const userConfig = require('./userConfig');

var config = {};

const path = require('path');

config.smtp = {};
config.email = {};
config.target = {};
config.msgs = {};
config.logs = {};

config.smtp.host = userConfig.smtp.host;
config.smtp.port = userConfig.smtp.port;
config.smtp.secure = userConfig.smtp.secure;
config.smtp.ignoreTLS = userConfig.smtp.ignoreTLS;

config.target.fullUrl = userConfig.target.fullUrl;
config.target.username = userConfig.target.username;
// slash required to escape the ! sign
config.target.password = userConfig.target.password;
config.target.httpMethod = userConfig.target.httpMethod
config.target.httpBody = userConfig.target.httpBody;
config.target.httpHeaders = userConfig.target.httpHeaders;
config.target.timeToWaitInMinutesBetweenChecks = userConfig.target.timeToWaitInMinutesBetweenChecks;

config.target.basicAuthToken = "Basic " + Buffer.from(config.target.username + ":" + config.target.password).toString('base64');

config.email.fromAddr = userConfig.email.fromAddr;
config.email.toAddr = userConfig.email.toAddr;
config.email.subject = userConfig.email.subject;
config.email.body = userConfig.email.body;

config.email.limit = userConfig.email.limit; 
config.email.resendPeriodInMinutes = userConfig.email.resendPeriodInMinutes;
config.email.resetPeriodInHours = userConfig.email.resetPeriodInHours;

config.msgs.title = userConfig.msgs.title;

config.logs.fileSpec = "logs" + path.sep + "err.log";

module.exports = config;
