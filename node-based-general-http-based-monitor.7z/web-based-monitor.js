var config = require('./config');

var mailUtils = require('./mailUtils');
var fileUtils = require('./fileUtils');
var netUtils = require('./netUtils');
var generalUtils = require('./generalUtils');
var dateUtils = require('./dateUtils');

(async() => {
	var numOfSentEmails = 0;
	var currentDate = "";
	var numOfSecondsUntilSettingsReset = config.email.resetPeriodInHours * 60 * 60;
	var result = "";
	
	while(true)
	{
		console.log("-----------------------------------------------------------------------------------");
		console.log(dateUtils.getCurrentDate("forText"));
		
		result = await netUtils.invokeAWebRequest(config.target.fullUrl, config.target.httpMethod, config.target.httpHeaders, "", "");
		
		console.log(result);
	
		if(result < 500)
		{
			console.log("got OK status");
			console.log("Waiting " + (config.target.timeToWaitInMinutesBetweenChecks * 60) + " second(s) before the next sample ...");
			
			await generalUtils.sleep(config.target.timeToWaitInMinutesBetweenChecks * 60);
			
			if(numOfSentEmails >= 1)
			{
				numOfSentEmails = 0;
				currentDate = "";
			}
		}
		else
		{
			if(result > 500)
			{
				if(numOfSentEmails > 1)
				{
					generalUtils.sleep(config.email.resendPeriodInMinutes * 60);
				}
				
				if(numOfSentEmails <= config.email.limit)
				{
					var status = await mailUtils.sendEmailPlain(config.email.fromAddr, config.email.toAddr, config.email.subject, config.email.body);
					
					numOfSentEmails++;
				}
				else
				{
					generalUtils.sleep(config.target.timeToWaitInMinutesBetweenChecks * 60);
				
					if(currentDate == "")
					{
						var currentDate = dateUtils.getCurrentDate("forCalculations");
					}
					else
					{
						var nextDate = dateUtils.getCurrentDate("forCalculations");
						
						if((nextDate - currentDate) > numOfSecondsUntilSettingsReset)
						{
							numOfSentEmails = 0;
							currentDate = "";
						}
					}
				}
			}
		}
	}
})();
	
