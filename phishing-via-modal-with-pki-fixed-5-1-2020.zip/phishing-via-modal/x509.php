<?php
// given the variables as constants:

  //Block size for encryption block cipher
  $ENCRYPT_BLOCK_SIZE = 200;// this for 2048 bit key for example, leaving some room

  //Block size for decryption block cipher
  $DECRYPT_BLOCK_SIZE = 256;// this again for 2048 bit key
	
	$KEY = "-----BEGIN PRIVATE KEY-----
MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDuZmNYYI+9DWo8
X4wgISwispe/YhGUYSKWBjLOTSW6oQDdsVkCm0IA3i2b+bxDYqO1SBzzeKoxT6hs
HqA0rOwy6ceJSvlMVJeDF9GV6IxPuJaVvIMmbAKn2a78HfMV+/fh3JOXqZh0FDa2
V/7GMccs7ar50JmRDX5l/zlmx1nWVA2f+/ycuN5fsNDdPn5EuX8SkYj6n6h2yNHK
WkM9H+uwYs+LjIMmTwlqsV6Qqck5EPcXFYRGt5zUkpD0Ok4iTUGbTzMRAuvQrKtw
NgJXNyxx8VeHYnHouZqrmhHRGxDITtTtT1v/fQmyGRkzGhAzukl7MkHeIdH58kcO
WzOzKKM/AgMBAAECggEAW2+Jyuu+NZRfmqhK5kfS1bwJ162VcIOQ8FmQQu/z+JCn
9F+A9C74Mb0FYT13p6C9iVoPQJKXNDKJNm7Io2tvbFed4FqRI2WOdwk7qXN33Vu+
5c9XvfTPT/F929Tg1x29BTPEp/a0MlFOasF1Ri7xZZoCaa5IOAok4JnzOihbnIgC
8IcDhrKVSfdNUjTkV6iW58WfWPyFer39l7wGx+w5tFlHIJuhj9uVLT+RVG/kqQy/
X48ZG/z29ZHwy6zeIhqlPWR+VdJJ8iTfsOhLasizM21v2JXqaYTFk9Dr9rDU+vhU
0x8IICGZFjgnfAxt5z6NQ53+rZ/W0FDi/GsT8x3zgQKBgQD3n4pzCd/Z1LKqGoUP
3TObnGDkVs/+mJ4PljR592AFE/ADbyHNNNKuaS5cogKUwMS/t/DiTcgYUo8C25XC
rzcmOLIf/VKTSAQTt8QdzIj45jd82a+54hNgQUbjH8e8P9mYrvnRk0lenZYZ6JO5
btE8L8EPav8bxAn7g8icUp184wKBgQD2dvjpFnOzlxYIB04kIfkcfeJaWOUGrWiY
l50/DDJHEuKhJ05/Zlo/Nr/Nvw7p6LioVgiEM7Mx3VcV3F+triYqIdJnYby7kH4L
CF+t68JD4W7cvE4lX6FZSf5y5IaKrSZeLyPjZ2CMsO84xVoTwgNnjIJIp/KYY3S6
NtWPvJfK9QKBgQDHEjTM3SBgUBW+mQlmQo/txx9CEuSuKmXP5BKWByDjlC69pAdJ
oPDLFHYYNIrcqcjC1I7McHmvzBd61aulUxWEHcpd21saWqgkbfU1e6yWZQYw0hTq
3Gx1UqU5jOAXYEF/9ROTv9QZQ5lbhNXWGtgNidqsmXk0Cjt4P2709Zn0vwKBgGgA
hkKdlc9X1xUmOAQpTdyHBmhHkMWDkVqqx9EeDW1Oe9GzK325LCX2rXNdxyZPbPSj
8U4QHvLQyvnPl5RLo5Et2oKDjMe9TmLLcsyKatyIGWcOEw/UTdrGzZef9WI5dLJT
xBomumhEFX5oUP17ZkJg2W1daZKCjXQyxWW1GHytAoGASd4kbFU6uNunEQL0V9PG
w0D6ED8XySmZXAAhUOixFEP70t7pSFGpcOxJk/m+wmLUu7HjpWOoTGXWopA4Oqmr
8JkEtt3viGwowJsDaPHneHg5PO/wqZu0MyF8l/lCbVfYFne+Z0DeQNH8yy1L5R7q
71xJdUgKAkW2p0mIQHC9Kso=
-----END PRIVATE KEY-----";	
	
	
  //For encryption we would use:
  function encrypt_RSA($privatePEMKey, $plainData)
  {
	if($privatePEMKey != "" && $plainData != "")
	{
		$encrypted = '';
		$plainData = str_split($plainData, $GLOBALS["ENCRYPT_BLOCK_SIZE"]);
		
		foreach($plainData as $chunk)
		{
		  $partialEncrypted = '';

		  //using for example OPENSSL_PKCS1_PADDING as padding
		  $encryptionOk = openssl_private_encrypt($chunk, $partialEncrypted, $privatePEMKey, OPENSSL_PKCS1_PADDING);

		  if($encryptionOk === false){return false;}//also you can return and error. If too big this will be false
		  $encrypted .= $partialEncrypted;
		}
		return base64_encode($encrypted);//encoding the whole binary String as MIME base 64
	}
	else
	{
		return "empty string!";
	}
  }

         //For decryption we would use:
  function decrypt_RSA($publicPEMKey, $data)
  {
	if($publicPEMKey != "" && $data != "")
	{
		$decrypted = '';

		//decode must be done before spliting for getting the binary String
		$data = str_split(base64_decode($data), $GLOBALS["DECRYPT_BLOCK_SIZE"]);

		foreach($data as $chunk)
		{
		  $partial = '';

		  //be sure to match padding
		  $decryptionOK = openssl_public_decrypt($chunk, $partial, $publicPEMKey, OPENSSL_PKCS1_PADDING);

		  if($decryptionOK === false){return false;}//here also processed errors in decryption. If too big this will be false
		  $decrypted .= $partial;
		}
	
		return $decrypted;
	}
	else
	{
		return "empty string!";
	}
  }
  
?>
