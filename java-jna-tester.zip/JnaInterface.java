// javac -cp "jna-5.9.0.jar;jna-platform-5.9.0.jar" *.java
// java -cp ".;jna-5.9.0.jar" JnaClient

import com.sun.jna.Library;
import com.sun.jna.Platform;
import com.sun.jna.Native;

public interface JnaInterface extends Library {
    JnaInterface INSTANCE = (JnaInterface) Native.loadLibrary((Platform.isWindows() ? "msvcrt" : "c"), JnaInterface.class);
	
    void printf(String format, Object... args);
    int sprintf(byte[] buffer, String format, Object... args);
    int scanf(String format, Object... args);
}
