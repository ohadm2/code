// javac -cp "jna-5.9.0.jar;jna-platform-5.9.0.jar" *.java
// java -cp ".;jna-5.9.0.jar" JnaClient

import com.sun.jna.Native;

public class JnaClient {
    public static void main(String args[]) {
        JnaInterface jnaInstance = JnaInterface.INSTANCE;
        jnaInstance.printf("Jna via Win msvcrt: Hello World!");        

        for (int i = 0; i < args.length; i++) {
            jnaInstance.printf("\nArgument %d : %s", i, args[i]);
        }
    }
}
