add-type -AssemblyName Microsoft.Office.Interop.Word

$msWord = New-Object -Com Word.Application
$msWord.visible = $true

$docReport = $msWord.Documents.Add("C:\temp\test-word-vba\pt-report-template.docx")

#$range = $docReport.content

$range = $docReport.ActiveWindow.Selection.GoTo([Microsoft.Office.Interop.Word.WdGoToItem]::wdGoToPage, [Microsoft.Office.Interop.Word.WdGoToDirection]::wdGoToFirst, 7)

$selection = $msWord.selection

$selection.GoTo([Microsoft.Office.Interop.Word.WdGoToItem]::wdGoToLine, [Microsoft.Office.Interop.Word.WdGoToDirection]::wdGoToRelative, 3)

$selection = $msWord.selection

$selection.TypeText(�This is my text in Word Document using VBA�)

#$docReport.Tables.Add($range, 7, 3,[Microsoft.Office.Interop.Word.WdDefaultTableBehavior]::wdWord9TableBehavior, [Microsoft.Office.Interop.Word.WdAutoFitBehavior]::wdAutoFitFixed)




