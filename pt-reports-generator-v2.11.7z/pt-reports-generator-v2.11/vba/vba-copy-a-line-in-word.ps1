add-type -AssemblyName Microsoft.Office.Interop.Word

$msWord = New-Object -Com Word.Application
$msWord.visible = $true

$docSource = $msWord.Documents.Add("C:\temp\test-word-vba\metadata-exposure.rtf")

#$docSource | select name
#$docDest | select name

#$docSource | Get-Member
#$docDest | Get-Member


$docSource.ActiveWindow.Selection.GoTo([Microsoft.Office.Interop.Word.WdGoToItem]::wdGoToLine, [Microsoft.Office.Interop.Word.WdGoToDirection]::wdGoToRelative, 1)

$selection = $msWord.selection

$selection.HomeKey([Microsoft.Office.Interop.Word.wdunits]::wdStory)

$selection.MoveDown([Microsoft.Office.Interop.Word.wdunits]::wdLine, 1, [Microsoft.Office.Interop.Word.wdMovementType]::wdExtend)

$selection.copy

write-host $selection.text

$docDest = $msWord.Documents.Add("C:\temp\test-word-vba\pt-report-template.docx")

$range = $docDest.ActiveWindow.Selection.GoTo([Microsoft.Office.Interop.Word.WdGoToItem]::wdGoToPage, [Microsoft.Office.Interop.Word.WdGoToDirection]::wdGoToFirst, 7)

$selection2 = $msWord.selection

$selection2.GoTo([Microsoft.Office.Interop.Word.WdGoToItem]::wdGoToLine, [Microsoft.Office.Interop.Word.WdGoToDirection]::wdGoToRelative, 3)

$selection2 = $msWord.selection

$dataObject = New-Object System.Windows.Forms.DataObject

$dataObject.SetData("Text", $selection.text)

#$dataObject.SetData("Rich Text Format", $RichTextBox.Rtf)

[System.Windows.Forms.Clipboard]::SetDataObject($dataObject,$false)

$selection2.PasteAndFormat([Microsoft.Office.Interop.Word.WdRecoveryType]::wdUseDestinationStylesRecovery)

#$range.paste

#$docDest.ActiveWindow.Selection.PasteAndFormat([Microsoft.Office.Interop.Word.WdRecoveryType]::wdUseDestinationStylesRecovery)




