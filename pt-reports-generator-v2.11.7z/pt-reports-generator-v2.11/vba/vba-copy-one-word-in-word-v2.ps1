﻿# include a script
. ($PSScriptRoot + "\" + "vba-functions.ps1")


add-type -AssemblyName Microsoft.Office.Interop.Word

$msWord = New-Object -Com Word.Application
$msWord.visible = $true

<# key-value array:

$ageList = @{}

$key = 'Kevin'
$value = 36

$ageList.add( $key, $value )

$ageList[$key] = $value

$ageList['Alex'] = 9

#>

$dataArr = @{}

# collect data from the source document and into an array

$docSource = $msWord.Documents.Add("C:\temp\test-word-vba\metadata-exposure.rtf")

#$docSource | select name
#$docSource | Get-Member

$range = $docSource.ActiveWindow.Selection.GoTo([Microsoft.Office.Interop.Word.WdGoToItem]::wdGoToLine, [Microsoft.Office.Interop.Word.WdGoToDirection]::wdGoToRelative, 1)

$selection = $msWord.selection

$range = $selection.HomeKey([Microsoft.Office.Interop.Word.wdunits]::wdStory)

$range = $selection.MoveDown([Microsoft.Office.Interop.Word.wdunits]::wdLine, 1, [Microsoft.Office.Interop.Word.wdMovementType]::wdExtend)

$dataArr.add("finding", $selection.text)

write-host $selection.text

$range = $docSource.ActiveWindow.Selection.GoTo([Microsoft.Office.Interop.Word.WdGoToItem]::wdGoToLine, [Microsoft.Office.Interop.Word.WdGoToDirection]::wdGoToAbsolute, 2)

$selection = $msWord.selection

#$range = $selection.HomeKey([Microsoft.Office.Interop.Word.wdunits]::wdStory)

$range = $selection.MoveDown([Microsoft.Office.Interop.Word.wdunits]::wdLine, 1, [Microsoft.Office.Interop.Word.wdMovementType]::wdExtend)

$wordsArr = $selection.text.Split()

$word = $wordsArr[2]

$dataArr.add("severity", $word)

write-host $word

$msWord.ActiveDocument.Close()


$docDest = $msWord.Documents.Add("C:\temp\test-word-vba\pt-report-template.docx")

# paste the collected data into the destination document

$loc = (Go-ToLocationInADocument $docDest 7 3)

if($loc -ne $false)
{
    $status = (Write-TextInADocument $loc $dataArr["finding"])
}

$loc = (Go-ToLocationInADocument $docDest 7 4)

if($loc -ne $false)
{
    $status = (Write-TextInADocument $loc $dataArr["severity"])
}
