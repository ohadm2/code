﻿# include a script
. ($PSScriptRoot + "\" + "vba-functions.ps1")

add-type -AssemblyName Microsoft.Office.Interop.Word

$msWord = New-Object -Com Word.Application
$msWord.visible = $true

# collect data
# create the data table
# create the stats table
# create a table of contents

$oneDimFindingsDataArr = [System.collections.arraylist]@()
$hashTableFindingsColorsArr = @{}

$findingsNumberPrefix = "4."
$findingsNumberCounter = 1

$criticalFindingsCounter = 0
$criticalFindingsIdentifier = "קריטית"
$criticalFindingsColor = "purple"

$highFindingsCounter = 0
$highFindingsIdentifier = "גבוהה"
$highFindingsColor = "red"

$mediumFindingsCounter = 0
$mediumFindingsIdentifier = "בינונית"
$mediumFindingsColor = "orange"

$lowFindingsCounter = 0
$lowFindingsIdentifier = "נמוכה"
$lowFindingsColor = "lightblue"

$infoFindingsCounter = 0
$infoFindingsIdentifier = "לידיעה"
$infoFindingsColor = "green"

$numberOfSeverities = 5

# collect the data from the rtfs

$rtfs = Get-ChildItem "C:\temp\test-word-vba" -Filter "*.rtf"

foreach ($rtf in $rtfs)
{
<#
    $RichTextBox = New-Object -TypeName System.Windows.Forms.RichTextBox

    $RichTextBox.rtf = [System.IO.File]::ReadAllText($rtf.fullname)

    $dataObject = New-Object System.Windows.Forms.DataObject

    $dataObject.SetData("Text", $RichTextBox.Text)
    $dataObject.SetData("Rich Text Format", $RichTextBox.Rtf)

    [System.Windows.Forms.Clipboard]::SetDataObject($dataObject,$false)
#>
    $doc = $msWord.Documents.Add($rtf.fullname)

    $findingNumber = $findingsNumberPrefix + $findingsNumberCounter.ToString()
    $findingDescription = (Get-ALineOfTextFromADocument $doc 1 1)
    $findingSeverity = (Get-OneWordFromADocument $doc 1 2 3)

    $findingDescription = $findingDescription.Replace("`n","")
    $findingDescription = $findingDescription.Replace("(","_")
    $findingDescription = $findingDescription.Replace(")","_")
    $findingDescription = $findingDescription.Replace("`"","")
    $findingDescription = $findingDescription.Trim()


    [void]$oneDimFindingsDataArr.add($findingNumber)
    [void]$oneDimFindingsDataArr.add($findingDescription)
    $findingSeverityIndex = $oneDimFindingsDataArr.add($findingSeverity)

    switch($findingSeverity)
    {
        $criticalFindingsIdentifier
        {
            $hashTableFindingsColorsArr.add($findingSeverityIndex, $criticalFindingsColor)
            $criticalFindingsCounter++
        }
        $highFindingsIdentifier
        {
            $hashTableFindingsColorsArr.add($findingSeverityIndex, $highFindingsColor)
            $highFindingsCounter++
        }
        $mediumFindingsIdentifier
        {
            $hashTableFindingsColorsArr.add($findingSeverityIndex, $mediumFindingsColor)
            $mediumFindingsCounter++
        }
        $lowFindingsIdentifier
        {
            $hashTableFindingsColorsArr.add($findingSeverityIndex, $lowFindingsColor)
            $lowFindingsCounter++
        }
        $infoFindingsIdentifier
        {
            $hashTableFindingsColorsArr.add($findingSeverityIndex, $infoFindingsColor)
            $infoFindingsCounter++
        }
        default
        {
        }
    }

    $findingsNumberCounter++

    $doc.activewindow.close()
}


$ptTemplate = "C:\temp\test-word-vba\pt-report-template.docx"

$ptReport = $msWord.Documents.Add("$ptTemplate")


# init static data

$findingsTableHeadersArr = (0..2)

$findingsTableHeadersArr[0] = "מספר"
$findingsTableHeadersArr[1] = "תיאור הממצא"
$findingsTableHeadersArr[2] = "רמת חומרה"


$statsTableHeadersArr = (0..4)

$statsTableHeadersArr[0] = "סיכון קריטי"
$statsTableHeadersArr[1] = "סיכון גבוה"
$statsTableHeadersArr[2] = "סיכון בינוני"
$statsTableHeadersArr[3] = "סיכון נמוך"
$statsTableHeadersArr[4] = "לידיעה"


$oneDimStatsDataArr = [System.collections.arraylist]@()

[void]$oneDimStatsDataArr.Add($criticalFindingsCounter.ToString())
[void]$oneDimStatsDataArr.Add($highFindingsCounter.ToString())
[void]$oneDimStatsDataArr.Add($mediumFindingsCounter.ToString())
[void]$oneDimStatsDataArr.Add($lowFindingsCounter.ToString())
[void]$oneDimStatsDataArr.Add($infoFindingsCounter.ToString())


$hashTableStatsColorsArr = @{}

$hashTableStatsColorsArr.add(0,$criticalFindingsColor)
$hashTableStatsColorsArr.add(1,$highFindingsColor)
$hashTableStatsColorsArr.add(2,$mediumFindingsColor)
$hashTableStatsColorsArr.add(3,$lowFindingsColor)
$hashTableStatsColorsArr.add(4,$infoFindingsColor)


#$loc = (Go-ToLocationInADocument $global:mainDoc 8 9)

#Write-TextInADocument $loc "`n" | out-null
#Write-TextInADocument $loc "`n" | out-null


# create and design the findings table

$loc = (Go-ToLocationInADocument $ptReport 8 5)

# Create-ANewTableInADocumentWithBookmarks($docObj, $locationAsASelectionObj, $headersArr, $oneDimDataArr, $columnNumToUseAsBookmark, $columnNumToUseAsHyperlink)

if((Create-ANewTableInADocumentWithBookmarks $ptReport $loc $findingsTableHeadersArr $oneDimFindingsDataArr 2) -eq $true)
{
    $loc = (Go-ToLocationInADocument $ptReport 8 5)

    if($loc -ne $false)
    {
        if((Design-ATableInADocument $ptReport $loc "right" 3 ($findingsNumberCounter-1) $true $false "black" "gray" $hashTableFindingsColorsArr) -eq $false)
        {
            write-host "ERROR! failed to design the 'findings' table."
        }
    }


    # create and design the stats table

    $loc = (Go-ToLocationInADocument $ptReport 6 12)

    if((Create-ANewTableInADocument $ptReport $loc $statsTableHeadersArr $oneDimStatsDataArr) -eq $true)
    {
        $loc = (Go-ToLocationInADocument $ptReport 6 12)

        if($loc -ne $false)
        {
            if((Design-ATableInADocument $ptReport $loc "right" $numberOfSeverities 1 $true $false "black" "gray" $hashTableStatsColorsArr) -eq $false)
            {
                write-host "ERROR! failed to design the 'stats' table."
            }
        }

    }
    else
    {
         write-host "ERROR! failed to create the 'stats' table."
    }

    # create the table of contents

    $loc = (Go-ToLocationInADocument $ptReport 2 1)

    if($loc -ne $false)
    {
        $toc = $ptReport.TablesOfContents.Add($loc.range)

        [void]$toc.update
    }
}
else
{
    write-host "ERROR! failed to create the 'findings' table."
}

######################################################################
# copy the content of the findings to the report
######################################################################

$range = $ptReport.content

# go to the end of the document
$ptReport.ActiveWindow.Selection.EndOf([Microsoft.Office.Interop.Word.wdunits]::wdStory)

# insert a new page break
$ptReport.ActiveWindow.Selection.InsertBreak([Microsoft.Office.Interop.Word.WdBreakType]::wdPageBreak)


foreach ($rtf in $rtfs)
{
    $RichTextBox = New-Object -TypeName System.Windows.Forms.RichTextBox

    $RichTextBox.rtf = [System.IO.File]::ReadAllText($rtf.fullname)

    $dataObject = New-Object System.Windows.Forms.DataObject

    $dataObject.SetData("Text", $RichTextBox.Text)
    $dataObject.SetData("Rich Text Format", $RichTextBox.Rtf)

    [System.Windows.Forms.Clipboard]::SetDataObject($dataObject,$false)
    
    # paste the content from the clipboard
    $ptReport.ActiveWindow.Selection.PasteAndFormat([Microsoft.Office.Interop.Word.WdRecoveryType]::wdUseDestinationStylesRecovery)

    # insert a new page break
    $ptReport.ActiveWindow.Selection.InsertBreak([Microsoft.Office.Interop.Word.WdBreakType]::wdPageBreak)
}

