﻿add-type -AssemblyName Microsoft.Office.Interop.Word

$msWord = New-Object -Com Word.Application

$msWord.visible = $true

$doc = $msWord.Documents.Add("C:\temp\test-word-vba\metadata-exposure.rtf")

$range = $doc.ActiveWindow.Selection.GoTo([Microsoft.Office.Interop.Word.WdGoToItem]::wdGoToLine, [Microsoft.Office.Interop.Word.WdGoToDirection]::wdGoToFirst, 1)

$selection = $msWord.selection

$doc.Tables.Add($selection.range, 1, 3,[Microsoft.Office.Interop.Word.WdDefaultTableBehavior]::wdWord9TableBehavior, [Microsoft.Office.Interop.Word.WdAutoFitBehavior]::wdAutoFitFixed)

$table = $doc.Tables(1)

$row = $selection.InsertRowsBelow(1)

#$table.rows(2).cells(1).range.text = "test"

#$test2 = New-Object -ComObject System.String

#[string]$test2 = "text"

$test2 = "sdddsdsd"

$table.Cell(0, 1).Range.text = "test1"
$table.Cell(0, 2).range.text = [string]$test2
$table.Cell(0, 3).range.text = "wewewewe"

$row = $selection.InsertRowsBelow(1)

$table.Cell(0, 1).Range.text = "test1"
$table.Cell(0, 2).range.text = [string]$test2
$table.Cell(0, 3).range.text = "wewewewe"


#$table.Cell(1, 1).Range.text.gettype().fullname

#$test2.gettype().fullname