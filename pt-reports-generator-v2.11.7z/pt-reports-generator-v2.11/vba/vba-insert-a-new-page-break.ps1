﻿# include a script
. ($PSScriptRoot + "\" + "vba-functions.ps1")

add-type -AssemblyName Microsoft.Office.Interop.Word

$msWord = New-Object -Com Word.Application
$msWord.visible = $true

$ptTemplate = "C:\temp\test-word-vba\pt-report-template.docx"

$doc = $msWord.Documents.Add("$ptTemplate")

$selection = $msWord.Selection

$selection.InsertBreak([Microsoft.Office.Interop.Word.WdBreakType]::wdPageBreak)

# objSelection.InsertBreak(wdPageBreak)