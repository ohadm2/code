﻿#add-type -AssemblyName Microsoft.Office.Interop.Word

#$msWord = New-Object -Com Word.Application
#$msWord.visible = $true

#$global:mainDoc = $msWord.Documents.Add("C:\temp\test-word-vba\pt-report-template.docx")


function Go-ToLocationInADocument($docObj, $pageNumber, $lineNumber)
{
    if($docObj.gettype().fullname -eq "Microsoft.Office.Interop.Word.DocumentClass")
    {
        if($pageNumber -eq "" -or $lineNumber -eq "")
        {
            write-host "ERROR! Wrong usage! one or two parameters are empty! (func: Go-ToLocationInADocument)"

            return $false
        }
        else
        {
            $range = $docObj.ActiveWindow.Selection.GoTo([Microsoft.Office.Interop.Word.WdGoToItem]::wdGoToPage, [Microsoft.Office.Interop.Word.WdGoToDirection]::wdGoToFirst, $pageNumber)

            $selection = $msWord.selection

            $range = $selection.GoTo([Microsoft.Office.Interop.Word.WdGoToItem]::wdGoToLine, [Microsoft.Office.Interop.Word.WdGoToDirection]::wdGoToRelative, $lineNumber)

            $selection = $msWord.selection

            return $selection
        }
    }
    else
    {
        write-host "ERROR! Wrong object inserted to function! (func: Go-ToLocationInADocument)"

        return $false
    }
}


function Write-TextInADocument($locationAsASelectionObj, $text)
{
    if($locationAsASelectionObj.gettype().fullname -eq "System.__ComObject")
    {
        if($text -eq $null)
        {
            write-host "ERROR! 'text' parameter is null! (func: Write-TextInADocument)"

            return $false
        }
        else
        {
            echo $locationAsASelectionObj.range.gettype().fullname

            $locationAsASelectionObj.TypeText($text)
           
            if($? -eq $true)
            {
                return $true
            }
            else
            {
                write-host "ERROR! Something went wrong while trying to write the text."

                return $false
            }
        }
    }
    else
    {
        write-host "ERROR! Wrong object inserted to function! (func: Write-TextInADocument)"

        return $false
    }    
}


function Create-ANewTableInADocumentUsing2DimsDataArray($docObj, $locationAsASelectionObj, $headersArr, $dataArr)
{
    if($docObj.gettype().fullname -eq "Microsoft.Office.Interop.Word.DocumentClass")
    {
        if($locationAsASelectionObj.gettype().fullname -eq "System.__ComObject")
        {
            if($headersArr -ne $null -and $dataArr -ne $null)
            {
                if($headersArr -is [array] -and $dataArr -is [System.Collections.ArrayList])
                {
                    $numOfColumns = $headersArr.count

                    $table = $docObj.Tables.Add($locationAsASelectionObj.range, 1, $numOfColumns,[Microsoft.Office.Interop.Word.WdDefaultTableBehavior]::wdWord9TableBehavior, [Microsoft.Office.Interop.Word.WdAutoFitBehavior]::wdAutoFitFixed)

                    $table = $docObj.Tables(1)


                    for($i=1;$i -le $numOfColumns; $i++)
                    {
                        $table.Cell(0,$i).Range.Text = $headersArr[($i-1)]
                    }

                    $numOfLines = $dataArr.count / $numOfColumns

                    for($j=0; $j -lt $numOfLines; $j++)
                    {
                        $row = $locationAsASelectionObj.InsertRowsBelow(1)

                        #sleep -s 5

                        for($i=1; $i -le $numOfColumns; $i++)
                        {   
                            $table.Cell(0,$i).Range.Text = $dataArr[$j,($i-1)]

                            #echo $j,$i

                            #echo $dataArr[$j,$i-1]
                        }
                    }
                }
                else
                {
                    write-host "ERROR! an invalid array was inserted! (func: Create-ANewTableInADocument, 3rd / 4th parameters)"
                }
            }
            else
            {
                write-host "ERROR! One or two of the given parameters is null and neither can be null! (func: Create-ANewTableInADocument, 3rd / 4th parameters)"
            }
        }
        else
        {
            write-host "ERROR! Wrong range object inserted to function! (func: Create-ANewTableInADocument, 2nd parameter)"

            return $false
        }
    }
    else
    {
        write-host "ERROR! Wrong doc object inserted to function! (func: Create-ANewTableInADocument, 1st parameter)"

        return $false
    }
}


function Create-ANewTableInADocument($docObj, $locationAsASelectionObj, $headersArr, $oneDimDataArr)
{
    if($docObj.gettype().fullname -eq "Microsoft.Office.Interop.Word.DocumentClass")
    {
        if($locationAsASelectionObj.gettype().fullname -eq "System.__ComObject")
        {
            if($headersArr -ne $null -and $oneDimDataArr -ne $null)
            {
                if($headersArr -is [array] -and $oneDimDataArr -is [System.Collections.ArrayList])
                {
                    $numOfColumns = $headersArr.count

                    $table = $docObj.Tables.Add($locationAsASelectionObj.range, 1, $numOfColumns,[Microsoft.Office.Interop.Word.WdDefaultTableBehavior]::wdWord9TableBehavior, [Microsoft.Office.Interop.Word.WdAutoFitBehavior]::wdAutoFitFixed)

                    $table = $docObj.Tables(1)

                    $numOfLines = $oneDimDataArr.count / $numOfColumns

                    $numOfCells = $oneDimDataArr.count


                    for($i=0;$i -lt $numOfColumns; $i++)
                    {
                        $table.Cell(0,($i+1)).Range.Text = $headersArr[$i]
                    }

                    for($j=0; $j -lt $numOfLines; $j++)
                    {
                        $row = $locationAsASelectionObj.InsertRowsBelow(1)

                        #sleep -s 5

                        for($i=0; $i -lt $numOfColumns; $i++)
                        {   
                            $table.Cell(0,($i+1)).Range.Text = $oneDimDataArr[$i+($j*$numOfColumns)]

                            #echo $j,$i

                            #echo $dataArr[$j,$i-1]
                        }
                    }

                    return $true
                }
                else
                {
                    write-host "ERROR! an invalid array was inserted! (func: Create-ANewTableInADocument, 3rd / 4th parameters)"

                    return $false
                }
            }
            else
            {
                write-host "ERROR! One or two of the given parameters is null and neither can be null! (func: Create-ANewTableInADocument, 3rd / 4th parameters)"

                return $false
            }
        }
        else
        {
            write-host "ERROR! Wrong range object inserted to function! (func: Create-ANewTableInADocument, 2nd parameter)"

            return $false
        }
    }
    else
    {
        write-host "ERROR! Wrong doc object inserted to function! (func: Create-ANewTableInADocument, 1st parameter)"

        return $false
    }
}


function Create-ANewTableInADocumentWithBookmarksV1($docObj, $locationAsASelectionObj, $headersArr, $oneDimDataArr, $columnNumToUseAsBookmark, $columnNumToUseAsHyperlink)
{
    if($docObj.gettype().fullname -eq "Microsoft.Office.Interop.Word.DocumentClass")
    {
        if($locationAsASelectionObj.gettype().fullname -eq "System.__ComObject")
        {
            if($headersArr -ne $null -and $oneDimDataArr -ne $null)
            {
                if($headersArr -is [array] -and $oneDimDataArr -is [System.Collections.ArrayList])
                {
                    $numOfColumns = $headersArr.count

                    $table = $docObj.Tables.Add($locationAsASelectionObj.range, 1, $numOfColumns,[Microsoft.Office.Interop.Word.WdDefaultTableBehavior]::wdWord9TableBehavior, [Microsoft.Office.Interop.Word.WdAutoFitBehavior]::wdAutoFitFixed)

                    $table = $docObj.Tables(1)

                    $numOfLines = $oneDimDataArr.count / $numOfColumns

                    $numOfCells = $oneDimDataArr.count

                    for($i=1;$i -le $numOfColumns; $i++)
                    {
                        $table.Cell(0,$i).Range.Text = $headersArr[($i-1)]
                    }

                    for($j=0; $j -lt $numOfLines; $j++)
                    {
                        $row = $locationAsASelectionObj.InsertRowsBelow(1)

                        #sleep -s 5

                        for($i=0; $i -lt $numOfColumns; $i++)
                        {   
                            $table.Cell(0,($i+1)).Range.Text = $oneDimDataArr[$i+($j*$numOfColumns)]

                            if($columnNumToUseAsHyperlink -is [int] -and $columnNumToUseAsBookmark -is [int])
                            {
                                if($columnNumToUseAsHyperlink -le $numOfColumns -and $columnNumToUseAsBookmark -le $numOfColumns)
                                {
                                    if($columnNumToUseAsHyperlink -gt 0 -and $columnNumToUseAsBookmark -gt 0)
                                    {
                                        if($columnNumToUseAsHyperlink -ne $columnNumToUseAsBookmark)
                                        {
                                            if(($i+1) -eq $columnNumToUseAsHyperlink)
                                            {
                                                $msWord.ActiveDocument.Hyperlinks.Add($table.Cell(0,($i+1)).Range, "", $oneDimDataArr[$i+($j*$numOfColumns)+($columnNumToUseAsBookmark-$columnNumToUseAsHyperlink)], "", $table.Cell(0,($i+1)).Range.Text)
                                            }
                                        }
                                        else
                                        {
                                            write-host "WARNING: bad arguments were inserted for bookmarking. Bookmarks will NOT be created. (func: Create-ANewTableInADocumentWithBookmarks, 5th / 6th parameters)"
                                        }
                                    }
                                    else
                                    {
                                        write-host "WARNING: bad arguments were inserted for bookmarking. Bookmarks will NOT be created. (func: Create-ANewTableInADocumentWithBookmarks, 5th / 6th parameters)"
                                    }
                                }
                                else
                                {
                                    write-host "WARNING: bad arguments were inserted for bookmarking. Bookmarks will NOT be created. (func: Create-ANewTableInADocumentWithBookmarks, 5th / 6th parameters)"
                                }
                            }
                            else
                            {
                                    write-host "WARNING: bad arguments were inserted for bookmarking. Bookmarks will NOT be created. (func: Create-ANewTableInADocumentWithBookmarks, 5th / 6th parameters)"
                            }

                            #echo $j,$i

                            #echo $dataArr[$j,$i-1]
                        }
                    }

                    return $true
                }
                else
                {
                    write-host "ERROR! an invalid array was inserted! (func: Create-ANewTableInADocumentWithBookmarks, 3rd / 4th parameters)"

                    return $false
                }
            }
            else
            {
                write-host "ERROR! One or two of the given parameters is null and neither can be null! (func: Create-ANewTableInADocumentWithBookmarks, 3rd / 4th parameters)"

                return $false
            }
        }
        else
        {
            write-host "ERROR! Wrong range object inserted to function! (func: Create-ANewTableInADocumentWithBookmarks, 2nd parameter)"

            return $false
        }
    }
    else
    {
        write-host "ERROR! Wrong doc object inserted to function! (func: Create-ANewTableInADocumentWithBookmarks, 1st parameter)"

        return $false
    }
}


function Create-ANewTableInADocumentWithBookmarks($docObj, $locationAsASelectionObj, $headersArr, $oneDimDataArr, $columnNumToUseAsHyperlinkToABookmarkByTheSameName)
{
    if($docObj.gettype().fullname -eq "Microsoft.Office.Interop.Word.DocumentClass")
    {
        if($locationAsASelectionObj.gettype().fullname -eq "System.__ComObject")
        {
            if($headersArr -ne $null -and $oneDimDataArr -ne $null)
            {
                if($headersArr -is [array] -and $oneDimDataArr -is [System.Collections.ArrayList])
                {
                    $numOfColumns = $headersArr.count

                    $table = $docObj.Tables.Add($locationAsASelectionObj.range, 1, $numOfColumns,[Microsoft.Office.Interop.Word.WdDefaultTableBehavior]::wdWord9TableBehavior, [Microsoft.Office.Interop.Word.WdAutoFitBehavior]::wdAutoFitContent)

                    $table = $docObj.Tables(1)

                    $numOfLines = $oneDimDataArr.count / $numOfColumns

                    $numOfCells = $oneDimDataArr.count


                    for($i=1; $i -le $numOfColumns; $i++)
                    {
                        write-host "About to set the header"$headersArr[($i-1)]"in cell(0,"$i") ..."

                        $table.Cell(0,$i).Range.Text = $headersArr[($i-1)]
                    }

                    for($j=0; $j -lt $numOfLines; $j++)
                    {
                        $row = $locationAsASelectionObj.InsertRowsBelow(1)

                        #sleep -s 5

                        for($i=0; $i -lt $numOfColumns; $i++)
                        {   
                            $table.Cell(0,($i+1)).Range.Text = $oneDimDataArr[$i+($j*$numOfColumns)]

                            #sleep 2

                            if($columnNumToUseAsHyperlinkToABookmarkByTheSameName -is [int])
                            {
                                if($columnNumToUseAsHyperlinkToABookmarkByTheSameName -le $numOfColumns)
                                {
                                    if($columnNumToUseAsHyperlinkToABookmarkByTheSameName -gt 0)
                                    {
                                        if(($i+1) -eq $columnNumToUseAsHyperlinkToABookmarkByTheSameName)
                                        {
                                            $msWord.ActiveDocument.Hyperlinks.Add($table.Cell(0,($i+1)).Range, "", $oneDimDataArr[$i+($j*$numOfColumns)].Replace(" ","_"), "", $oneDimDataArr[$i+($j*$numOfColumns)])
                                        }
                                    }
                                    else
                                    {
                                        write-host "WARNING: bad arguments were inserted for bookmarking. Bookmarks will NOT be created. (func: Create-ANewTableInADocumentWithBookmarks, 5th parameter)"
                                    }
                                }
                                else
                                {
                                    write-host "WARNING: bad arguments were inserted for bookmarking. Bookmarks will NOT be created. (func: Create-ANewTableInADocumentWithBookmarks, 5th parameter)"
                                }
                            }
                            else
                            {
                                    write-host "WARNING: bad arguments were inserted for bookmarking. Bookmarks will NOT be created. (func: Create-ANewTableInADocumentWithBookmarks, 5th parameter)"
                            }

                            #echo $j,$i

                            #echo $dataArr[$j,$i-1]
                        }
                    }

                    return $true
                }
                else
                {
                    write-host "ERROR! an invalid array was inserted! (func: Create-ANewTableInADocumentWithBookmarks, 3rd / 4th parameters)"
                }
            }
            else
            {
                write-host "ERROR! One or two of the given parameters is null and neither can be null! (func: Create-ANewTableInADocumentWithBookmarks, 3rd / 4th parameters)"
            }
        }
        else
        {
            write-host "ERROR! Wrong range object inserted to function! (func: Create-ANewTableInADocumentWithBookmarks, 2nd parameter)"

            return $false
        }
    }
    else
    {
        write-host "ERROR! Wrong doc object inserted to function! (func: Create-ANewTableInADocumentWithBookmarks, 1st parameter)"

        return $false
    }
}


function Color-NameToOfficeEnum($colorName)
{
    switch($colorName)
    {
        "red"
        {
            return [Microsoft.Office.Interop.Word.WdColor]::wdColorRed
        }
        "green"
        {
            return [Microsoft.Office.Interop.Word.WdColor]::wdColorGreen
        }
        "blue"
        {
            return [Microsoft.Office.Interop.Word.WdColor]::wdColorBlue
        }
        "lightblue"
        {
            return [Microsoft.Office.Interop.Word.WdColor]::wdColorLightBlue
        }
        "yellow"
        {
            return [Microsoft.Office.Interop.Word.WdColor]::wdColorYellow
        }
        "orange"
        {
            return [Microsoft.Office.Interop.Word.WdColor]::wdColorOrange
        }
        "gray"
        {
            return [Microsoft.Office.Interop.Word.WdColor]::wdColorGray25
        }
        "black"
        {
            return [Microsoft.Office.Interop.Word.WdColor]::wdColorBlack
        }
        "purple"
        {
            return [Microsoft.Office.Interop.Word.WdColor]::wdColorViolet
        }
        default
        {
            return [Microsoft.Office.Interop.Word.WdColor]::wdColorBlack
        }
    }
}


function Create-ANewTableInADocumentWithStyleUsing2DimsDataArray($docObj, $locationAsASelectionObj, $headersArr, $dataArr, $areHeadersBold, $areHeadersItalic, $headersTextColor, $headersTextSize, $dataCellsColorsArr)
{
    if($docObj.gettype().fullname -eq "Microsoft.Office.Interop.Word.DocumentClass")
    {
        if($locationAsASelectionObj.gettype().fullname -eq "System.__ComObject")
        {
            if($headersArr -ne $null -and $dataArr -ne $null)
            {
                if($headersArr -is [array] -and $dataArr -is [System.Collections.ArrayList])
                {
                    $numOfColumns = $headersArr.length

                    $table = $docObj.Tables.Add($locationAsASelectionObj.range, 1, $numOfColumns,[Microsoft.Office.Interop.Word.WdDefaultTableBehavior]::wdWord9TableBehavior, [Microsoft.Office.Interop.Word.WdAutoFitBehavior]::wdAutoFitFixed)

                    $table = $docObj.Tables(1)

                    

                    if($dataCellsColorsArr -is [array])
                    {
                        $doDataColors = $true
                    }

                    for($i=1;$i -le $numOfColumns; $i++)
                    {
                        write-host "working on cell (0,$i) ..."

                        $cell = $table.Cell(0,$i)

                        
                        $cell.Range.Text = $headersArr[($i-1)]

                        if($areHeadersBold -eq $true)
                        {
                            echo "Making cell '(0,$i)' bold ..."
                         
                            $cell.Range.Font.Bold = -1
                        }

                        if($areHeadersItalic -eq $true)
                        {
                            echo "Making cell '(0,$i)' italic ..."

                            $table.Cell(0,$i).Range.Font.Italic = -1
                        }

                        if($headersTextSize -is [int])
                        {
                            #$table.Cell(0,$i).Range.Font.Size = $headersTextSize
                        }

                        switch($headersTextColor)
                        {
                            "red"
                            {
                                $table.Cell(0,$i).Range.Font.TextColor = (Color-NameToOfficeEnum "red")
                            }
                            "green"
                            {
                                $table.Cell(0,$i).Range.Font.TextColor = (Color-NameToOfficeEnum "green")
                            }
                            "blue"
                            {
                                $table.Cell(0,$i).Range.Font.TextColor = (Color-NameToOfficeEnum "blue")
                            }
                            "lightblue"
                            {
                                $table.Cell(0,$i).Range.Font.TextColor = (Color-NameToOfficeEnum "lightblue")
                            }
                            "yellow"
                            {
                                $table.Cell(0,$i).Range.Font.TextColor = (Color-NameToOfficeEnum "yellow")
                            }
                            "orange"
                            {
                                $table.Cell(0,$i).Range.Font.TextColor = (Color-NameToOfficeEnum "orange")
                            }
                            default
                            {
                                $table.Cell(0,$i).Range.Font.TextColor = (Color-NameToOfficeEnum "black")
                            }
                        }

                        $table.Cell(0,$i).Range.ParagraphFormat.Alignment = [Microsoft.Office.Interop.Word.WdAlignmentTabAlignment]::wdCenter


                        echo "Just edited header cell '(0,$i)'"

                        #sleep 3
                    }

                    $numOfLines = $dataArr.length / $numOfColumns

                    for($j=0; $j -lt $numOfLines; $j++)
                    {
                        $row = $locationAsASelectionObj.InsertRowsBelow(1)

                        #sleep 3

                        for($i=1; $i -le $numOfColumns; $i++)
                        {
                            if($doDataColors -eq $true)
                            {
                                if($dataCellsColorsArr[$j,($i-1)] -is [string])
                                {
                                    'About to set the color {0} on cell ({1},{2}) ...' -f $dataCellsColorsArr[$j,($i-1)],$j,$i

                                    switch($dataCellsColorsArr[$j,($i-1)])
                                    {
                                        "red"
                                        {
                                            $table.Cell(0,$i).Range.Font.TextColor = (Color-NameToOfficeEnum "red")

                                            echo (Color-NameToOfficeEnum "red")
                                        }
                                        "green"
                                        {
                                            $table.Cell(0,$i).Range.Font.TextColor = (Color-NameToOfficeEnum "green")
                                        }
                                        "blue"
                                        {
                                            $table.Cell(0,$i).Range.Font.TextColor = (Color-NameToOfficeEnum "blue")
                                        }
                                        "lightblue"
                                        {
                                            $table.Cell(0,$i).Range.Font.TextColor = (Color-NameToOfficeEnum "lightblue")

                                            echo (Color-NameToOfficeEnum "lightblue")
                                        }
                                        "yellow"
                                        {
                                            $table.Cell(0,$i).Range.Font.TextColor = (Color-NameToOfficeEnum "yellow")

                                            echo (Color-NameToOfficeEnum "yellow")
                                        }
                                        "orange"
                                        {
                                            $table.Cell(0,$i).Range.Font.TextColor = (Color-NameToOfficeEnum "orange")

                                            echo (Color-NameToOfficeEnum "orange")
                                        }
                                        default
                                        {
                                            $table.Cell(0,$i).Range.Font.TextColor = (Color-NameToOfficeEnum "black")

                                            echo (Color-NameToOfficeEnum "black")
                                        }
                                    }                                    
                                }
                                else
                                {
                                    $table.Cell(0,$i).Range.Font.TextColor = (Color-NameToOfficeEnum "black")

                                    echo "else case - $j,$i"
                                }
                            }

                            $table.Cell(0,$i).Range.ParagraphFormat.Alignment = [Microsoft.Office.Interop.Word.WdAlignmentTabAlignment]::wdCenter

                            $table.Cell(0,$i).Range.Text = $dataArr[$j,($i-1)]

                            echo "Just edited data cell '(0,$i)'"

                            #sleep 3

                            #echo $j,$i

                            #echo $dataArr[$j,$i-1]
                        }
                    }

                    #return $table
                }
                else
                {
                    write-host "ERROR! an invalid array was inserted! (func: Create-ANewTableInADocument, 3rd / 4th parameters)"
                }
            }
            else
            {
                write-host "ERROR! One or two of the given parameters is null and neither can be null! (func: Create-ANewTableInADocument, 3rd / 4th parameters)"
            }
        }
        else
        {
            write-host "ERROR! Wrong range object inserted to function! (func: Create-ANewTableInADocument, 2nd parameter)"

            return $false
        }
        
    }
    else
    {
        write-host "ERROR! Wrong doc object inserted to function! (func: Create-ANewTableInADocument, 1st parameter)"

        return $false
    }
}


function Design-ATableInADocumentUsing2DimsDataArray($docObj, $tableFirstCellLocationAsASelectionObj, $directionToUse, $numOfColumnsInTable, $numOfDataLinesInTable, $areHeadersBold, $areHeadersItalic, $headersTextColor, $headersBackgroundColor, $dataCellsColorsArr)
{
    if($docObj -ne $null -or $tableFirstCellLocationAsASelectionObj -ne $null)
    {
        if($docObj.gettype().fullname -eq "Microsoft.Office.Interop.Word.DocumentClass")
        {
            if($tableFirstCellLocationAsASelectionObj.gettype().fullname -eq "System.__ComObject")
            {
                if($dataCellsColorsArr -is [array])
                {
                    $doDataColors = $true
                }

                if($directionToUse -eq "right" -or $directionToUse -eq "left")
                {
                    $currentLocation = $tableFirstCellLocationAsASelectionObj

                    for($i=1; $i -le $numOfColumnsInTable; $i++)
                    {
                        $currentLocation.HomeKey([Microsoft.Office.Interop.Word.wdunits]::wdLine) | out-null
                        $currentLocation.EndKey([Microsoft.Office.Interop.Word.wdunits]::wdLine, [Microsoft.Office.Interop.Word.wdMovementType]::wdExtend) | out-null

                        $currentLocation.range.ParagraphFormat.Alignment = [Microsoft.Office.Interop.Word.WdAlignmentTabAlignment]::wdCenter

                        if($areHeadersBold -eq $true)
                        {
                            $currentLocation.range.BoldBi = $true
                        }

                        if($areHeadersItalic -eq $true)
                        {
                            $currentLocation.range.ItalicBi = $true
                        }

                        if($headersBackgroundColor -ne $null -and $headersBackgroundColor -ne "")
                        {
                            $currentLocation.Shading.Texture = [Microsoft.Office.Interop.Word.WdTextureIndex]::wdTextureNone
                            $currentLocation.Shading.ForegroundPatternColor = (Color-NameToOfficeEnum $headersBackgroundColor)
                            $currentLocation.range.ParagraphFormat.Shading.BackgroundPatternColor = (Color-NameToOfficeEnum $headersBackgroundColor)
                        }

                        if($headersTextColor -ne $null -and $headersTextColor -ne "")
                        {
                            $currentLocation.Range.Font.TextColor = (Color-NameToOfficeEnum $headersTextColor)
                        }

                        if($directionToUse -eq "right")
                        {
                            $currentLocation.MoveRight([Microsoft.Office.Interop.Word.wdunits]::wdCell, 1, [Microsoft.Office.Interop.Word.wdMovementType]::wdMove)
                        }
                        else
                        {
                            $currentLocation.MoveLeft([Microsoft.Office.Interop.Word.wdunits]::wdCell, 1, [Microsoft.Office.Interop.Word.wdMovementType]::wdMove)
                        }
                    }

                    if($doDataColors -eq $true)
                    {
                        $currentLocation = $tableFirstCellLocationAsASelectionObj
                        $currentLocation.MoveDown([Microsoft.Office.Interop.Word.wdunits]::wdLine, $i, [Microsoft.Office.Interop.Word.wdMovementType]::wdExtend)

                        $cellCounter = 1

                        for($i=0; $i -lt $numOfDataLinesInTable; $i++)
                        {
                            for($j=0; $j -lt $numOfColumnsInTable; $j++)
                            {
                                write-host "Currently working on cell #$cellCounter - ($i,$j)"

                                $currentLocation.HomeKey([Microsoft.Office.Interop.Word.wdunits]::wdLine) | out-null
                                $currentLocation.EndKey([Microsoft.Office.Interop.Word.wdunits]::wdLine, [Microsoft.Office.Interop.Word.wdMovementType]::wdExtend) | out-null

                                $currentLocation.Range.ParagraphFormat.Alignment = [Microsoft.Office.Interop.Word.WdAlignmentTabAlignment]::wdCenter

                                if($dataCellsColorsArr[$i,$j] -is [string])
                                {
                                    #'About to set the color {0} on cell ({1},{2}) ...' -f $dataCellsColorsArr[$i,$j],$i,$j
                                    'About to set the color {0} on cell #{1} ...' -f $dataCellsColorsArr[$i,$j],$cellCounter

                                    $currentLocation.Range.Font.TextColor = (Color-NameToOfficeEnum $dataCellsColorsArr[$i,$j])
                                }

                                # skip the last jump because the start location is already inside the first cell
                                if($i -ne ($numOfDataLinesInTable-1) -or $j -ne ($numOfColumnsInTable-1))
                                {
                                    if($directionToUse -eq "right")
                                    {
                                        write-host "moving right ..."
                                        $currentLocation.MoveRight([Microsoft.Office.Interop.Word.wdunits]::wdCell, 1, [Microsoft.Office.Interop.Word.wdMovementType]::wdMove) | out-null
                                    }
                                    else
                                    {
                                        $currentLocation.MoveLeft([Microsoft.Office.Interop.Word.wdunits]::wdCell, 1, [Microsoft.Office.Interop.Word.wdMovementType]::wdMove) | out-null
                                    }
                                }
                                
                                $cellCounter++
                            }
                        }
                    }
                    else
                    {
                        write-host "WARNING: will not process colors."
                    }
                }
                else
                {
                    write-host "ERROR! Wrong direction inserted to function! (func: Design-ATableInADocument, 3rd parameter)"

                    return $false        
                }
            }
            else
            {
                write-host "ERROR! Wrong range object inserted to function! (func: Design-ATableInADocument, 2nd parameter)"

                return $false
            }
        }
        else
        {
            write-host "ERROR! Wrong doc object inserted to function! (func: Design-ATableInADocument, 1st parameter)"

            return $false
        }
    }

}

function Design-ATableInADocument($docObj, $tableFirstCellLocationAsASelectionObj, $directionToUse, $numOfColumnsInTable, $numOfDataLinesInTable, $areHeadersBold, $areHeadersItalic, $headersTextColor, $headersBackgroundColor, $hashTableDataCellsColorsArr)
{
    if($docObj -ne $null -or $tableFirstCellLocationAsASelectionObj -ne $null)
    {
        if($docObj.gettype().fullname -eq "Microsoft.Office.Interop.Word.DocumentClass")
        {
            if($tableFirstCellLocationAsASelectionObj.gettype().fullname -eq "System.__ComObject")
            {
                write-host "About to design a table with dims of"$numOfColumnsInTable" x"($numOfDataLinesInTable+1)

                if($hashTableDataCellsColorsArr -is [Hashtable] -and $hashTableDataCellsColorsArr.count -gt 0)
                {
                    write-host "Colors will be processed for this table."
                    $doDataColors = $true
                }

                if($directionToUse -eq "right" -or $directionToUse -eq "left")
                {
                    $currentLocation = $tableFirstCellLocationAsASelectionObj

                    write-host "Designing headers ..."

                    for($i=1; $i -le $numOfColumnsInTable; $i++)
                    {
                        $currentLocation.HomeKey([Microsoft.Office.Interop.Word.wdunits]::wdLine) | out-null
                        $currentLocation.EndKey([Microsoft.Office.Interop.Word.wdunits]::wdLine, [Microsoft.Office.Interop.Word.wdMovementType]::wdExtend) | out-null

                        $currentLocation.range.ParagraphFormat.Alignment = [Microsoft.Office.Interop.Word.WdAlignmentTabAlignment]::wdCenter

                        if($areHeadersBold -eq $true)
                        {
                            $currentLocation.range.BoldBi = $true
                        }

                        if($areHeadersItalic -eq $true)
                        {
                            $currentLocation.range.ItalicBi = $true
                        }

                        if($headersBackgroundColor -ne $null -and $headersBackgroundColor -ne "")
                        {
                            $currentLocation.Shading.Texture = [Microsoft.Office.Interop.Word.WdTextureIndex]::wdTextureNone
                            $currentLocation.Shading.ForegroundPatternColor = (Color-NameToOfficeEnum $headersBackgroundColor)
                            $currentLocation.range.ParagraphFormat.Shading.BackgroundPatternColor = (Color-NameToOfficeEnum $headersBackgroundColor)
                        }

                        if($headersTextColor -ne $null -and $headersTextColor -ne "")
                        {
                            $currentLocation.Range.Font.TextColor = (Color-NameToOfficeEnum $headersTextColor)
                        }

                        if($directionToUse -eq "right")
                        {
                            $currentLocation.MoveRight([Microsoft.Office.Interop.Word.wdunits]::wdCell, 1, [Microsoft.Office.Interop.Word.wdMovementType]::wdMove)
                        }
                        else
                        {
                            $currentLocation.MoveLeft([Microsoft.Office.Interop.Word.wdunits]::wdCell, 1, [Microsoft.Office.Interop.Word.wdMovementType]::wdMove)
                        }
                    }

                    if($doDataColors -eq $true)
                    {
                        write-host "Designing colors ..."

                        $currentLocation = $tableFirstCellLocationAsASelectionObj
                        $currentLocation.MoveDown([Microsoft.Office.Interop.Word.wdunits]::wdLine, $i, [Microsoft.Office.Interop.Word.wdMovementType]::wdExtend)

                        $currentCellIndex = 0

                        for($i=0; $i -lt $numOfDataLinesInTable; $i++)
                        {
                            for($j=0; $j -lt $numOfColumnsInTable; $j++)
                            {
                                $currentLocation.HomeKey([Microsoft.Office.Interop.Word.wdunits]::wdLine) | out-null
                                $currentLocation.EndKey([Microsoft.Office.Interop.Word.wdunits]::wdLine, [Microsoft.Office.Interop.Word.wdMovementType]::wdExtend) | out-null

                                $currentLocation.Range.ParagraphFormat.Alignment = [Microsoft.Office.Interop.Word.WdAlignmentTabAlignment]::wdCenter

                                if(($hashTableDataCellsColorsArr.$currentCellIndex) -ne $null)
                                {
                                    #'About to set the color {0} on cell #{1} ...' -f ($hashTableDataCellsColorsArr.$currentCellIndex),($currentCellIndex+1)

                                    write-host "About to set the color"($hashTableDataCellsColorsArr.$currentCellIndex)" on cell "($currentCellIndex+1)" ..."

                                    $currentLocation.Range.Font.TextColor = (Color-NameToOfficeEnum ($hashTableDataCellsColorsArr.$currentCellIndex))

                                    #sleep 2
                                }
                                else
                                {
                                    #'The value of "`$hashTableDataCellsColorsArr.`$currentCellIndex" is: {0} (null) and this is unexpected.' -f ($hashTableDataCellsColorsArr.$currentCellIndex)
                                    write-host "The value of hashTableDataCellsColorsArr.$currentCellIndex is:"($hashTableDataCellsColorsArr.$currentCellIndex)"(null)"
                                }

                                # skip the last jump because the start location is already inside the first cell
                                if($i -ne ($numOfDataLinesInTable-1) -or $j -ne ($numOfColumnsInTable-1))
                                {
                                    if($directionToUse -eq "right")
                                    {
                                        "DEBUG: moving right once. current i (data lines) and j (column number) values are: {0},{1}" -f $i,$j

                                        $currentLocation.MoveRight([Microsoft.Office.Interop.Word.wdunits]::wdCell, 1, [Microsoft.Office.Interop.Word.wdMovementType]::wdMove) | out-null
                                    }
                                    else
                                    {
                                        $currentLocation.MoveLeft([Microsoft.Office.Interop.Word.wdunits]::wdCell, 1, [Microsoft.Office.Interop.Word.wdMovementType]::wdMove) | out-null
                                    }
                                }
                                
                                $currentCellIndex++
                            }
                        }
                    }
                    else
                    {
                        write-host "WARNING: will not process colors."
                    }
                }
                else
                {
                    write-host "ERROR! Wrong direction inserted to function! (func: Design-ATableInADocument, 3rd parameter)"

                    return $false                    
                }
            }
            else
            {
                write-host "ERROR! Wrong range object inserted to function! (func: Design-ATableInADocument, 2nd parameter)"

                return $false
            }
        }
        else
        {
            write-host "ERROR! Wrong doc object inserted to function! (func: Design-ATableInADocument, 1st parameter)"

            return $false
        }
    }
}


function Get-ALineOfTextFromADocument2($docObj, $pageNumber, $lineNumber)
{
    if($docObj.gettype().fullname -eq "Microsoft.Office.Interop.Word.DocumentClass")
    {
        if($pageNumber -eq "" -or $lineNumber -eq "")
        {
            write-host "ERROR! Wrong usage! one or two parameters are empty! (func: Get-ALineOfTextFromADocument2)"

            return $false
        }
        else
        {
            if($pageNumber -is [int] -and $lineNumber -is [int])
            {
                $loc = (Go-ToLocationInADocument $docObj $pageNumber $lineNumber)

                if($loc -ne $false)
                {
                    $selection = $msWord.selection

                    $range = $selection.expand([Microsoft.Office.Interop.Word.wdunits]::wdLine)

                    return $selection.text
                }
                else
                {
                    write-host "ERROR! An unexpected error occured! (func: Get-ALineOfTextFromADocument2)"

                    return $false
                }
            }
            else
            {
                write-host "ERROR! Wrong usage! 2nd and 3rd parameters must be numbers! (func: Get-ALineOfTextFromADocument2)"

                return $false                
            }
        }
    }
    else
    {
        write-host "ERROR! Wrong object inserted to function! (func: Get-ALineOfTextFromADocument2)"

        return $false
    }
}

function Get-ALineOfTextFromADocument($docObj, $pageNumber, $lineNumber)
{
    if($docObj.gettype().fullname -eq "Microsoft.Office.Interop.Word.DocumentClass")
    {
        if($pageNumber -eq "" -or $lineNumber -eq "")
        {
            write-host "ERROR! Wrong usage! one or two parameters are empty! (func: Get-ALineOfTextFromADocument)"

            return $false
        }
        else
        {
            $range = $docObj.ActiveWindow.Selection.GoTo([Microsoft.Office.Interop.Word.WdGoToItem]::wdGoToPage, [Microsoft.Office.Interop.Word.WdGoToDirection]::wdGoToFirst, $pageNumber)

            $selection = $msWord.selection

            $range = $selection.GoTo([Microsoft.Office.Interop.Word.WdGoToItem]::wdGoToLine, [Microsoft.Office.Interop.Word.WdGoToDirection]::wdGoToAbsolute, $lineNumber)

            $selection = $msWord.selection

            $range = $selection.HomeKey([Microsoft.Office.Interop.Word.wdunits]::wdLine)

            $range = $selection.MoveDown([Microsoft.Office.Interop.Word.wdunits]::wdLine, 1, [Microsoft.Office.Interop.Word.wdMovementType]::wdExtend)

            return $selection.text
        }
    }
    else
    {
        write-host "ERROR! Wrong object inserted to function! (func: Get-ALineOfTextFromADocument)"

        return $false
    }
}

function Get-OneWordFromADocument($docObj, $pageNumber, $lineNumber, $wordNumber)
{
    if($docObj.gettype().fullname -eq "Microsoft.Office.Interop.Word.DocumentClass")
    {
        if($pageNumber -eq "" -or $lineNumber -eq "" -or $wordNumber -eq "")
        {
            write-host "ERROR! Wrong usage! one or more parameters are empty! (func: Get-OneWordFromADocument)"

            return $false
        }
        else
        {
            if($pageNumber -is [int] -and $lineNumber -is [int] -and $wordNumber -is [int])
            {
                $line = (Get-ALineOfTextFromADocument $docObj $pageNumber $lineNumber)

                if($line -is [string])
                {
                    $wordsArr = $line.Split()

                    return $wordsArr[($wordNumber-1)]
                }
                else
                {
                    write-host "ERROR! An unexpected error occured! (func: Get-OneWordFromADocument, while calling 'Get-ALineOfTextFromADocument')"

                    return $false 
                }
            }
            else
            {
                write-host "ERROR! Wrong usage! 2nd, 3rd and 4th parameters must be numbers! (func: Get-OneWordFromADocument)"

                return $false                
            }
        }
    }
    else
    {
        write-host "ERROR! Wrong object inserted to function! (func: Get-ALineOfTextFromADocument)"

        return $false
    }
}
