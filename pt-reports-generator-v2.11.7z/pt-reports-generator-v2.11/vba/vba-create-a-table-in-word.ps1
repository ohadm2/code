﻿add-type -AssemblyName Microsoft.Office.Interop.Word

$msWord = New-Object -Com Word.Application
$msWord.visible = $true

$docReport = $msWord.Documents.Add("C:\temp\test-word-vba\pt-report-template.docx")

#$doc1 = $msWord.Documents.Add("C:\temp\test-word-vba\metadata-exposure.rtf")
#$doc2 = $msWord.Documents.Add("C:\temp\test-word-vba\no-client-side-validation.rtf")


$range = $docReport.ActiveWindow.Selection.GoTo([Microsoft.Office.Interop.Word.WdGoToItem]::wdGoToPage, [Microsoft.Office.Interop.Word.WdGoToDirection]::wdGoToFirst, 7)

$selection = $msWord.selection

$range = $selection.GoTo([Microsoft.Office.Interop.Word.WdGoToItem]::wdGoToLine, [Microsoft.Office.Interop.Word.WdGoToDirection]::wdGoToRelative, 3)

$selection = $msWord.selection

$docReport.Tables.Add($selection.range, 1, 3,[Microsoft.Office.Interop.Word.WdDefaultTableBehavior]::wdWord9TableBehavior, [Microsoft.Office.Interop.Word.WdAutoFitBehavior]::wdAutoFitFixed)

$tableSelection = $selection

$table = $docReport.Tables(1)

$table.Borders.Enable = $true

Start-Sleep -s 5

#$table.Cell(0,1).Shading.BackgroundPatternColor = [Microsoft.Office.Interop.Word.WdColor]::wdColorGray50
#$table.Cell(0,1).Range.Font.TextColor = [Microsoft.Office.Interop.Word.WdColor]::wdColorWhite
$table.Cell(0,1).Range.Font.Underline = $true
$table.Cell(0,1).Range.Font.Bold = $true
$table.Cell(0,1).Range.Font.Size = 14
$table.Cell(0,1).Range.Text = "מספר"

Start-Sleep -s 5

#$table.Cell(0,2).Shading.BackgroundPatternColor = [Microsoft.Office.Interop.Word.WdColor]::wdColorGray50
#$table.Cell(0,2).Range.Font.TextColor = [Microsoft.Office.Interop.Word.WdColor]::wdColorWhite
$table.Cell(0,2).Range.Font.Underline = $true
$table.Cell(0,2).Range.Font.Bold = $true
$table.Cell(0,3).Range.Font.Size = 14
$table.Cell(0,2).Range.Text = "תיאור הממצא"

Start-Sleep -s 5

$table.Cell(0,3).Range.Text = "רמת חומרה"
#$table.Cell(0,3).Shading.BackgroundPatternColor = [Microsoft.Office.Interop.Word.WdColor]::wdColorGray50
#$table.Cell(0,3).Range.Font.TextColor = [Microsoft.Office.Interop.Word.WdColor]::wdColorWhite
$table.Cell(0,3).Range.Font.Underline = $true
$table.Cell(0,3).Range.Font.Bold = $true
$table.Cell(0,3).Range.Font.Size = 14

#foreach($doc in $msWord.Documents)
#{
#    write-host $doc.name
#}

$findingsCounter=1

$rtfs = Get-ChildItem C:\temp\test-word-vba -File -Filter "*.rtf"

foreach($rtf in $rtfs)
{
    $doc = $msWord.Documents.Add($rtf.fullname)

    $range = $doc.ActiveWindow.Selection.GoTo([Microsoft.Office.Interop.Word.WdGoToItem]::wdGoToLine, [Microsoft.Office.Interop.Word.WdGoToDirection]::wdGoToRelative, 1)

    $selection = $msWord.selection

    $range = $selection.HomeKey([Microsoft.Office.Interop.Word.wdunits]::wdStory)

    $range = $selection.MoveDown([Microsoft.Office.Interop.Word.wdunits]::wdLine, 1, [Microsoft.Office.Interop.Word.wdMovementType]::wdExtend)

    $findingName = $selection.text

    echo $findingName

    $range = $doc.ActiveWindow.Selection.GoTo([Microsoft.Office.Interop.Word.WdGoToItem]::wdGoToLine, [Microsoft.Office.Interop.Word.WdGoToDirection]::wdGoToFirst, 2)

    $selection = $msWord.selection


    $range = $selection.MoveRight([Microsoft.Office.Interop.Word.wdunits]::wdWord, 4, [Microsoft.Office.Interop.Word.wdMovementType]::wdExtend)

    $words = $selection.text.Split()

    $findingSeverity = $words[2]

    #echo $findingSeverity

    $row = $tableSelection.InsertRowsBelow(1)

    # required for the data to arrive into word on time
    Start-Sleep -s 5

    $table.Cell(0,1).Range.Font.Underline = $false
    
    Start-Sleep -s 2

    $table.Cell(0,1).Range.text = [string]$findingsCounter
    
    # required for the data to arrive into word on time
    Start-Sleep -s 2
    
    $table.Cell(0,2).Range.Font.Underline = $false

    Start-Sleep -s 2

    $table.Cell(0,2).Range.text = [string]$findingName
    
    
    # required for the data to arrive into word on time
    Start-Sleep -s 2
    
    $table.Cell(0,3).Range.Font.Underline = $false

    Start-Sleep -s 2

    $table.Cell(0,3).Range.text = [string]$findingSeverity
    
    # required for the data to arrive into word on time
    Start-Sleep -s 2

    switch($findingSeverity)
    {
        "נמוכה"
        {
            $table.Cell(0,3).Range.Font.TextColor = [Microsoft.Office.Interop.Word.WdColor]::wdColorLightBlue
        }
        "בינונית"
        {
            $table.Cell(0,3).Range.Font.TextColor = [Microsoft.Office.Interop.Word.WdColor]::wdColorYellow
        }
        "גבוהה"
        {
            $table.Cell(0,3).Range.Font.TextColor = [Microsoft.Office.Interop.Word.WdColor]::wdColorRed
        }
    }

    # bug fix - without it the first number is not inserted to the table
    if($findingsCounter -eq 1)
    {
        $table.Cell(0,1).Range.text = [string]$findingsCounter
    }

    $findingsCounter++

    $doc.ActiveWindow.Close()
}