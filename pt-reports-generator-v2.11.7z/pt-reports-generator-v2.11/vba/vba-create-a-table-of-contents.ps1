﻿<#
Application.Templates( _
        "C:\Users\ohadm\AppData\Roaming\Microsoft\Document Building Blocks\1033\16\Built-In Building Blocks.dotx" _
        ).BuildingBlockEntries("Automatic Table 1").Insert Where:=Selection.Range _
        , RichText:=True

        ActiveDocument.TablesOfContents.Add _ 
 Range:=myRange, _ 
 UseFields:=False, _ 
 UseHeadingStyles:=True, _ 
 LowerHeadingLevel:=3, _ 
 UpperHeadingLevel:=1, _ 
 AddedStyles:="myStyle, yourStyle"

#>

function Go-ToLocationInADocument($docObj, $page, $line)
{
    if($docObj.gettype().fullname -eq "Microsoft.Office.Interop.Word.DocumentClass")
    {
        if($page -eq "" -or $line -eq "")
        {
            write-host "ERROR! Wrong usage! one or two parameters are empty! (func: Go-ToLocationInADocument)"

            return $false
        }
        else
        {
            $range = $docObj.ActiveWindow.Selection.GoTo([Microsoft.Office.Interop.Word.WdGoToItem]::wdGoToPage, [Microsoft.Office.Interop.Word.WdGoToDirection]::wdGoToFirst, $page)

            $selection = $msWord.selection

            $range = $selection.GoTo([Microsoft.Office.Interop.Word.WdGoToItem]::wdGoToLine, [Microsoft.Office.Interop.Word.WdGoToDirection]::wdGoToRelative, $line)

            $selection = $msWord.selection

            return $selection
        }
    }
    else
    {
        write-host "ERROR! Wrong object inserted to function! (func: Go-ToLocationInADocument)"

        return $false
    }
}

add-type -AssemblyName Microsoft.Office.Interop.Word

$msWord = New-Object -Com Word.Application
$msWord.visible = $true

$ptTemplate = "C:\temp\test-word-vba\pt-report-template.docx"

$doc = $msWord.Documents.Add("$ptTemplate")

$loc = (Go-ToLocationInADocument $doc 2 1)

#$toc = $msWord.Templates($env:USERPROFILE + "\Roaming\Microsoft\Document Building Blocks\1033\16\Built-In Building Blocks.dotx")

#$toc.BuildingBlockEntries("Automatic Table 1").Insert($loc, $true)


$toc = $doc.TablesOfContents.Add($loc.range)

#$msWord.ActiveDocument.TablesOfContents.Add($loc.range, $false, $true, 3 ,1)

$toc.update

