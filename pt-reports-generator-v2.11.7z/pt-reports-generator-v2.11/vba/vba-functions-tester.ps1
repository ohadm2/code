﻿# include a script
. ($PSScriptRoot + "\" + "vba-functions.ps1")

add-type -AssemblyName Microsoft.Office.Interop.Word

$msWord = New-Object -Com Word.Application
$msWord.visible = $true

$global:mainDoc = $msWord.Documents.Add("C:\temp\test-word-vba\pt-report-template.docx")

<#
$loc = (Go-ToLocationInADocument $global:mainDoc 6 12)

if($loc -ne $false)
{
    Write-TextInADocument $loc "testing 1 2 3 ..."| out-null
}


$loc = (Go-ToLocationInADocument $global:mainDoc 7 3)

if($loc -ne $false)
{
    Write-TextInADocument $loc "testing 1 2 3 #2 ..." | out-null
}



#>

$headersArr = (0..2)

$headersArr[2] = "מספר"
$headersArr[1] = "תיאור הממצא"
$headersArr[0] = "רמת חומרה"


$twoDimsDataArr = New-Object 'object[,]' 3,3

$twoDimsDataArr[0,2] = "1"
$twoDimsDataArr[0,1] = "בעיה 1"
$twoDimsDataArr[0,0] = "נמוכה"

$twoDimsDataArr[1,2] = "2"
$twoDimsDataArr[1,1] = "בעיה 2"
$twoDimsDataArr[1,0] = "בינונית"

$twoDimsDataArr[2,2] = "3"
$twoDimsDataArr[2,1] = "בעיה 3"
$twoDimsDataArr[2,0] = "גבוהה"


#$loc = (Go-ToLocationInADocument $global:mainDoc 8 9)

#Write-TextInADocument $loc "`n" | out-null
#Write-TextInADocument $loc "`n" | out-null

$dataCellsColorsArr = New-Object 'object[,]' 3,3

$dataCellsColorsArr[0,0] = "lightblue"
$dataCellsColorsArr[1,0] = "orange"
$dataCellsColorsArr[2,0] = "red"


#Create-ANewTableInADocumentWithStyle $global:mainDoc $loc $headersArr $twoDimsDataArr $true $true "black" 14 $dataCellsColorsArr


#$loc = (Go-ToLocationInADocument $global:mainDoc 8 5)

<#

#Write-TextInADocument $loc "sdsdsdsdsdsd" 

#$loc.HomeKey([Microsoft.Office.Interop.Word.wdunits]::wdStory)

$loc.HomeKey([Microsoft.Office.Interop.Word.wdunits]::wdLine)
$loc.EndKey([Microsoft.Office.Interop.Word.wdunits]::wdLine, [Microsoft.Office.Interop.Word.wdMovementType]::wdExtend)


$loc.range.BoldBi = $true
$loc.range.ParagraphFormat.Alignment = [Microsoft.Office.Interop.Word.WdAlignmentTabAlignment]::wdCenter
$loc.range.ParagraphFormat.Shading.BackgroundPatternColor = (Color-NameToOfficeEnum "gray")


$loc.MoveRight([Microsoft.Office.Interop.Word.wdunits]::wdCell, 1, [Microsoft.Office.Interop.Word.wdMovementType]::wdMove)


$loc.HomeKey([Microsoft.Office.Interop.Word.wdunits]::wdLine)

$loc.EndKey([Microsoft.Office.Interop.Word.wdunits]::wdLine, [Microsoft.Office.Interop.Word.wdMovementType]::wdExtend)


$loc.range.BoldBi = $true
$loc.range.ParagraphFormat.Alignment = [Microsoft.Office.Interop.Word.WdAlignmentTabAlignment]::wdCenter
$loc.range.ParagraphFormat.Shading.BackgroundPatternColor = (Color-NameToOfficeEnum "gray")
$loc.range.Parent.select().

.ParagraphFormat.Shading.BackgroundPatternColor = (Color-NameToOfficeEnum "gray")

$loc.MoveRight([Microsoft.Office.Interop.Word.wdunits]::wdCell, 1, [Microsoft.Office.Interop.Word.wdMovementType]::wdMove)


$loc.HomeKey([Microsoft.Office.Interop.Word.wdunits]::wdLine)
$loc.EndKey([Microsoft.Office.Interop.Word.wdunits]::wdLine, [Microsoft.Office.Interop.Word.wdMovementType]::wdExtend)


$loc.range.BoldBi = $true
$loc.range.ParagraphFormat.Alignment = [Microsoft.Office.Interop.Word.WdAlignmentTabAlignment]::wdCenter
$loc.range.ParagraphFormat.Shading.BackgroundPatternColor = (Color-NameToOfficeEnum "gray")



$loc = (Go-ToLocationInADocument $global:mainDoc 8 5)

Create-ANewTableInADocumentUsing2DimsDataArray $global:mainDoc $loc $headersArr $twoDimsDataArr

$loc = (Go-ToLocationInADocument $global:mainDoc 8 5)

if($loc -ne $false)
{
    Design-ATableInADocument $global:mainDoc $loc "right" 3 3 $true $false "black" "gray" $dataCellsColorsArr
}

#>

write-host (Get-ALineOfTextFromADocument $global:mainDoc 5 1)