﻿# include a script
. ($PSScriptRoot + "\" + "vba-functions.ps1")

add-type -AssemblyName Microsoft.Office.Interop.Word

$msWord = New-Object -Com Word.Application
$msWord.visible = $true

$ptTemplate = "C:\temp\test-word-vba\pt-report-template.docx"

$doc = $msWord.Documents.Add("$ptTemplate")

$loc = (Go-ToLocationInADocument $doc 2 1)

if($loc -ne $false)
{
    #Write-TextInADocument $loc "`n" | out-null

    Write-TextInADocument $loc "this is a bookmark test link"

    $selection = $msWord.Selection

    $selection.HomeKey([Microsoft.Office.Interop.Word.wdunits]::wdLine)

    $selection.EndKey([Microsoft.Office.Interop.Word.wdunits]::wdLine, [Microsoft.Office.Interop.Word.wdMovementType]::wdExtend)
    

    $msWord.ActiveDocument.Hyperlinks.Add($selection.Range, "", "bookmark_name", "", $selection.Text)
}

<#
 ActiveDocument.Hyperlinks.Add Anchor:=Selection.Range, Address:="", _
        SubAddress:="dfdf" & ChrW(1490) & ChrW(1499) & ChrW(1490) & ChrW(1490) & _
        ChrW(1499), ScreenTip:="", TextToDisplay:=ChrW(1502) & ChrW(1495) & ChrW( _
        1489) & ChrW(1512)
#>