﻿add-type -AssemblyName Microsoft.Office.Interop.Word

$msWord = New-Object -Com Word.Application

$msWord.visible = $true

$doc = $msWord.Documents.Add("C:\temp\test-word-vba\metadata-exposure.rtf")

$range = $doc.ActiveWindow.Selection.GoTo([Microsoft.Office.Interop.Word.WdGoToItem]::wdGoToLine, [Microsoft.Office.Interop.Word.WdGoToDirection]::wdGoToFirst, 2)

$selection = $msWord.selection


$range = $selection.MoveRight([Microsoft.Office.Interop.Word.wdunits]::wdWord, 4, [Microsoft.Office.Interop.Word.wdMovementType]::wdExtend)

$tokens = $selection.text.Split()

echo $tokens[2]