﻿add-type -AssemblyName Microsoft.Office.Interop.Word

$msWord = New-Object -Com Word.Application
$msWord.visible = $true

$docSource = $msWord.Documents.Add("C:\temp\test-word-vba\metadata-exposure.rtf")

#$docSource.ActiveWindow.Selection.GoTo([Microsoft.Office.Interop.Word.WdGoToItem]::wdGoToBookmark, [Microsoft.Office.Interop.Word.WdGoToDirection]::wdGoToRelative, 1) | Out-Null

$selection = $msWord.selection

write-host $selection.Bookmarks.Count

write-host $selection.Bookmarks(1).Name