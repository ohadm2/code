function Show-OpenFolderDialog
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true, Position=0)]
        [system.windows.Forms.TextBox]
        $txtBoxObj,
         
        [Parameter(Mandatory=$false, Position=1)]
        [Object]
        $InitialDirectory = "."
    )
     
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.SelectedPath = $InitialDirectory

    if ($dialog.ShowDialog() -eq "ok")
    {
        $txtBoxObj.text = $dialog.SelectedPath
    }
    else
    {
        #Throw 'Nothing selected.'   
    }
}

function Check-Content
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true, Position=0)]
        [System.String]
        $folderToWorkOn,
        [Parameter(Mandatory=$true, Position=1)]
        [string]
        $wordsListFileSpec,
        [Parameter(Mandatory=$true, Position=2)]
        [string]
        $stdoutLogFileSpec,
        [Parameter(Mandatory=$true, Position=3)]
        [string]
        $stderrLogFileSpec
    )
    
    $status = test-path $folderToWorkOn

    if ($status -ne $true)
    {
        [System.Windows.MessageBox]::Show('Error! The path defined in the variable "$folderToWorkOn" is invalid! Please correct and run again.')
    }
    else
    {
        $isFolder = (Get-Item $folderToWorkOn -ErrorAction SilentlyContinue) -is [System.IO.DirectoryInfo]

        if($isFolder -eq $true)
        {
            $status = test-path $wordsListFileSpec

            if ($status -ne $true)
            {
                [System.Windows.MessageBox]::Show('Error! The term defined in the variable "$wordsListFileSpec" is NOT a valid file! Please correct and run again.')
            }
            else
            {
                Add-Type -AssemblyName System.Web

                $mimeType = [System.Web.MimeMapping]::GetMimeMapping($wordsListFileSpec)
                
                if($mimeType -eq "text/plain")
                {
                    $tempErrorLog = $PSScriptRoot + "\content-checker-error-" + (Get-Random) + ".txt"
                    $tempOutputLog = $PSScriptRoot + "\content-checker-output-" + (Get-Random) + ".txt"

                    $grepToolCmd = "`"" + $PSScriptRoot + "\tools\grep.exe`""
                    $grepToolGeneralArgs = "-iRn"
                    
                    $findToolCmd = "`"" + $PSScriptRoot + "\tools\find.exe`""
                    $findToolGeneralArgs = ". -name"
                    
                    
                    $wordsRegexLine = ""
                    $findCmdWordsLine = ""

                    $lines = Get-Content $wordsListFileSpec
                    $numOfLines = $lines.count
                    $i = 1

                    foreach ($line in $lines)
                    {
                        if($i -lt $numOfLines)
                        {
                            $wordsRegexLine = $wordsRegexLine + $line + "\|"
                            $findCmdWordsLine = $findCmdWordsLine + "`"*" + $line + "*`"" + " -or -name "
                        }
                        else
                        {
                            $wordsRegexLine = $wordsRegexLine + $line
                            $findCmdWordsLine = $findCmdWordsLine + "`"*" + $line + "*`""
                        }

                        $i++
                    }

                    $grepToolArgs = $grepToolGeneralArgs + " `"" + $wordsRegexLine + "`" ."
                    $findToolArgs = $findToolGeneralArgs + " " + $findCmdWordsLine

                    $btnFind.Enabled = $false

                    start-process $findToolCmd -argumentlist $findToolArgs -WorkingDirectory $folderToWorkOn -RedirectStandardError $tempErrorLog -RedirectStandardOutput $tempOutputLog -NoNewWindow -Wait
                    
                    Get-Content $tempErrorLog | Out-File $stderrLogFileSpec -Append
                    Get-Content $tempOutputLog | Out-File $stdoutLogFileSpec -Append
                    
                    start-process $grepToolCmd -argumentlist $grepToolArgs -WorkingDirectory $folderToWorkOn -RedirectStandardError $tempErrorLog -RedirectStandardOutput $tempOutputLog -NoNewWindow -Wait

                    echo "$grepToolArgs ; $folderToWorkOn"

                    Get-Content $tempErrorLog | Out-File $stderrLogFileSpec -Append
                    Get-Content $tempOutputLog | Out-File $stdoutLogFileSpec -Append

                    $btnFind.Enabled = $true

                    del $tempErrorLog
                    del $tempOutputLog
                }
                else
                {
                    [System.Windows.MessageBox]::Show('Error! The file defined in the variable "$wordsListFileSpec" must be a simple text file and it is not. Please correct and try again.')
                }
            }
        }
        else
        {
            [System.Windows.MessageBox]::Show('Error! The path defined in the variable "$folderToWorkOn" is NOT a valid folder! Please correct and run again.')
        }
    }
}

Add-Type -AssemblyName System.Windows.Forms

$wordsListFile = $PSScriptRoot + "\wordsList.txt"

$frmContentChecker = New-Object system.Windows.Forms.Form
$frmContentChecker.Text = "Sensitive Data Finder (using grep) v1.1"
$frmContentChecker.BackColor = "#4396eb"
$frmContentChecker.TopMost = $true
$frmContentChecker.Width = 819
$frmContentChecker.Height = 270

$lblPath = New-Object system.windows.Forms.Label
$lblPath.Text = "    Local path to work on:"
$lblPath.AutoSize = $true
$lblPath.ForeColor = "#fbfbfb"
$lblPath.Width = 25
$lblPath.Height = 10
$lblPath.location = new-object system.drawing.point(1,1)
$lblPath.Font = "Microsoft Sans Serif,14"
$lblPath.Left = 8
$lblPath.Top = 22

$global:txtPath = New-Object system.windows.Forms.TextBox
$txtPath.Width = 460
$txtPath.Height = 23
$txtPath.location = new-object system.drawing.point(1,1)
$txtPath.Left = $lblPath.Left + $lblPath.Width + 190
$txtPath.Top = $lblPath.Top + 2
$txtPath.Text = ""
$txtPath.AutoCompleteMode = 'SuggestAppend'
$txtPath.AutoCompleteSource = [System.Windows.Forms.AutoCompleteSource]::FileSystemDirectories
$txtPath.Font = "Microsoft Sans Serif,10,style=Bold"

$txtPath.Add_TextChanged({
    if ($txtPath.Text -ne "")
    {
        if((test-path $txtPath.Text) -eq $true)
        {
            $btnFind.Enabled = $true
            $btnFind.ForeColor = [System.Drawing.Color]::White
            $btnFind.BackColor = [System.Drawing.Color]::LightBlue
        }
        else
        {
            $btnFind.Enabled = $false
            $btnFind.ForeColor = [System.Drawing.Color]::Black
            $btnFind.BackColor = [System.Drawing.Color]::Gray
        }
    }
    else
    {
        $btnFind.Enabled = $false
        $btnFind.ForeColor = [System.Drawing.Color]::Black
        $btnFind.BackColor = [System.Drawing.Color]::Gray
    }
})

$btnBrowse = New-Object system.windows.Forms.Button
$btnBrowse.Text = "Browse"
$btnBrowse.Width = 70
$btnBrowse.Height = 24
$btnBrowse.ForeColor = [System.Drawing.Color]::Black
$btnBrowse.BackColor = [System.Drawing.Color]::WhiteSmoke
$btnBrowse.location = new-object system.drawing.point(1,1)
$btnBrowse.Left = $txtPath.Left + $txtPath.Width + 2
$btnBrowse.Top = $lblPath.Top + 1

$btnBrowse.Font = "Microsoft Sans Serif,10"

$btnBrowse.Add_Click({
    Show-OpenFolderDialog $txtPath
})


$fraPath = New-Object System.Windows.Forms.GroupBox
$fraPath.Text = "Select a path"
$fraPath.ForeColor = "#FFCB87"
$fraPath.Width = 760
$fraPath.Height = 70
$fraPath.location = new-object system.drawing.point(30,22)
$fraPath.Font = "Microsoft Sans Serif,14"

$fraPath.controls.Add($lblPath)
$fraPath.controls.Add($txtPath)
$fraPath.controls.Add($btnBrowse)

$frmContentChecker.controls.Add($fraPath)

$btnFind = New-Object system.windows.Forms.Button
$btnFind.Text = "Find"
$btnFind.Enabled = $false
$btnFind.Width = 500
$btnFind.Height = 69

$btnFind.Add_Click({
    if ( -not $txtPath.text -eq "")
    {
        $path = $txtPath.text

        #write-host $url
    }
    else
    {
        $path = Get-Clipboard
    }

    if ($path -ne "" -and $path -ne $null)
    {
        $result = Test-Path $path

        if ($result -eq $true)
        {
            cd $path
            
            $dateSuffix = Get-Date -format dd-MM-yy_hh-mm-ss

            Check-Content $path $wordsListFile $PSScriptRoot\report-$dateSuffix.txt $PSScriptRoot\error-$dateSuffix.txt

            start-process "explorer" -ArgumentList "$PSScriptRoot"
        }
        else
        {
            [System.Windows.MessageBox]::Show('Error! The given text is NOT a valid Path!')   
        }
    }
    else
    {
        # show a msgbox: 
        [System.Windows.MessageBox]::Show('Error! Cound not find a valid path to work on!')
    }
})

#$global:btnFind.location = new-object system.drawing.point(1,1)
$btnFind.Font = "Microsoft Sans Serif,14,style=Bold"
$btnFind.ForeColor = [System.Drawing.Color]::Black
$btnFind.BackColor = [System.Drawing.Color]::Gray
$btnFind.Left = 140
$btnFind.Top = 25

$fraScan = New-Object System.Windows.Forms.GroupBox
$fraScan.Text = "Find Content"
$fraScan.ForeColor = "#FFCB87"
$fraScan.Width = 760
$fraScan.Height = 110
$fraScan.location = new-object system.drawing.point(30,98)
$fraScan.Font = "Microsoft Sans Serif,14"

$fraScan.controls.Add($btnFind)
$frmContentChecker.controls.Add($fraScan)


[void]$frmContentChecker.ShowDialog()
$frmContentChecker.Dispose()