param (
   [string]$fileOrFolderToExtract = ""
)

# include a script
. ($PSScriptRoot + "\" + "myFunctionsV1.1.ps1")

Add-Type -AssemblyName "System.Web"

$usageInfo = "Usage: " + $MyInvocation.MyCommand.Name + " <file-or-folder-to-extract>"

if($fileOrFolderToExtract -ne "")
{
    $status = Test-Path $fileOrFolderToExtract

    if($status -eq $true)
    {
        Find-AndExtractInnerArchiveFiles $fileOrFolderToExtract $global:glbSupportedArchiveTypesList

        $fsObj = get-item $fileOrFolderToExtract

        if (($fsObj.Attributes) -eq "Directory")
        {
            $loc = $fileOrFolderToExtract
        }
        else
        {
            $loc = ($fsObj.Directory)
        }

        start-process "explorer" -ArgumentList "$loc"
    }
    else
    {
        echo 'Error! The given text is NOT a valid Path!'
    }
}
else
{
    echo $usageInfo
}
