function Show-OpenFolderDialog
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true, Position=0)]
        [system.windows.Forms.TextBox]
        $txtBoxObj,
         
        [Parameter(Mandatory=$false, Position=1)]
        [Object]
        $InitialDirectory = "."
    )
     
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.SelectedPath = $InitialDirectory
    $dial

    if ($dialog.ShowDialog() -eq "ok")
    {
        $txtBoxObj.text = $dialog.SelectedPath
    }
    else
    {
        #Throw 'Nothing selected.'   
    }
}

function Extract-Content
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true, Position=0)]
        [System.String]
        $folderOrFileToWorkOn
    )
    
    $status = test-path $folderOrFileToWorkOn

    if ($status -ne $true)
    {
        [System.Windows.MessageBox]::Show('Error! The given path is invalid! Please correct it and run again.')
    }
    else
    {
        Find-AndExtractInnerArchiveFiles $folderOrFileToWorkOn $global:glbSupportedArchiveTypesList
    }
}

# include a script
. ($PSScriptRoot + "\" + "myFunctionsV1.1.ps1")

Add-Type -AssemblyName System.Windows.Forms

$frmContentChecker = New-Object system.Windows.Forms.Form
$frmContentChecker.Text = "Content Extractor v1.0"
$frmContentChecker.BackColor = "#4396eb"
$frmContentChecker.TopMost = $true
$frmContentChecker.Width = 819
$frmContentChecker.Height = 270

$lblPath = New-Object system.windows.Forms.Label
$lblPath.Text = " File or folder to work on:"
$lblPath.AutoSize = $true
$lblPath.ForeColor = "#fbfbfb"
$lblPath.Width = 25
$lblPath.Height = 10
$lblPath.location = new-object system.drawing.point(1,1)
$lblPath.Font = "Microsoft Sans Serif,14"
$lblPath.Left = 8
$lblPath.Top = 22

$global:txtPath = New-Object system.windows.Forms.TextBox
$txtPath.Width = 460
$txtPath.Height = 23
$txtPath.location = new-object system.drawing.point(1,1)
$txtPath.Left = $lblPath.Left + $lblPath.Width + 190
$txtPath.Top = $lblPath.Top + 2
$txtPath.Text = ""
$txtPath.AutoCompleteMode = 'SuggestAppend'
$txtPath.AutoCompleteSource = [System.Windows.Forms.AutoCompleteSource]::AllSystemSources
$txtPath.Font = "Microsoft Sans Serif,10,style=Bold"

$txtPath.Add_TextChanged({
    if ($txtPath.Text -ne "")
    {
        if((test-path $txtPath.Text) -eq $true)
        {
            $btnExtract.Enabled = $true
            $btnExtract.ForeColor = [System.Drawing.Color]::White
            $btnExtract.BackColor = [System.Drawing.Color]::LightBlue
        }
        else
        {
            $btnExtract.Enabled = $false
            $btnExtract.ForeColor = [System.Drawing.Color]::Black
            $btnExtract.BackColor = [System.Drawing.Color]::Gray
        }
    }
    else
    {
        $btnExtract.Enabled = $false
        $btnExtract.ForeColor = [System.Drawing.Color]::Black
        $btnExtract.BackColor = [System.Drawing.Color]::Gray
    }
})

$btnBrowse = New-Object system.windows.Forms.Button
$btnBrowse.Text = "Browse"
$btnBrowse.Width = 70
$btnBrowse.Height = 24
$btnBrowse.ForeColor = [System.Drawing.Color]::Black
$btnBrowse.BackColor = [System.Drawing.Color]::WhiteSmoke
$btnBrowse.location = new-object system.drawing.point(1,1)
$btnBrowse.Left = $txtPath.Left + $txtPath.Width + 2
$btnBrowse.Top = $lblPath.Top + 1

$btnBrowse.Font = "Microsoft Sans Serif,10"

$btnBrowse.Add_Click({
    Show-OpenFolderDialog $txtPath
})


$fraPath = New-Object System.Windows.Forms.GroupBox
$fraPath.Text = "Select a file or a folder"
$fraPath.ForeColor = "#FFCB87"
$fraPath.Width = 760
$fraPath.Height = 70
$fraPath.location = new-object system.drawing.point(30,22)
$fraPath.Font = "Microsoft Sans Serif,14"

$fraPath.controls.Add($lblPath)
$fraPath.controls.Add($txtPath)
$fraPath.controls.Add($btnBrowse)

$frmContentChecker.controls.Add($fraPath)

$btnExtract = New-Object system.windows.Forms.Button
$btnExtract.Text = "Extract"
$btnExtract.Enabled = $false
$btnExtract.Width = 500
$btnExtract.Height = 69

$btnExtract.Add_Click({
    if ( -not $txtPath.text -eq "")
    {
        $path = $txtPath.text

        #write-host $url
    }
    else
    {
        $path = Get-Clipboard
    }

    if ($path -ne "" -and $path -ne $null)
    {
        $result = Test-Path $path

        if ($result -eq $true)
        {
            $fsObj = get-item $path

            if (($fsObj.Attributes) -eq "Directory")
            {
                $loc = $path
            }
            else
            {
                $loc = ($fsObj.Directory)
            }
            
            #$dateSuffix = Get-Date -format dd-MM-yy_hh-mm-ss

            Extract-Content $path

            start-process "explorer" -ArgumentList "$loc"
        }
        else
        {
            [System.Windows.MessageBox]::Show('Error! The given text is NOT a valid Path!')   
        }
    }
    else
    {
        # show a msgbox: 
        [System.Windows.MessageBox]::Show('Error! Cound not find a valid path to work on!')
    }
})

#$global:btnExtract.location = new-object system.drawing.point(1,1)
$btnExtract.Font = "Microsoft Sans Serif,14,style=Bold"
$btnExtract.ForeColor = [System.Drawing.Color]::Black
$btnExtract.BackColor = [System.Drawing.Color]::Gray
$btnExtract.Left = 140
$btnExtract.Top = 25

$fraScan = New-Object System.Windows.Forms.GroupBox
$fraScan.Text = "Find Content"
$fraScan.ForeColor = "#FFCB87"
$fraScan.Width = 760
$fraScan.Height = 110
$fraScan.location = new-object system.drawing.point(30,98)
$fraScan.Font = "Microsoft Sans Serif,14"

$fraScan.controls.Add($btnExtract)
$frmContentChecker.controls.Add($fraScan)


[void]$frmContentChecker.ShowDialog()
$frmContentChecker.Dispose()