﻿
$global:glbSupportedExtensions = "sln,csproj,cs,xaml,cshtml,javasln,project,java,jsp,jspf,xhtml,jsf,tld,tag,mf,js,html,htm,apex,apexp,page,component,cls,trigger,tgr,object,report,workflow,-metaxml,cpp,c++,cxx,hpp,hh,h++,hxx,c,cc,h,vb,vbs,asp,bas,frm,cls,dsr,ctl,vb,vbp,php,php3,php4,php5,phtm,phtml,tpl,ctp,twig,rb,rhtml,rxml,rjs,erb,lock,pl,pm,plx,psgi,m,h,xib,pls,sql,pkh,pks,pkb,pck,py,gtl,groovy,gsh,gvy,gy,gsp,properties,aspx,asax,ascx,master,config,xml,cgi,inc,ts"
$global:glbSupportedMimeTypes = "text/plain,text/html,application/x-javascript,application/x-zip-compressed,application/octet-stream,application/x-gzip,application/x-tar,application/x-compressed"        
$global:glbSupportedArchiveTypesList = "zip,rar,tar,gz,bz2,tgz,7z"
$global:glbPasswordsList = "1234,1,123,12345,123456,111,123123,2468,321,12,1234567,12345678,1111,2222"

$global:glb7zipBinaryFileSpec = "$PSScriptRoot" + "\7zip\7z.exe"
$global:glbCxzipBinaryFileSpec = "$PSScriptRoot" + "\cxzip\cxzip.exe"


function Find-AndExtractInnerArchiveFiles($contentLocation, $supportedArchiveTypesList)
{
    # these files are ignored
    $excludeList = "fixtures.tar"

    $status = test-path $contentLocation

    if($status -eq $true)
    {
        $filter = @()
        $extList = $supportedArchiveTypesList.split(",")

        foreach($ext in $extList)
        {
            $extToAdd = "*." + $ext
            $filter += $extToAdd
        }

        # get-childitem -recurse -path .\Desktop -file -include *.zip, *.rar
        $archiveFilesList = (get-childitem -recurse -path $contentLocation -file -include $filter)

        $numOfFilesFound = $archiveFilesList.count

        if($numOfFilesFound -gt 0)
        {
            write-host "Found $numOfFilesFound inner file(s) to extract!"

            $app = $global:glb7zipBinaryFileSpec

            $status = test-path $app
                
            if($status -eq $true)
            {
                if (((& $app) | Where-Object {$_ -Like "*Igor Pavlov*"}) -eq $null)
                {
                    write-host "ERROR! Could not find '7z.exe' inside the path '$app'!"

                    return $false
                }
                else
                {
                    foreach($file in $archiveFilesList)
                    {
                        $extractedArchiveLocation = $contentLocation + "\" + $file.name + "-" + (Generate-ARandomString 8)

                        $fileSpec = $file.fullname

                        if($excludeList.Contains($file.name.ToLower()) -eq $false)
                        {
                            $isValidArchiveFile = (Is-ValidArchiveFile $fileSpec $supportedArchiveTypesList)

                            if($isValidArchiveFile -eq $true)
                            {
                                mkdir $extractedArchiveLocation | out-null

                                $isEncrypted = (Is-APasswordProtectedArchiveFile $fileSpec $supportedArchiveTypesList)

                                if($isEncrypted -eq $true)
                                {
                                    Try-ToExtractAPasswordProtectedArchiveFile $fileSpec $supportedArchiveTypesList $global:glbPasswordsList $extractedArchiveLocation    
                                }
                                else
                                {
                                    write-host "Extracting the inner archive $fileSpec to destination $extractedArchiveLocation ..."
                                    # Extract the rar archive
                                    & $app "x" "$fileSpec" "-o$extractedArchiveLocation" | Out-Null
                                }

                                remove-item $fileSpec

                                # recursive call on the new folder in case there is another archive file inside the freshly extracted one and in case the archive is dual - e.g tar.gz etc.
                                Find-AndExtractInnerArchiveFiles $extractedArchiveLocation $supportedArchiveTypesList
                            }
                        }
                        else
                        {
                            write-host "INFO: Skipping a file named '$($file.name)' because it was found inside the exclude list."

                            return $true
                        }
                    }
                }
            }
            else
            {
                write-host "ERROR! Could not find '7z.exe' inside the path '$app'!"

                return $false
            }
        }
    }
    else
    {
        write-host "ERROR! The given 1st argument is an invalid path! (func: Find-AndExtractInnerArchiveFiles)"

        return $false
    }
}


function Create-ANewZipArchive
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true, Position=0)]
        [System.String]
        $fileOrFolderToCompress,

        [Parameter(Mandatory=$true, Position=1)]
        [System.String]
        $destDir
    )

    $app = $global:glb7zipBinaryFileSpec

    $status = test-path $app
                
    if($status -eq $true)
    {
        if (((& $app) | Where-Object {$_ -Like "*Igor Pavlov*"}) -eq $null)
        {
            write-host "ERROR! Could not find '7z.exe' inside the path '$app'!"
        }
        else
        {
            $tempDestLoc = Get-Item $destDir

            $fileOrFolderToCompressObj = get-childitem -Recurse -File $fileOrFolderToCompress

            if($fileOrFolderToCompressObj.count -gt 0)
            {
                if($tempDestLoc.count -gt 0)
                {
                    write-host "The given destination directory '$destDir' is not empty. Creating a random sub directory inside it to make sure that only the input files will be compressed."

                    cd $destDir

                    $destName = [io.path]::GetFileNameWithoutExtension("$fileOrFolderToCompress")

                    $tempDestLoc = mkdir ($destName + "-" + (Generate-ARandomString 8))
                }

                cd $tempDestLoc

                $zipFileName = $destName + "-" + (Generate-ARandomString 8) + ".zip"

                # Zip the extracted folder
                & $app "a" "$fileOrFolderToCompress" "$zipFileName"

                if((Check-IfAStringReffersToASupportedFile "$zipFileName" "application/x-zip-compressed") -eq $true -and (get-item $zipFileName).Length -gt 0)
                {
                    return "$tempDestLoc\$zipFileName"
                }
                else
                {
                    write-host "ERROR! Something went wrong while trying to create the Zip archive (func: Create-ANewZipArchive)."

                    return $false
                }
            }
            else
            {
                write-host "ERROR! The given input is either an empty directory or an empty file (func: Create-ANewZipArchive)."
                    
                return $false   
            }
        }
    }
    else
    {
        write-host "ERROR! Could not find '7z.exe' inside the path '$app' (func: Create-ANewZipArchive)!"

        return $false
    }
}


function Is-APhpScriptFile($fileSpec)
{
    $status = ""
    
    $status = Select-String -Path $fileSpec -Pattern "<\?|\?>"

    if($status -ne "")
    {
        return $true
    }
    else
    {
        return $false
    }
}


function Verify-ContentBeforeScanning
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true, Position=0)]
        [System.String]
        $contentLocation,
        
        [Parameter(Mandatory=$true, Position=1)]
        [System.String]
        $supportedFormatsList
    )

    write-host "Verifying content before scanning ..."

    $items = Get-ChildItem -File -Recurse $contentLocation

    $numOfFiles = $items.count

    $numOfFilesLeftToProcess = $numOfFiles
    $status = $false
    $i = 0

    $numOfScannableFiles = 0

    while($numOfFilesLeftToProcess -gt 0)
    {
        $item = $items[$i++]

        $ext = $item.extension.ToLower()

        if($ext -ne "")
        {
            if(Is-SupportedFileFormat ($ext -replace '\.','') $supportedFormatsList)
            {
                $numOfScannableFiles++
            }
            else
            {
                # a fix for drupal extentions
                if($item.extension.ToLower() -eq ".inc" -or $item.extension.ToLower() -eq ".module" -or $item.extension.ToLower() -eq ".install")
                {
                    if((Is-APhpScriptFile $item.FullName))
                    {
                        $name = $item.FullName

                        Move-Item $item.FullName $name".php"

                        $numOfScannableFiles++
                    }
                }
            }
        }

        $numOfFilesLeftToProcess--
    }

    # renaming non-english folder names

    $folders = Get-ChildItem -Directory -Recurse $contentLocation

    foreach($folder in $folders)
    {
        $folderName = $folder.name

        if((Does-ThisStringContainsCharsInLanguagesOtherThanEnglish $folderName) -eq $true)
        {
            write-host "The folder '$folderName' contains chars that are unsupported by Checkmarx."
            Write-Host "Renaming the folder ..."

            rename-item ($folder.fullname) ((($folder.Parent).fullname) + "\renamed-" + (Generate-ARandomString 8))
        }
    }

    $outputArr = @($numOfFiles, $numOfScannableFiles)

    return $outputArr
}


function Send-AFolderToCheckmarx($cxRunningScriptFileSpec, $username, $password, $cxServerURL, $projectPathInsideServer, $projectName, $folderPathToScan, $commaSeparatedListOfFoldersOrPatternsToExcludeFromSASTscan, $deleteFolderAfter) {
    if((test-path $cxRunningScriptFileSpec) -ne $true)
    {
        write-host "ERROR! The path given in the 1st argument (which was: '$cxRunningScriptFileSpec') is invalid! It must be a valid path the cx script. (func: Send-AFolderToCheckmarx)"

        return $false
    }
    else
    {
        if($cxServerURL -eq "" -or $projectPathInsideServer -eq "" -or $projectName -eq "" -or $folderPathToScan -eq "")
        {
            write-host "ERROR! One or more of the mandatory aruments (4-7) is/are empty! (func: Send-AFolderToCheckmarx)"

            return $false
        }
        else
        {
            $fullProjectName = "$projectPathInsideServer\$projectName"
    
            $outputDest = (get-item $folderPathToScan).parent

            $date = (get-date -uFormat "%d-%m-%Y")

            if($username -ne "" -and $password -ne "")
            {
                $authPart = "-cxuser $username -cxpassword $password"
            }
            else
            {
                $authPart = "-usesso"
            }

            $reportsDir = "$PSScriptRoot\reports"

            $status = Test-Path "$reportsDir"

            if($status -ne $true)
            {
                mkdir $reportsDir | out-null
            }
            else
            {
                $fsObj = get-item $reportsDir

                if (($fsObj.Attributes) -ne "Directory")
                {
                    # something is wrong - use the scripts root dir to save reports
                    $reportsDir = $PSScriptRoot
                }
            }
			
			# for older versions:
            #$args = "/c `"`"$cxRunningScriptFileSpec`" scan -enableosa -osareportpdf `"$reportsDir`" -reportpdf `"$reportsDir\$projectName-$date.pdf`" -v $authPart -projectname $fullProjectName -cxserver $cxServerURL -locationtype folder -locationpath `"$folderPathToScan`" -locationpathexclude `"$commaSeparatedListOfFoldersOrPatternsToExcludeFromSASTscan`"`""
			
			$args = "/c `"`"$cxRunningScriptFileSpec`" scan -enableosa -reportpdf `"$reportsDir\$projectName-$date.pdf`" -v $authPart -projectname $fullProjectName -cxserver $cxServerURL -locationtype folder -locationpath `"$folderPathToScan`" -locationpathexclude `"$commaSeparatedListOfFoldersOrPatternsToExcludeFromSASTscan`"`""
            
			#Write-Host "DEBUG: args = $args"

            # run the scan
            Run-A-CMD-Inside-A-Job "cmd.exe" "$env:windir\system32" $args "scanner"

            if($? -eq 0)
            {
                $status = $true
            }
            else
            {
                $status = $false
            }

            if($deleteFolderAfter -eq "y" -or $deleteFolderAfter -eq "Y" -or $deleteFolderAfter -eq "Yes" -or $deleteFolderAfter -eq "yes" -or $deleteFolderAfter -eq "YES" -or $deleteFolderAfter -eq $true)
            {
                #write-host "DEBUG: A request was made to remove the scanned folder '$folderPathToScan'. Removing folder ..."
        
                #write-host "DEBUG: running 'Remove-Item -Recurse $folderPathToScan' ..."
        
                Remove-Item -Recurse -Force $folderPathToScan
            }

            # temporary fix: move osa related files to the "reports" dir which currently been saved to the cx tool's inner folder regardless of sent parameters inside a dir by the name of the project
            $toolDir = $PSScriptRoot + "\CxConsolePlugin"

            $status = test-path "$toolDir\$projectName"

            if($status -eq $true)
            {
                move-item $toolDir\$projectName $reportsDir\$projectName-$date
            }

            if($status -eq $true)
            {
                return $true
            }
            else
            {
                return $false
            }
        }
    }
}


function Convert-ARarArchiveToAZipArchive
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true, Position=0)]
        [System.String]
        $rarFileSpec,

        [Parameter(Mandatory=$true, Position=1)]
        [System.String]
        $destDir
    )

    if((Check-IfAStringReffersToASupportedFile $rarFileSpec "application/octet-stream") -eq $true)
    {
        $app = $global:glb7zipBinaryFileSpec
    
        $status = test-path $app
                
        if($status -eq $true)
        {
            if ((& "$app") -notcontains "Igor Pavlov")
            {
                write-host "ERROR! Could not find '7z.exe' inside the path '$app'!"
            }
            else
            {
                $tempLoc = Get-Item $destDir

                #if (-not (Get-Item $file) -is [System.IO.DirectoryInfo])
                if (($tempLoc.Attributes) -eq "Directory")
                {
                    $rarFileObj = get-item $rarFileSpec

                    if($rarFileObj.Extension.ToLower() -eq ".rar" -and $rarFileObj.Length -gt 0)
                    {
                        & $app "l" $rarFileSpec | out-null

                        if($? -eq $true)
                        {
                            copy $rarFileSpec $tempLoc

                            cd $tempLoc

                            $outputFolder = [io.path]::GetFileNameWithoutExtension("$rarFileSpec")

                            # Extract .rar archive
                            & $app "x" "$rarFileSpec" "-o$outputFolder"
    
                            # Zip the extracted folder
                            & $app "a" ".\$outputFolder" "$outputFolder.zip"

                            if((Check-IfAStringReffersToASupportedFile "$outputFolder.zip" "application/x-zip-compressed") -eq $true -and (get-item $outputFolder.zip).Length -gt 0)
                            {
                                remove-item -Recurse ".\$outputFolder"
                                remove-item $rarFileSpec 

                                return "$tempLoc\$outputFolder.zip"
                            }
                            else
                            {
                                write-host "ERROR! Something went wrong while trying to create the Zip archive."
                            }
                        }
                        else
                        {
                            write-host "ERROR! invalid file (could not list the archive using 7z)!"
                        }
                    }
                    else
                    {
                        write-host "ERROR! The given file is either empty or not a valid rar file."
                    }
                }
                else
                {
                     write-host "ERROR! The given temp location is not a valid directory!"
                }
            }
        }
        else
        {
            write-host "ERROR! Could not find '7z.exe' inside the path '$app'!"
        }
    }
}


function Extract-ARarArchive
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true, Position=0)]
        [System.String]
        $rarFileSpec,

        [Parameter(Mandatory=$true, Position=1)]
        [System.String]
        $destDir
    )

    if((Check-IfAStringReffersToASupportedFile $rarFileSpec "application/octet-stream") -eq $true)
    {
        $app = $global:glb7zipBinaryFileSpec

        $status = test-path $app
                
        if($status -eq $true)
        {
            if (((& $app) | Where-Object {$_ -Like "*Igor Pavlov*"}) -eq $null)
            {
                write-host "ERROR! Could not find '7z.exe' inside the path '$app'!"

                return $false
            }
            else
            {
                $tempLoc = Get-Item $destDir

                #if (-not (Get-Item $file) -is [System.IO.DirectoryInfo])
                if (($tempLoc.Attributes) -eq "Directory")
                {
                    $rarFileObj = get-item $rarFileSpec

                    if($rarFileObj.Extension.ToLower() -eq ".rar" -and $rarFileObj.Length -gt 0)
                    {
                        & $app "l" $rarFileSpec | out-null

                        if($? -eq $true)
                        {
                            write-host "Extracting the rar archive $rarFileSpec to destination $destDir ..."                        
                     
                            & $app "x" "$rarFileSpec" "-o$destDir" | Out-Null

                            if($? -eq $true)
                            {
                                return $true
                            }
                            else
                            {
                                return $false
                            }
                        }
                        else
                        {
                            write-host "ERROR! invalid file (could not list the archive using 7z)!"

                            return $false
                        }
                    }
                    else
                    {
                        write-host "ERROR! The given file is either empty or not a valid rar file."

                        return $false
                    }
                }
                else
                {
                     write-host "ERROR! The given temp location is not a valid directory!"

                     return $false
                }
            }
        }
    }
    else
    {
        write-host "ERROR! Could not find '7z.exe' inside the path '$app'!"

        return $false
    }
}


function Extract-AZipArchive
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true, Position=0)]
        [System.String]
        $zipFileSpec,

        [Parameter(Mandatory=$true, Position=1)]
        [System.String]
        $destDir
    )

    if((Check-IfAStringReffersToASupportedFile $zipFileSpec "application/x-zip-compressed") -eq $true)
    {
        $app = $global:glb7zipBinaryFileSpec

        $status = test-path $app
                
        if($status -eq $true)
        {
            if (((& $app) | Where-Object {$_ -Like "*Igor Pavlov*"}) -eq $null)
            {
                write-host "ERROR! Could not find '7z.exe' inside the path '$app'!"

                return $false
            }
            else
            {
                $tempLoc = Get-Item $destDir

                #if (-not (Get-Item $file) -is [System.IO.DirectoryInfo])
                if (($tempLoc.Attributes) -eq "Directory")
                {
                    $zipFileObj = get-item $zipFileSpec

                    if($zipFileObj.Extension.ToLower() -eq ".zip" -and $zipFileObj.Length -gt 0)
                    {
                        & $app "l" $zipFileSpec | out-null

                        if($? -eq $true)
                        {
                            write-host "Extracting the zip archive $zipFileSpec to destination $destDir ..."

                            & $app "x" "$zipFileSpec" "-o$destDir" | Out-Null

                            if($? -eq $true)
                            {
                                return $true
                            }
                            else
                            {
                                return $false
                            }
                        }
                        else
                        {
                            write-host "ERROR! invalid file (could not list the archive using 7z)!"

                            return $false
                        }
                    }
                    else
                    {
                        write-host "ERROR! The given file is either empty or not a valid zip file."

                        return $false
                    }
                }
                else
                {
                     write-host "ERROR! The given temp location is not a valid directory!"

                     return $false
                }
            }
        }
        else
        {
            write-host "ERROR! Could not find '7z.exe' inside the path '$app'!"

            return $false
        }
    }
}


function Extract-ATarArchive
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true, Position=0)]
        [System.String]
        $tarFileSpec,

        [Parameter(Mandatory=$true, Position=1)]
        [System.String]
        $destDir
    )

    if((Check-IfAStringReffersToASupportedFile $tarFileSpec "application/x-tar") -eq $true)
    {
        $app = $global:glb7zipBinaryFileSpec

        $status = test-path $app
                
        if($status -eq $true)
        {
            if (((& $app) | Where-Object {$_ -Like "*Igor Pavlov*"}) -eq $null)
            {
                write-host "ERROR! Could not find '7z.exe' inside the path '$app'!"

                return $false
            }
            else
            {
                $tempLoc = Get-Item $destDir

                #if (-not (Get-Item $file) -is [System.IO.DirectoryInfo])
                if (($tempLoc.Attributes) -eq "Directory")
                {
                    $tarFileObj = get-item $tarFileSpec

                    if($tarFileObj.Extension.ToLower() -eq ".tar" -and $tarFileObj.Length -gt 0)
                    {
                        & $app "l" $tarFileSpec | out-null

                        if($? -eq $true)
                        {
                            write-host "Extracting the tar archive $tarFileSpec to destination $destDir ..."

                            & $app "x" "$tarFileSpec" "-o$destDir" | Out-Null

                            if($? -eq $true)
                            {
                                return $true
                            }
                            else
                            {
                                return $false
                            }
                        }
                        else
                        {
                            write-host "ERROR! invalid file (could not list the archive using 7z)!"

                            return $false
                        }
                    }
                    else
                    {
                        write-host "ERROR! The given file is either empty or not a valid tar file."

                        return $false
                    }
                }
                else
                {
                     write-host "ERROR! The given temp location is not a valid directory!"

                     return $false
                }
            }

        }
        else
        {
            write-host "ERROR! Could not find '7z.exe' inside the path '$app'!"

            return $false
        }
    }
}


function Extract-A7zipArchive
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true, Position=0)]
        [System.String]
        $7zipFileSpec,

        [Parameter(Mandatory=$true, Position=1)]
        [System.String]
        $destDir
    )

    if((Check-IfAStringReffersToASupportedFile $7zipFileSpec "application/octet-stream") -eq $true)
    {
        $app = $global:glb7zipBinaryFileSpec

        $status = test-path $app
                
        if($status -eq $true)
        {
            if (((& $app) | Where-Object {$_ -Like "*Igor Pavlov*"}) -eq $null)
            {
                write-host "ERROR! Could not find '7z.exe' inside the path '$app'!"

                return $false
            }
            else
            {
                $tempLoc = Get-Item $destDir

                #if (-not (Get-Item $file) -is [System.IO.DirectoryInfo])
                if (($tempLoc.Attributes) -eq "Directory")
                {
                    $7zipFileObj = get-item $7zipFileSpec

                    if($7zipFileObj.Extension.ToLower() -eq ".7z" -and $7zipFileObj.Length -gt 0)
                    {
                        & $app "l" $7zipFileSpec | out-null

                        if($? -eq $true)
                        {
                            write-host "Extracting the 7zip archive $7zipFileSpec to destination $destDir ..."

                            & $app "x" "$7zipFileSpec" "-o$destDir" | Out-Null
                        
                            if($? -eq $true)
                            {
                                return $true
                            }
                            else
                            {
                                return $false
                            }
                        }
                        else
                        {
                            write-host "ERROR! invalid file (could not list the archive using 7z)!"

                            return $false
                        }
                    }
                    else
                    {
                        write-host "ERROR! The given file is either empty or not a valid 7zip file."

                        return $false
                    }
                }
                else
                {
                     write-host "ERROR! The given temp location is not a valid directory!"

                     return $false
                }
            }
        }
        else
        {
            write-host "ERROR! Could not find '7z.exe' inside the path '$app'!"

            return $false
        }
    }
}


function Extract-ABz2Archive
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true, Position=0)]
        [System.String]
        $bz2FileSpec,

        [Parameter(Mandatory=$true, Position=1)]
        [System.String]
        $destDir
    )

    if((Check-IfAStringReffersToASupportedFile $bz2FileSpec "application/octet-stream") -eq $true)
    {
        $app = $global:glb7zipBinaryFileSpec

        $status = test-path $app
                
        if($status -eq $true)
        {
            if (((& $app) | Where-Object {$_ -Like "*Igor Pavlov*"}) -eq $null)
            {
                write-host "ERROR! Could not find '7z.exe' inside the path '$app'!"

                return $false
            }
            else
            {
                $tempLoc = Get-Item $destDir

                #if (-not (Get-Item $file) -is [System.IO.DirectoryInfo])
                if (($tempLoc.Attributes) -eq "Directory")
                {
                    $bz2FileObj = get-item $bz2FileSpec

                    if($bz2FileObj.Extension.ToLower() -eq ".bz2" -and $bz2FileObj.Length -gt 0)
                    {
                        & $app "l" $bz2FileSpec | out-null

                        if($? -eq $true)
                        {
                            write-host "Extracting the bz2 archive $bz2FileSpec to destination $destDir ..."

                            & $app "x" "$bz2FileSpec" "-o$destDir" | Out-Null

                            if($? -eq $false)
                            {
                                return $false
                            }

                            # check if a tar file exists inside the archive
                            $testTar = (& $app "l" "$bz2FileSpec" | select-object -last 3 | select-object -first 1 | %{ $_.Split(' ')[-1];})

                            #$temp = (& $app "l" "$bz2FileSpec" | select-object -last 3 | select-object -first 1)

                            #Write-Host "DEBUG: $temp"

                            #Write-Host "DEBUG: detected a tar file named $testTar"

                            if($testTar -ne $null -and $testTar -ne "")
                            {
                                $status = Test-Path "$destDir\$testTar"

                                if($status -eq $true)
                                {
                                    $fileObj = Get-Item "$destDir\$testTar"

                                    if ($fileObj.Attributes -eq "Archive" -and $fileObj.Length -gt 0)
                                    {
                                        if((Extract-ATarArchive "$destDir\$testTar" $destDir) -eq $true)
                                        {
                                            Remove-Item "$destDir\$testTar"

                                            return $true
                                        }
                                        else
                                        {
                                            return $false
                                        }
                                    }
                                }
                                else
                                {
                                    return $false
                                }
                            }
                        }
                        else
                        {
                            write-host "ERROR! invalid file (could not list the archive using 7z)!"

                            return $false
                        }
                    }
                    else
                    {
                        write-host "ERROR! The given file is either empty or not a valid bz2 file."

                        return $false
                    }
                }
                else
                {
                     write-host "ERROR! The given temp location is not a valid directory!"

                     return $false
                }
            }
        }
        else
        {
            write-host "ERROR! Could not find '7z.exe' inside the path '$app'!"

            return $false
        }
    }
}


function Extract-AGZipArchive
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true, Position=0)]
        [System.String]
        $gzipFileSpec,

        [Parameter(Mandatory=$true, Position=1)]
        [System.String]
        $destDir
    )

    if((Check-IfAStringReffersToASupportedFile $gzipFileSpec "application/x-gzip") -eq $true -or (Check-IfAStringReffersToASupportedFile $gzipFileSpec "application/x-compressed") -eq $true)
    {
        $app = $global:glb7zipBinaryFileSpec

        $status = test-path $app
                
        if($status -eq $true)
        {
            if (((& $app) | Where-Object {$_ -Like "*Igor Pavlov*"}) -eq $null)
            {
                write-host "ERROR! Could not find '7z.exe' inside the path '$app'!"

                return $false
            }
            else
            {
                $tempLoc = Get-Item $destDir

                #if (-not (Get-Item $file) -is [System.IO.DirectoryInfo])
                if (($tempLoc.Attributes) -eq "Directory")
                {
                    $gzipFileObj = get-item $gzipFileSpec

                    if(($gzipFileObj.Extension.ToLower() -eq ".gz" -or $gzipFileObj.Extension.ToLower() -eq ".tgz") -and $gzipFileObj.Length -gt 0)
                    {
                        & $app "l" $gzipFileSpec | out-null

                        if($? -eq $true)
                        {
                            write-host "Extracting the gzip archive $gzipFileSpec to destination $destDir ..."                    

                            & $app "x" "$gzipFileSpec" "-o$destDir" | Out-Null

                            if($? -eq $false)
                            {
                                return $false
                            }

                            # check if a tar file exists inside the archive
                            $testTar = (& $app "l" "$gzipFileSpec" | select-object -last 3 | select-object -first 1 | %{ $_.Split(' ')[-1];})

                            #$temp = (& $app "l" "$gzipFileSpec" | select-object -last 3 | select-object -first 1)

                            #Write-Host "DEBUG: $temp"

                            #Write-Host "DEBUG: detected a tar file named $testTar"

                            if($testTar -ne $null -and $testTar -ne "")
                            {
                                $status = Test-Path "$destDir\$testTar"

                                if($status -eq $true)
                                {
                                    $fileObj = Get-Item "$destDir\$testTar"

                                    if ($fileObj.Attributes -eq "Archive" -and $fileObj.Length -gt 0)
                                    {
                                        if((Extract-ATarArchive "$destDir\$testTar" $destDir) -eq $true)
                                        {
                                            Remove-Item "$destDir\$testTar"

                                            return $true
                                        }
                                        else
                                        {
                                            return $false
                                        }
                                    }
                                }
                                else
                                {
                                    return $false
                                }
                            }
                        }
                        else
                        {
                            write-host "ERROR! invalid file (could not list the archive using 7z)!"

                            return $false
                        }
                    }
                    else
                    {
                        write-host "ERROR! The given file is either empty or not a valid gzip file."

                        return $false
                    }
                }
                else
                {
                     write-host "ERROR! The given temp location is not a valid directory!"

                     return $false
                }
            }
        }
        else
        {
            write-host "ERROR! Could not find '7z.exe' inside the path '$app'!"

            return $false
        }
    }
}


function Is-ValidArchiveFile($archiveFileSpec, $supportedArchiveTypesList)
{
    $status = Test-Path $archiveFileSpec

    if($status -eq $true)
    {
        $fileObj = Get-Item $archiveFileSpec

        if (($fileObj.Attributes) -ne "Directory")
        {
            if ((Get-Content $archiveFileSpec) -ne $null) 
            {
	            $fileMimeType = Get-MimeType($fileObj)

                if (Is-SupportedMimeType $fileMimeType $glbSupportedMimeTypes)
                {
                    $app = $global:glb7zipBinaryFileSpec

                    $status = test-path $app
                
                    if($status -eq $true)
                    {
                        if (((& $app) | Where-Object {$_ -Like "*Igor Pavlov*"}) -eq $null)
                        {
                            return $false
                        }
                        else
                        {
                            if(((& $app "l" $archiveFileSpec) | Where-Object {$_ -Like "Blocks = 0"}) -eq $null)
                            {
                                return $true
                            }
                            else
                            {
                                return $false
                            }
                        }
                    }
                    else
                    {
                        return $false
                    }
                }
                else
                {
                    return $false
                }
            }
            else
            {
                return $false
            }
        }
        else
        {
            return $false
        }
    }
    else
    {
        return $false
    }
}


function Is-APasswordProtectedArchiveFile($archiveFileSpec, $supportedArchiveTypesList)
{
    $status = test-path $archiveFileSpec

    if($status -eq $true)
    {
        $fileObj = Get-Item $archiveFileSpec

        if ($fileObj.Attributes -eq "Archive" -and $fileObj.Length -gt 0)
        {
            $app = $global:glb7zipBinaryFileSpec

            $status = test-path $app
                
            if($status -eq $true)
            {
                if (((& $app) | Where-Object {$_ -Like "*Igor Pavlov*"}) -eq $null)
                {
                    write-output "ERROR! Could not find '7z.exe' inside the path '$app'!"

                    return $false
                }
                else
                {
                    $isEncrypted = & $app "l" "-slt" $archiveFileSpec | select-string "encrypted" | select -last 1 | select-string "\+"

                    #write-host $isEncrypted

                    if($isEncrypted -ne $null)
                    {
                        return $true
                    }
                    else
                    {
                        return $false
                    }
                }
            }
            else
            {
                write-output "ERROR! Could not find '7z.exe' inside the path '$app'!"

                return $false
            }
        }
        else
        {
            write-output "ERROR! The given 1st argument is an invalid file! (func: Is-APasswordProtectedArchiveFile)"

            return $false
        }                
    }
    else
    {
        write-output "ERROR! The given 1st argument is an invalid file! (func: Is-APasswordProtectedArchiveFile)"

        return $false
    }                    
}


function Try-ToExtractAPasswordProtectedArchiveFile($archiveFileSpec, $supportedArchiveTypesList, $passwordsList, $destDir)
{
    $pwdFound = $false

    $status = test-path $archiveFileSpec

    if($status -eq $true)
    {
        $fileObj = Get-Item $archiveFileSpec

        if ($fileObj.Attributes -eq "Archive" -and $fileObj.Length -gt 0)
        {
            if (Is-SupportedFileFormat ($fileObj.extension.ToLower() -replace '\.','') $supportedArchiveTypesList)
            {
                $app = $global:glb7zipBinaryFileSpec

                $status = test-path $app
                
                if($status -eq $true)
                {
                    if (((& $app) | Where-Object {$_ -Like "*Igor Pavlov*"}) -eq $null)
                    {
                       write-output "ERROR! Could not find '7z.exe' inside the path '$app'!"
                    }
                    else
                    {
                       if((test-path $destDir) -ne $true)
                       {
                            mkdir $destDir | out-null
                       }

                       $passwordsList = $passwordsList + "," + $fileObj.basename

                       $pwdsArr = $passwordsList.split(",")

                        foreach($pwd in $pwdsArr)
                        {
                            write-host "Trying to extract the archive using the password '$pwd' ..."

                            & $app "x" "$archiveFileSpec" "-o$destDir" "-p$pwd" -y | out-null
                     
                            if($? -eq $true)
                            {
                                $pwdFound = $true
                                break
                            }
                        }

                        if($pwdFound -eq $true)
                        {
                            write-host "Successfully extracted a password protected file ($archiveFileSpec)."

                            return $true
                        }
                        else
                        {
                            write-host "ERROR! Could not extract a password protected file ($archiveFileSpec)!"

                            return $false
                        }
                    }
                }
                else
                {
                    write-host "ERROR! Could not find '7z.exe' inside the path '$app'!"

                    return $false
                }           
            }
            else
            {
                write-host "ERROR! The given file type is not supported by this function! (func: Try-ToExtractAPasswordProtectedArchiveFile)"
                
                return $false             
            }
        }
        else
        {
            write-host "ERROR! The given 1st argument is an invalid file! (func: Try-ToExtractAPasswordProtectedArchiveFile)"

            return $false
        }                
    }
    else
    {
        write-host "ERROR! The given 1st argument is an invalid file! (func: Try-ToExtractAPasswordProtectedArchiveFile)"

        return $false
    }
}


function Is-SupportedFileFormat
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true, Position=0)]
        [System.String]
        $aFormatToCheck,
         
        [Parameter(Mandatory=$true, Position=1)]
        [System.String]
        $supportedFormatsList
    )

    #write-host "DEBUG: "$aFormatToCheck.ToLower()

    if($supportedFormatsList.Contains($aFormatToCheck.ToLower()))
    {
        return $true
    }
    else
    {
        return $false
    }
}


function Is-SupportedMimeType
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true, Position=0)]
        [System.String]
        $aMimeTypeToCheck,
         
        [Parameter(Mandatory=$true, Position=1)]
        [System.String]
        $supportedMimeTypesList
    )

    #write-host "DEBUG: "$aFormatToCheck.ToLower()

    if($supportedMimeTypesList.Contains($aMimeTypeToCheck.ToLower()))
    {
        return $true
    }
    else
    {
        return $false
    }
}


function Check-IfAStringReffersToASupportedFile
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true, Position=0)]
        [System.String]
        $aStringToCheck,
         
        [Parameter(Mandatory=$true, Position=1)]
        [System.String]
        $theFileTypeTheStringShouldRefferTo
    )

    $status = Test-Path $aStringToCheck

    if($status -eq $true)
    {
        $fileObj = Get-Item $aStringToCheck

        #if (-not (Get-Item $file) -is [System.IO.DirectoryInfo])
        if (($fileObj.Attributes) -ne "Directory")
        {
            if ((Get-Content $aStringToCheck) -ne $null) 
            {
	            $fileMimeType = Get-MimeType($fileObj)

                if (Is-SupportedMimeType $fileMimeType $glbSupportedMimeTypes)
                {
                    if ($theFileTypeTheStringShouldRefferTo -eq $fileMimeType -or $theFileTypeTheStringShouldRefferTo -eq "any")
                    {
                        return $true
                    }
                }
                else
                {
                    write-host "ERROR! The given file type is not supported by this application (func: Check-IfAStringReffersToASupportedFile)!"

                    return $false
                }
            }
            else
            {
                write-host "ERROR! The given file is empty (func: Check-IfAStringReffersToASupportedFile)!"

                return $false
            }
        }
        else
        {
            write-host "ERROR! No file supplied. The given is a directory (func: Check-IfAStringReffersToASupportedFile)!"
	    
            return $false
        }
    }
    else
    {
        write-host "ERROR! The given is not a valid file (func: Check-IfAStringReffersToASupportedFile)!"

        return $false        
    }
}


function Get-MimeType() { 
    param([parameter(Mandatory=$true, ValueFromPipeline=$true)][ValidateNotNullorEmpty()][System.IO.FileInfo]$CheckFile)

    begin {
        [System.IO.FileInfo]$check_file = $CheckFile
        [string]$mime_type = $null
    } 
    process {
        if ($check_file.Exists) {
            $mime_type = [System.Web.MimeMapping]::GetMimeMapping($check_file.FullName)
        }
        else {
            $mime_type = "false"
        }
    } 
    end { return $mime_type }
}


function Run-A-CMD-Inside-A-Job ($cmd, $cmdLocation, $cmdArgs, $logFilesPrefix)
{
    $dateSuffix = Get-Date -format yyyy-MM-dd_HH-mm-ss
    $fileSuffix = ".txt"

    $outputFileSpec = $logFilesPrefix + "-" + $dateSuffix + $fileSuffix
    $errorFileSpec = $logFilesPrefix + "-" + $dateSuffix + "-error" + $fileSuffix

    $logsDir = "$PSScriptRoot\logs"

    $status = Test-Path "$logsDir"

    if($status -ne $true)
    {
        mkdir $logsDir | out-null
    }
    else
    {
        $fsObj = get-item $logsDir

        if (($fsObj.Attributes) -ne "Directory")
        {
            # something is wrong - use the scripts root dir to save logs
            $logsDir = $PSScriptRoot
        }
    }

    pushd .

    cd $cmdLocation

    Start-Process $cmd -ArgumentList "$cmdArgs" -RedirectStandardOutput "$logsDir\$outputFileSpec" -RedirectStandardError "$logsDir\$errorFileSpec" -Wait

    popd

    #write-host "DEBUG: Start-Process $cmd -ArgumentList `"$cmdArgs`" -RedirectStandardOutput `"$outputFileSpec`" -RedirectStandardError `"$errorFileSpec`""

    #write-host "DEBUG: $cmd $cmdArgs"
}


function Get-NewestFile($dirToSearchIn)
{
    $status = test-path $dirToSearchIn

    if($status -eq $true)
    {
        $file = get-childitem -path $dirToSearchIn -file  | sort-object LastWriteTime -Descending | select -first 1

        return $file.fullname
    }
    else
    {
        write-host "ERROR! The given is an invalid path!"

        return $false
    }
}


function Find-AProjectName($projectFilesDir)
{
    $status = test-path $projectFilesDir

    if($status -eq $true)
    {
        $solFilesList = get-childitem -file -filter "*.sol"

        if($solFilesList.count -ne 1)
        {
            return $false
        }
        else
        {
            $solFilesList.name
        }
    }
    else
    {
        #write-host "ERROR! The given is an invalid path!"
        #write-host "Please supply a path with source files to scan."

        return $false
    }
}


function Generate-ARandomString($numberOfChars) { 
    -join ((65..90) + (97..122) | Get-Random -Count $numberOfChars | % {[char]$_})
}


function Get-NextMatchLocation($aChar, $aString, $startSearchIndex)
{
    $outputIndex = -1

    if($aChar.length -eq 1)
    {
        $strLen = $aString.length
        $i=$startSearchIndex
        $found = $false

        while($i -lt $strLen -and $found -eq $false)
        {
            $currentChar = $aString[$i]

            if($currentChar -eq $aChar)
            {
                $outputIndex = $i
                $found = $true
            }
            else
            {
                $i++
            }
        }
    }
    else
    {
        write-host "ERROR! First argument is NOT a single char!"
    }

    return $outputIndex
}


function Get-LargestIdenticalSubsring($string1, $string2)
{
    if($string1 -ne $null -and $string1 -ne "" -and $string2 -ne $null -and $string2 -ne "")
    {
        $i=0
        $nextMatchIndex=0
        
        $largestIdenticalSubsring=""
        $largestIdenticalSubsringRecheck=""

        $str1Len = $string1.length
        $str2Len = $string2.length

        $doneBeforehand = $false

        if($str1Len -lt $str2Len)
        {
            $numOfCharsLeftToProcess = $str1Len
            $smallerString = $string1
            $largerString = $string2
        }
        else
        {
            $numOfCharsLeftToProcess = $str2Len
            $smallerString = $string2
            $largerString = $string1
        }

        while($numOfCharsLeftToProcess -gt 0 -and $doneBeforehand -ne $true)
        {
            $currentChar = $smallerString[$i]

            $nextMatchIndex = (Get-NextMatchLocation $currentChar $largerString $nextMatchIndex)

            while($nextMatchIndex -ne -1 -and $doneBeforehand -ne $true)
            {
                $largestIdenticalSubsring = $largestIdenticalSubsring + $currentChar
                
                $j = $nextMatchIndex+1
                $k = $i+1
                #$numOfCharsLeftInTheSubstring = $largerString.length - ($firstMatchIndex + 1)
                
                $numOfCharsLeftInTheSubstring = $numOfCharsLeftToProcess-1

                while($numOfCharsLeftInTheSubstring -gt 0)
                {
                    if($smallerString[$k] -eq $largerString[$j])
                    {
                        $largestIdenticalSubsring = $largestIdenticalSubsring + $smallerString[$k]
                        $k++
                        $j++
                        $numOfCharsLeftInTheSubstring--
                    }
                    else
                    {
                        $numOfCharsLeftInTheSubstring = -1
                    }
                }
            
                if(-not ($largestIdenticalSubsring.length -lt $numOfCharsLeftToProcess))
                {
                    $doneBeforehand = $true
                }
                else
                {
                    if($largestIdenticalSubsringRecheck.length -lt $largestIdenticalSubsring.length)
                    {
                        $largestIdenticalSubsringRecheck = $largestIdenticalSubsring
                    }

                    #write-host $largestIdenticalSubsring
                    $largestIdenticalSubsring = ""
                }

                $nextMatchIndex = (Get-NextMatchLocation $currentChar $largerString ($nextMatchIndex+1))
            }
            
            $numOfCharsLeftToProcess--
            $i++
        }

        if($largestIdenticalSubsringRecheck.length -gt $largestIdenticalSubsring.length)
        {
            $largestIdenticalSubsring = $largestIdenticalSubsringRecheck
        }

        return $largestIdenticalSubsring
    }
    else
    {
        write-host "ERROR! At least one of the given arguments is empty or null! (func: Get-LargestIdenticalSubsring)"

        return -1
    }
}


function Get-AListOfProjectNames($aPathToRunOn, $extraNamesCommaDelimitedString)
{
    $MAX_NUMBER_OF_EXTRACTED_NAMES=10

    $projectNamesOutputArr = @()
    $numOfExtractedNames=0
    $nameToCompareAgainst=""

    $status = test-path $aPathToRunOn

    if($status -eq $true)
    {
        $fldrs = get-childitem $aPathToRunOn -directory -recurse

        if($fldrs.count -gt 0)
        {
            #$fldrs += (get-item $aPathToRunOn)

            foreach($fldr in $fldrs)
            {
                $files = get-childitem $fldr.fullname -file | Sort-Object
            
                foreach($file in $files)
                {
                    if($nameToCompareAgainst -eq "")
                    {
                        $nameToCompareAgainst = $file.basename
                    }
                    else
                    {
                        $basename = $file.basename

                        #write-host "comparing $basename with $nameToCompareAgainst ..."

                        [string]$commonPart = (Get-LargestIdenticalSubsring $basename $nameToCompareAgainst)

                        if($commonPart -eq "")
                        {
                            $nameToCompareAgainst = $file.basename
                        }

                        #write-host "and the common part is: '$commonPart'"

                        # removing unneeded chars
                        $commonPart = $commonPart.Replace(".","")

                        if($commonPart.length -gt 3)
                        {
                            #write-host "adding a new name to the array - $commonPart"

                            if(-not ($projectNamesOutputArr.Contains($commonPart)))
                            {
                                $projectNamesOutputArr += $commonPart
                                $numOfExtractedNames++
                            }
                        }

                        #if($numOfExtractedNames -eq $MAX_NUMBER_OF_EXTRACTED_NAMES)
                        #{
                        #    break
                        #}
                    }
                }

                $nameToCompareAgainst=""
            }
        }
        else
        {
            $files = get-childitem $aPathToRunOn -file

            if($files.count -gt 0)
            {
                foreach($file in $files)
                {
                    $projectNamesOutputArr += $file.basename
                    $numOfExtractedNames++
                }
            }
        }

        $extraNamesArr = $extraNamesCommaDelimitedString.split(",")

        $projectNamesOutputArr += $extraNamesArr
    }
    else
    {
        write-host "ERROR! The given is an invalid path! (func: Get-AListOfProjectNames)"
    }

    return $projectNamesOutputArr
}


function Extract-OrCopyAnItem($item, $destination)
{
    $status = Test-Path $item

    if($status -eq $true)
    {
        $fileObj = Get-Item $item

        if (($fileObj.Attributes) -ne "Directory")
        {
            if ((Get-Content $item) -ne $null) 
            {
	            $fileMimeType = Get-MimeType($fileObj)
    
                #write-host "DEBUG: $fileMimeType"

                if (Is-SupportedMimeType $fileMimeType $glbSupportedMimeTypes)
                {
                    #mkdir $destination | Out-Null

                    if((Does-ThisStringContainsCharsInLanguagesOtherThanEnglish $fileObj.basename) -eq $true)
                    {
                        write-host "The file '$item' contains chars that are unsupported by Checkmarx."
                        Write-Host "Making a renamed copy of the file ..."

                        $newItemName = ($fileObj.DirectoryName + "\renamed-" + (Generate-ARandomString 8) + ($fileObj.Extension))
                        copy $item $newItemName
                        $item = $newItemName
                        #$destination = $newItemName + "-dir-" + (Generate-ARandomString 8)
                    }
                    
                    mkdir $destination | Out-Null

                    switch($fileMimeType)
                    {
                        "text/plain" {
                            #mkdir $destination | Out-Null

                            copy $item $destination

                            if($? -eq $true)
                            {
                                return $true
                            }
                            else
                            {
                                return $false
                            }
                        }
                        "text/html" {
                            #mkdir $destination | Out-Null

                            copy $item $destination

                            if($? -eq $true)
                            {
                                return $true
                            }
                            else
                            {
                                return $false
                            }
                        }
                        "application/x-javascript" {
                            #mkdir $destination | Out-Null

                            copy $item $destination

                            if($? -eq $true)
                            {
                                return $true
                            }
                            else
                            {
                                return $false
                            }
                        }
                        "application/x-zip-compressed" {
                            if(Is-APasswordProtectedArchiveFile $item $glbSupportedArchiveTypesList)
                            {
                                #mkdir $destination | Out-Null

                                Try-ToExtractAPasswordProtectedArchiveFile $item $glbSupportedArchiveTypesList $glbPasswordsList $destination

                                if($? -eq $true)
                                {
                                    Find-AndExtractInnerArchiveFiles $destination $glbSupportedArchiveTypesList

                                    return $true
                                }
                                else
                                {
                                    return $false
                                }
                            }
                            else
                            {
                                #mkdir $destination | Out-Null

                                if((Extract-AZipArchive $item $destination) -eq $true)
                                {
                                    Find-AndExtractInnerArchiveFiles $destination $glbSupportedArchiveTypesList

                                    return $true
                                }
                                else
                                {
                                    write-host "ERROR! something went wrong while trying to extract the zip archive."

                                    rmdir -Recurse -Force $destination

                                    return $false
                                }
                            }
                        }
                        "application/x-tar" {
                            #mkdir $destination | Out-Null

                            if((Extract-ATarArchive $item $destination) -eq $true)
                            {
                                Find-AndExtractInnerArchiveFiles $destination $glbSupportedArchiveTypesList

                                return $true
                            }
                            else
                            {
                                write-host "ERROR! something went wrong while trying to extract the tar archive."

                                rmdir -Recurse -Force $destination

                                return $false
                            }
                        }
                        "application/x-gzip" {
                            if(Is-APasswordProtectedArchiveFile $item $glbSupportedArchiveTypesList)
                            {
                                #mkdir $destination | Out-Null

                                Try-ToExtractAPasswordProtectedArchiveFile $item $glbSupportedArchiveTypesList $glbPasswordsList $destination

                                if($? -eq $true)
                                {
                                    Find-AndExtractInnerArchiveFiles $destination $glbSupportedArchiveTypesList

                                    return $true
                                }
                                else
                                {
                                    return $false
                                }
                            }
                            else
                            {
                                #mkdir $destination | Out-Null

                                if((Extract-AGZipArchive $item $destination) -eq $true)
                                {
                                    Find-AndExtractInnerArchiveFiles $destination $glbSupportedArchiveTypesList
                                    
                                    return $true
                                }
                                else
                                {
                                    write-host "ERROR! something went wrong while trying to extract the gzip archive."

                                    rmdir -Recurse -Force $destination

                                    return $false
                                }
                            }
                        }
                        "application/x-compressed" {
                            if(Is-APasswordProtectedArchiveFile $item $glbSupportedArchiveTypesList)
                            {
                                #mkdir $destination | Out-Null

                                Try-ToExtractAPasswordProtectedArchiveFile $item $glbSupportedArchiveTypesList $glbPasswordsList $destination

                                if($? -eq $true)
                                {
                                    Find-AndExtractInnerArchiveFiles $destination $glbSupportedArchiveTypesList

                                    return $true
                                }
                                else
                                {
                                    return $false
                                }
                            }
                            else
                            {
                                #mkdir $destination | Out-Null

                                if((Extract-AGZipArchive $item $destination) -eq $true)
                                {
                                    Find-AndExtractInnerArchiveFiles $destination $glbSupportedArchiveTypesList

                                    return $true
                                }
                                else
                                {
                                    write-host "ERROR! something went wrong while trying to extract the gzip archive."

                                    rmdir -Recurse -Force $destination

                                    return $false
                                }
                            }
                        }
                        "application/octet-stream" 
                        {
                            switch($fileObj.extension.ToLower())
                            {
                                ".rar"
                                {
                                    if(Is-APasswordProtectedArchiveFile $item $glbSupportedArchiveTypesList)
                                    {
                                        #mkdir $destination | Out-Null

                                        Try-ToExtractAPasswordProtectedArchiveFile $item $glbSupportedArchiveTypesList $glbPasswordsList $destination

                                        if($? -eq $true)
                                        {
                                            Find-AndExtractInnerArchiveFiles $destination $glbSupportedArchiveTypesList

                                            return $true
                                        }
                                        else
                                        {
                                            return $false
                                        }
                                    }
                                    else
                                    {
                                        #mkdir $destination | Out-Null

                                        if((Extract-ARarArchive $item $destination) -eq $true)
                                        {
                                            Find-AndExtractInnerArchiveFiles $destination $glbSupportedArchiveTypesList

                                            return $true
                                        }
                                        else
                                        {
                                            write-host "ERROR! something went wrong while trying to extract the rar archive."

                                            rmdir -Recurse -Force $destination

                                            return $false
                                        }
                                    }
                                }
                                ".7z"
                                {
                                    if(Is-APasswordProtectedArchiveFile $item $glbSupportedArchiveTypesList)
                                    {
                                        #mkdir $destination | Out-Null

                                        Try-ToExtractAPasswordProtectedArchiveFile $item $glbSupportedArchiveTypesList $glbPasswordsList $destination

                                        if($? -eq $true)
                                        {
                                            Find-AndExtractInnerArchiveFiles $destination $glbSupportedArchiveTypesList

                                            return $true
                                        }
                                        else
                                        {
                                            return $false
                                        }
                                    }
                                    else
                                    {
                                        #mkdir $destination | Out-Null

                                        if((Extract-A7zipArchive $item $destination) -eq $true)
                                        {
                                            Find-AndExtractInnerArchiveFiles $destination $glbSupportedArchiveTypesList
                                            
                                            return $true
                                        }
                                        else
                                        {
                                            write-host "ERROR! something went wrong while trying to extract the 7zip archive."

                                            rmdir -Recurse -Force $destination

                                            return $false
                                        }
                                    }
                                }
                                ".bz2"
                                {
                                    #mkdir $destination | Out-Null

                                    if((Extract-ABz2Archive $item $destination) -eq $true)
                                    {
                                        Find-AndExtractInnerArchiveFiles $destination $glbSupportedArchiveTypesList
                                        
                                        return $true
                                    }
                                    else
                                    {
                                        write-host "ERROR! something went wrong while trying to extract the bz2 archive."

                                        rmdir -Recurse -Force $destination

                                        return $false
                                    }
                                }
                                ".cs"
                                {
                                    #mkdir $destination | Out-Null

                                    copy $item $destination

                                    if($? -eq $true)
                                    {
                                        return $true
                                    }
                                    else
                                    {
                                        return $false
                                    }                                
                                }
                                default
                                {
                                    write-host "ERROR! The given mime type (which is '$fileMimeType') is either not recognized or not supported."

                                    return $false
                                }
                            }
                        }
                        ""
                        {
                            write-host "ERROR! The given file has no extension! Please add an extension to its name according to its type and try again."

                            return $false
                        }
                        default
                        {
                            write-host "ERROR! The given file mime type (which is '$fileMimeType') is valid, but the file structure is not supported by this application."

                            return $false
                        }
                    }
                }
                else
                {
                    write-host "ERROR! The given file type is not supported by this application!"

                    return $false
                }
            }
            else
            {
                write-host "ERROR! The given 1st argument is an empty file!"

                return $false
            }
        }
        else
        {
            mkdir $destination | Out-Null

            if((Does-ThisStringContainsCharsInLanguagesOtherThanEnglish $item) -eq $true)
            {
                write-host "The folder '$item' contains chars that are unsupported by Checkmarx."
                Write-Host "Renaming the folder at the destination ..."

                $destination = $destination + "\renamed-" + (Generate-ARandomString 8)
            }

            write-host "Copying content of folder '$item' to destination folder '$destination' ..."

            copy -Recurse $item $destination

            $copyActionStatus = $?

            # this function call does not need to succeed...
            Find-AndExtractInnerArchiveFiles $destination $glbSupportedArchiveTypesList
            
            if($copyActionStatus -eq $true)
            {
                return $true
            }
            else
            {
                write-host "ERROR! Something went wrong while trying to copy the content of the folder '$item' to the destination folder '$destination'!"
                return $false
            }
        }
    }
    else
    {
        write-host "ERROR! The first argument must be a valid path! (func: Extract-OrCopyAnItem)"

        return $false
    }
}

function Does-ThisStringContainsCharsInLanguagesOtherThanEnglish($stringToTest)
{
    $allowedChars="[ !`"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~]"

    if($stringToTest -eq $null -or $stringToTest -eq "")
    {
        write-host "The given string is null or empty! (func: Does-ThisStringContainsCharsInLanguagesOtherThanEnglish)"
    }
    else
    {
        if($stringToTest -notmatch $allowedChars)
        {
            return $true
        }
        else
        {
            return $false
        }
    }
}

function Run-PostSuccessfulScanActions($folderToOpenInExplorer)
{
    write-host "The scan was ended successfully."
    write-host "Openning the 'reports' folder ..."

    start-process "explorer" -ArgumentList "$folderToOpenInExplorer"
}

function Run-PostFailedScanActions($folderToOpenInExplorer)
{
    write-host "ERROR! Something went wrong while trying to run a scan!"

    start-process "explorer" -ArgumentList "$folderToOpenInExplorer"
}

function Is-ValidCxzipToolV1($toolFullPath)
{
    $status = Test-Path $toolFullPath

    if($status -eq $true)
    {
        $arg1 = (Generate-ARandomString 8)
        $arg2 = (Generate-ARandomString 8)

        # due to a bug, the cxzip tool MUST be run from its location
        cd ((get-item $toolFullPath).DirectoryName)

        if (((& $toolFullPath "$arg1" "$arg2" 2>&1) | Where-Object {$_ -Like "*cxzip*"}) -eq $null)
        {
            write-output "ERROR! Could not find 'cxzip.exe' inside the path '$toolFullPath'! (func: Is-ValidCxzipToolV1)"

            return $false
        }
        else
        {
            return $true
        }
    }
    else
    {
        write-host "ERROR! The given is an invalid path! (func: Is-ValidCxzipToolV1)"

        return $false
    }
}


function Cxzip-AFolder
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true, Position=0)]
        [System.String]
        $fileOrFolderToCompress,

        [Parameter(Mandatory=$true, Position=1)]
        [System.String]
        $destDir
    )

    if((Is-ValidCxzipTool $global:glbCxzipBinaryFileSpec) -eq $true)
    {
        $tempDestLoc = Get-Item $destDir

        $fileOrFolderToCompressObj = get-childitem -Recurse -File $fileOrFolderToCompress

        if($fileOrFolderToCompressObj.count -gt 0)
        {
            if($tempDestLoc.count -gt 0)
            {
                write-host "The given destination directory '$destDir' is not empty. Creating a random sub directory inside it to make sure that only the input files will be compressed."

                cd $destDir

                $destName = "aZip"

                $tempDestLoc = mkdir $destName
            }

            # due to a bug, the cxzip tool MUST be run from its location
            cd ((get-item $global:glbCxzipBinaryFileSpec).DirectoryName)

            $zipFileName = $destName + ".zip"

            $appName = (get-item $global:glbCxzipBinaryFileSpec).name

            # Zip the extracted folder

            write-host "Creating a new Cxzip archive inside the destination '"$tempDestLoc\$zipFileName"' ..."

            & ".\$appName" "$fileOrFolderToCompress" "$tempDestLoc\$zipFileName" | out-null

            if((Check-IfAStringReffersToASupportedFile "$tempDestLoc\$zipFileName" "application/x-zip-compressed") -eq $true -and (get-item "$tempDestLoc\$zipFileName").Length -gt 0)
            {
                return "$tempDestLoc\$zipFileName"
            }
            else
            {
                write-host "ERROR! Something went wrong while trying to create the CxZip archive (func: Cxzip-AFolder)."

                return $false
            }
        }
        else
        {
            write-host "ERROR! The given input is either an empty directory or an empty file (func: Cxzip-AFolder)."
                    
            return $false   
        }
    }
    else
    {
        write-output "ERROR! Could not find 'cxzip.exe' tool inside the path '$global:glbCxzipBinaryFileSpec' (func: Cxzip-AFolder)!"

        return $false
    }
}

function Get-MD5Hash($fileSpec)
{
    $md5 = [System.Security.Cryptography.MD5]::Create("MD5")
    $fd = [System.IO.File]::OpenRead($fileSpec)
    
    $buf = new-object byte[] (1024*1024*8) # 8mb buffer
    
    while (($read_len = $fd.Read($buf,0,$buf.length)) -eq $buf.length){
        $total += $buf.length
        $md5.TransformBlock($buf,$offset,$buf.length,$buf,$offset)
        
        #write-progress -Activity "Hashing File" `
        #   -Status $file -percentComplete ($total/$fd.length * 100)
    }
    
    # finalize the last read
    $md5.TransformFinalBlock($buf,0,$read_len) | out-null
    $hash = $md5.Hash
    # convert hash bytes to hex formatted string
    $hash | foreach { $hash_txt += $_.ToString("x2") }

    write-output $hash_txt
}

function Is-ValidCxzipTool($toolFullPath)
{
    $validHashes = @("1103493c5f5405b990211c2cc1827d61","aa6eb93e0259369248294e4a210fd548")

    $status = Test-Path $toolFullPath

    if($status -eq $true)
    {
        $fileObj = Get-Item $toolFullPath

        if ($fileObj.Attributes -eq "Archive" -and $fileObj.Length -gt 0)
        {
            $hashFromCalc = (Get-MD5Hash $toolFullPath)

            foreach($hash in $validHashes)
            {
                if($hashFromCalc -eq $hash)
                {
                    return $true
                }
            }

            return $false
        }
        else
        {
            write-host "ERROR! The given is not a file! (func: Is-ValidCxzipTool)"

            return $false            
        }
    }
    else
    {
        write-host "ERROR! The given is an invalid path! (func: Is-ValidCxzipTool)"

        return $false
    }
}
