param (
   [string]$fileOrFolderToScan = "",
   [string]$projectName = "",
   [string]$userName = "",
   [string]$password = "",
   [string]$cameFromWrapper = "no",
   [string]$cxServerURL = "myServer.local",
   [string]$projectPathInsideServer = "cxserver\someGroup\users",
   [string]$commaSeparatedListOfFoldersOrPatternsToExcludeFromSASTscan = "node_modules"
)

# include a script
. ($PSScriptRoot + "\" + "myFunctions.ps1")

Add-Type -AssemblyName "System.Web"

$usageInfo = "Usage: " + $MyInvocation.MyCommand.Name + " <file-or-folder-to-scan> <project-name> [optional: cx-username] [optional: cx-password] [optional: cx-server-url] [optional: project-path-inside-server]"

if($fileOrFolderToScan -ne "" -and $projectName -ne "" -and $cxServerURL -ne "" -and $projectPathInsideServer -ne "")
{
    $status = Test-Path $fileOrFolderToScan

    if($status -eq $true)
    {
        $tempLocation = "c:\windows\temp\cx-auto-scan-temp-" + (Generate-ARandomString 8)

        #Write-Host "DEBUG: Current temp location is: $tempLocation"

        $cxRunningScriptFileSpec = "$PSScriptRoot\CxConsolePlugin\runCxConsole.cmd"

        # check if a valid file

        $fileObj = Get-Item $cxRunningScriptFileSpec

        if ($fileObj.Attributes -eq "Archive" -and $fileObj.Length -gt 0)
        {
            $status = Test-Path $fileOrFolderToScan

            if($status -eq $true)
            {
                $fileObj = Get-Item $fileOrFolderToScan

                #if (-not (Get-Item $file) -is [System.IO.DirectoryInfo])
                if (($fileObj.Attributes) -ne "Directory")
                {
                    if ((Get-Content $fileOrFolderToScan) -ne $null) 
                    {
	                    $fileMimeType = Get-MimeType($fileObj)
    
                        #write-host "DEBUG: $fileMimeType"

                        if (Is-SupportedMimeType $fileMimeType $glbSupportedMimeTypes)
                        {
                            $folderPathToScan = $tempLocation

                            switch($fileMimeType)
                            {
                                "text/plain" { 
                                    if (Is-SupportedFileFormat ($fileObj.extension.ToLower() -replace '\.','') $glbSupportedExtensions)
                                    {
                                        mkdir $tempLocation | Out-Null

                                        copy $fileOrFolderToScan $tempLocation

                                        $filesStatusArray = Verify-ContentBeforeScanning $tempLocation $glbSupportedExtensions

                                        if($filesStatusArray[1] -gt 0)
                                        {
                                            write-host "Openning the temp folder to show the project files ..."

                                            start-process "explorer" -ArgumentList "$tempLocation"

                                            write-host "Found"$filesStatusArray[1]"scannable files out of"$filesStatusArray[0]"files."

                                            write-host "Starting a new scan on the background..."

                                            $status = (Send-AFolderToCheckmarx "$cxRunningScriptFileSpec" $userName $password $cxServerURL $projectPathInsideServer $projectName $tempLocation "yes")

                                            if($status -eq $true)
                                            {
                                                Run-PostSuccessfulScanActions "$PSScriptRoot\reports"
                                            }
                                            else
                                            {
                                                Run-PostFailedScanActions "$PSScriptRoot\logs"
                                            }
                                        }
                                        else
                                        {
                                            write-host "ERROR! No scannable files supplied!"
	                                        write-host "Aborting ..."
                                        }
                                    }
                                }
                                "application/x-zip-compressed" {
                                    if(Is-APasswordProtectedArchiveFile $fileOrFolderToScan $glbSupportedArchiveTypesList)
                                    {
                                        mkdir $tempLocation | Out-Null

                                        Try-ToExtractAPasswordProtectedArchiveFile $fileOrFolderToScan $glbSupportedArchiveTypesList $glbPasswordsList $tempLocation
                                    }
                                    else
                                    {
                                        mkdir $tempLocation | Out-Null

                                        if((Extract-AZipArchive $fileOrFolderToScan $tempLocation) -eq $true)
                                        {
                                            Find-AndExtractInnerArchiveFiles $tempLocation $glbSupportedArchiveTypesList

                                            $filesStatusArray = Verify-ContentBeforeScanning $tempLocation $glbSupportedExtensions

                                            if($filesStatusArray[1] -gt 0)
                                            {
                                                write-host "Openning the temp folder to show the project files ..."

                                                start-process "explorer" -ArgumentList "$tempLocation"

                                                write-host "Found"$filesStatusArray[1]"scannable files out of"$filesStatusArray[0]"files."

                                                write-host "Starting a new scan on the background..."

                                                $status = (Send-AFolderToCheckmarx "$cxRunningScriptFileSpec" $userName $password $cxServerURL $projectPathInsideServer $projectName $tempLocation "yes")

                                                if($status -eq $true)
                                                {
                                                    Run-PostSuccessfulScanActions "$PSScriptRoot\reports"
                                                }
                                                else
                                                {
                                                    Run-PostFailedScanActions "$PSScriptRoot\logs"
                                                }
                                            }
                                            else
                                            {
                                                write-host "ERROR! No scannable files supplied!"
	                                            write-host "Aborting ..."
                                            }
                                        }
                                        else
                                        {
                                            write-host "ERROR! something went wrong while trying to extract the zip archive."

                                            rmdir -Recurse $tempLocation
                                        }
                                    }
                                }
                                "application/x-tar" {
                                    mkdir $tempLocation | Out-Null

                                    if((Extract-ATarArchive $fileOrFolderToScan $tempLocation) -eq $true)
                                    {
                                        Find-AndExtractInnerArchiveFiles $tempLocation $glbSupportedArchiveTypesList

                                        $filesStatusArray = Verify-ContentBeforeScanning $tempLocation $glbSupportedExtensions

                                        if($filesStatusArray[1] -gt 0)
                                        {

                                            write-host "Openning the temp folder to show the project files ..."

                                            start-process "explorer" -ArgumentList "$tempLocation"

                                            write-host "Found"$filesStatusArray[1]"scannable files out of"$filesStatusArray[0]"files."

                                            write-host "Starting a new scan on the background..."

                                            $status = (Send-AFolderToCheckmarx "$cxRunningScriptFileSpec" $userName $password $cxServerURL $projectPathInsideServer $projectName $tempLocation "yes")

                                            if($status -eq $true)
                                            {
                                                Run-PostSuccessfulScanActions "$PSScriptRoot\reports"
                                            }
                                            else
                                            {
                                                Run-PostFailedScanActions "$PSScriptRoot\logs"
                                            }
                                        }
                                        else
                                        {
                                            write-host "ERROR! No scannable files supplied!"
	                                        write-host "Aborting ..."
                                        }
                                    }
                                    else
                                    {
                                        write-host "ERROR! something went wrong while trying to extract the tar archive."

                                        rmdir -Recurse $tempLocation
                                    }
                                }
                                "application/x-gzip" {
                                    if(Is-APasswordProtectedArchiveFile $fileOrFolderToScan $glbSupportedArchiveTypesList)
                                    {
                                        mkdir $tempLocation | Out-Null

                                        Try-ToExtractAPasswordProtectedArchiveFile $fileOrFolderToScan $glbSupportedArchiveTypesList $glbPasswordsList $tempLocation
                                    }
                                    else
                                    {
                                        mkdir $tempLocation | Out-Null

                                        if((Extract-AGZipArchive $fileOrFolderToScan $tempLocation) -eq $true)
                                        {
                                            Find-AndExtractInnerArchiveFiles $tempLocation $glbSupportedArchiveTypesList

                                            $filesStatusArray = Verify-ContentBeforeScanning $tempLocation $glbSupportedExtensions

                                            if($filesStatusArray[1] -gt 0)
                                            {
                                                write-host "Openning the temp folder to show the project files ..."

                                                start-process "explorer" -ArgumentList "$tempLocation"

                                                write-host "Found"$filesStatusArray[1]"scannable files out of"$filesStatusArray[0]"files."

                                                write-host "Starting a new scan on the background..."

                                                $status = (Send-AFolderToCheckmarx "$cxRunningScriptFileSpec" $userName $password $cxServerURL $projectPathInsideServer $projectName $tempLocation "yes")

                                                if($status -eq $true)
                                                {
                                                    Run-PostSuccessfulScanActions "$PSScriptRoot\reports"
                                                }
                                                else
                                                {
                                                    Run-PostFailedScanActions "$PSScriptRoot\logs"
                                                }
                                            }
                                            else
                                            {
                                                write-host "ERROR! No scannable files supplied!"
	                                            write-host "Aborting ..."
                                            }
                                        }
                                        else
                                        {
                                            write-host "ERROR! something went wrong while trying to extract the gzip archive."

                                            rmdir -Recurse $tempLocation
                                        }
                                    }
                                }
                                "application/x-compressed" {
                                    if(Is-APasswordProtectedArchiveFile $fileOrFolderToScan $glbSupportedArchiveTypesList)
                                    {
                                        mkdir $tempLocation | Out-Null

                                        Try-ToExtractAPasswordProtectedArchiveFile $fileOrFolderToScan $glbSupportedArchiveTypesList $glbPasswordsList $tempLocation
                                    }
                                    else
                                    {
                                        mkdir $tempLocation | Out-Null

                                        if((Extract-AGZipArchive $fileOrFolderToScan $tempLocation) -eq $true)
                                        {
                                            Find-AndExtractInnerArchiveFiles $tempLocation $glbSupportedArchiveTypesList

                                            $filesStatusArray = Verify-ContentBeforeScanning $tempLocation $glbSupportedExtensions

                                            if($filesStatusArray[1] -gt 0)
                                            {
                                                write-host "Openning the temp folder to show the project files ..."

                                                start-process "explorer" -ArgumentList "$tempLocation"

                                                write-host "Found"$filesStatusArray[1]"scannable files out of"$filesStatusArray[0]"files."

                                                write-host "Starting a new scan on the background..."

                                                $status = (Send-AFolderToCheckmarx "$cxRunningScriptFileSpec" $userName $password $cxServerURL $projectPathInsideServer $projectName $tempLocation "yes")

                                                if($status -eq $true)
                                                {
                                                    Run-PostSuccessfulScanActions "$PSScriptRoot\reports"
                                                }
                                                else
                                                {
                                                    Run-PostFailedScanActions "$PSScriptRoot\logs"
                                                }
                                            }
                                            else
                                            {
                                                write-host "ERROR! No scannable files supplied!"
	                                            write-host "Aborting ..."
                                            }
                                        }
                                        else
                                        {
                                            write-host "ERROR! something went wrong while trying to extract the gzip archive."

                                            rmdir -Recurse $tempLocation
                                        }
                                    }
                                }
                                "application/octet-stream" {
                                    switch($fileObj.extension.ToLower())
                                    {
                                        ".rar"
                                        {
                                            if(Is-APasswordProtectedArchiveFile $fileOrFolderToScan $glbSupportedArchiveTypesList)
                                            {
                                                mkdir $tempLocation | Out-Null

                                                Try-ToExtractAPasswordProtectedArchiveFile $fileOrFolderToScan $glbSupportedArchiveTypesList $glbPasswordsList $tempLocation
                                            }
                                            else
                                            {
                                                mkdir $tempLocation | Out-Null

                                                if((Extract-ARarArchive $fileOrFolderToScan $tempLocation) -eq $true)
                                                {
                                                    Find-AndExtractInnerArchiveFiles $tempLocation $glbSupportedArchiveTypesList

                                                    $filesStatusArray = Verify-ContentBeforeScanning $tempLocation $glbSupportedExtensions

                                                    if($filesStatusArray[1] -gt 0)
                                                    {
                                                        write-host "Openning the temp folder to show the project files ..."
    
                                                        start-process "explorer" -ArgumentList "$tempLocation"

                                                        write-host "Found"$filesStatusArray[1]"scannable files out of"$filesStatusArray[0]"files."

                                                        write-host "Starting a new scan on the background..."

                                                        $status = (Send-AFolderToCheckmarx "$cxRunningScriptFileSpec" $userName $password $cxServerURL $projectPathInsideServer $projectName $tempLocation "yes")

                                                        if($status -eq $true)
                                                        {
                                                            Run-PostSuccessfulScanActions "$PSScriptRoot\reports"
                                                        }
                                                        else
                                                        {
                                                            Run-PostFailedScanActions "$PSScriptRoot\logs"
                                                        }
                                                    }
                                                    else
                                                    {
                                                        write-host "ERROR! No scannable files supplied!"
	                                                    write-host "Aborting ..."
                                                    }
                                                }
                                                else
                                                {
                                                    write-host "ERROR! something went wrong while trying to extract the rar archive."

                                                    rmdir -Recurse $tempLocation
                                                }
                                            }
                                        }
                                        ".7z"
                                        {
                                            if(Is-APasswordProtectedArchiveFile $fileOrFolderToScan $glbSupportedArchiveTypesList)
                                            {
                                                mkdir $tempLocation | Out-Null

                                                Try-ToExtractAPasswordProtectedArchiveFile $fileOrFolderToScan $glbSupportedArchiveTypesList $glbPasswordsList $tempLocation
                                            }
                                            else
                                            {
                                                mkdir $tempLocation | Out-Null

                                                if((Extract-A7zipArchive $fileOrFolderToScan $tempLocation) -eq $true)
                                                {
                                                    Find-AndExtractInnerArchiveFiles $tempLocation $glbSupportedArchiveTypesList

                                                    $filesStatusArray = Verify-ContentBeforeScanning $tempLocation $glbSupportedExtensions

                                                    if($filesStatusArray[1] -gt 0)
                                                    {

                                                        write-host "Openning the temp folder to show the project files ..."

                                                        start-process "explorer" -ArgumentList "$tempLocation"

                                                        write-host "Found"$filesStatusArray[1]"scannable files out of"$filesStatusArray[0]"files."

                                                        write-host "Starting a new scan on the background..."

                                                        $status = (Send-AFolderToCheckmarx "$cxRunningScriptFileSpec" $userName $password $cxServerURL $projectPathInsideServer $projectName $tempLocation "yes")

                                                        if($status -eq $true)
                                                        {
                                                            Run-PostSuccessfulScanActions "$PSScriptRoot\reports"
                                                        }
                                                        else
                                                        {
                                                           Run-PostFailedScanActions "$PSScriptRoot\logs"
                                                        }
                                                    }
                                                    else
                                                    {
                                                        write-host "ERROR! No scannable files supplied!"
	                                                    write-host "Aborting ..."
                                                    }
                                                }
                                                else
                                                {
                                                    write-host "ERROR! something went wrong while trying to extract the 7zip archive."

                                                    rmdir -Recurse $tempLocation
                                                }
                                            }
                                        }
                                        ".bz2"
                                        {
                                            mkdir $tempLocation | Out-Null

                                            if((Extract-ABz2Archive $fileOrFolderToScan $tempLocation) -eq $true)
                                            {
                                                Find-AndExtractInnerArchiveFiles $tempLocation $glbSupportedArchiveTypesList

                                                $filesStatusArray = Verify-ContentBeforeScanning $tempLocation $glbSupportedExtensions

                                                if($filesStatusArray[1] -gt 0)
                                                {
                                                    write-host "Openning the temp folder to show the project files ..."

                                                    start-process "explorer" -ArgumentList "$tempLocation"

                                                    write-host "Found"$filesStatusArray[1]"scannable files out of"$filesStatusArray[0]"files."

                                                    write-host "Starting a new scan on the background..."
                                                    
                                                    $status = (Send-AFolderToCheckmarx "$cxRunningScriptFileSpec" $userName $password $cxServerURL $projectPathInsideServer $projectName $tempLocation "yes")

                                                    if($status -eq $true)
                                                    {
                                                        Run-PostSuccessfulScanActions "$PSScriptRoot\reports"
                                                    }
                                                    else
                                                    {
                                                        Run-PostFailedScanActions "$PSScriptRoot\logs"
                                                    }
                                                }
                                                else
                                                {
                                                    write-host "ERROR! No scannable files supplied!"
	                                                write-host "Aborting ..."
                                                }
                                            }
                                            else
                                            {
                                                write-host "ERROR! something went wrong while trying to extract the bz2 archive."

                                                rmdir -Recurse -Force $tempLocation
                                            }
                                        }
                                        ""
                                        {
                                            write-host "ERROR! The given file has no extension! Please add an extension to its name according to its type and try again."
                                        }
                                        default
                                        {
                                            write-host "ERROR! The given file mime type is valid, but the file structure is not supported by this application."
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            write-host "ERROR! The given file type is not supported by this application!"
                        }
                    }
                    else
                    {
                        write-host "ERROR! The given 1st argument is an empty file!"
                    }
                }
                else
                {
                    if($cameFromWrapper -eq "no")
                    {
                        mkdir $tempLocation | Out-Null

                        copy -Recurse $fileOrFolderToScan $tempLocation
                    }
                    else
                    {
                        $tempLocation = $fileOrFolderToScan
                    }

                    Find-AndExtractInnerArchiveFiles $tempLocation $glbSupportedArchiveTypesList

                    $filesStatusArray = Verify-ContentBeforeScanning $tempLocation $glbSupportedExtensions

                    if($filesStatusArray[1] -gt 0)
                    {
                        write-host "Openning the temp folder to show the project files ..."

                        start-process "explorer" -ArgumentList "$tempLocation"

                        write-host "Found"$filesStatusArray[1]"scannable files out of"$filesStatusArray[0]"files."

                        write-host "Starting a new scan on the background..."

                        $status = (Send-AFolderToCheckmarx "$cxRunningScriptFileSpec" $userName $password $cxServerURL $projectPathInsideServer $projectName $tempLocation $commaSeparatedListOfFoldersOrPatternsToExcludeFromSASTscan "yes")

                        if($status -eq $true)
                        {
                            Run-PostSuccessfulScanActions "$PSScriptRoot\reports"
                        }
                        else
                        {
                            Run-PostFailedScanActions "$PSScriptRoot\logs"
                        }
                    }
                    else
                    {
                        write-host "ERROR! No scannable files supplied!"
	                    write-host "Aborting ..."
                    }
                }
            }
            else
            {
                write-host "ERROR! The given 1st argument is not a valid path!"
            }
        }
        else
        {
            write-host "ERROR! Cannot find the scanner script!"
            write-host "Please check the settings of this script and try again."
            write-host "Aborting ..."
            write-host $usageInfo
        }
    }
    else
    {
        write-host "ERROR! The first argument is an invalid path!"
        write-host "Please check your input and try again."
        write-host "Aborting ..."
        write-host $usageInfo
    }
}
else
{
	write-host "ERROR! Wrong usage."
	write-host $usageInfo
}