﻿param (
   [string]$fileOrFolderToZip = ""
)

# include a script
. ($PSScriptRoot + "\" + "myFunctions.ps1")

Add-Type -AssemblyName "System.Web"

$usageInfo = "Usage: " + $MyInvocation.MyCommand.Name + " <file-or-folder-to-zip>"

if($fileOrFolderToZip -ne "")
{
    if((Is-ValidCxzipTool $global:glbCxzipBinaryFileSpec) -eq $true)
    {
        $tempLocation = "c:\windows\temp\cx-auto-filter-using-cxzip-" + (Generate-ARandomString 8)

        if($fileOrFolderToZip -ne $null -and $fileOrFolderToZip -ne "")
        {
            $status = (Extract-OrCopyAnItem $fileOrFolderToZip $tempLocation)

            start-process "explorer" -ArgumentList "$tempLocation"

            if($status -eq $true)
            {
                $filesStatusArray = Verify-ContentBeforeScanning $tempLocation $glbSupportedExtensions

                if($filesStatusArray[1] -gt 0)
                {
                    $destDir = $tempLocation

                    $zipFile = (Cxzip-AFolder $tempLocation $destDir)
            
                    if((Is-ValidArchiveFile $zipFile $global:glbSupportedArchiveTypesList) -eq $true)
                    {
                        $zipFileDir = (get-item $zipFile).DirectoryName

                        write-host "A zip file named '$zipFile' was created successfully inside '$zipFileDir'."
                        write-host "Openning '$zipFileDir' ..."

                        start-process "explorer" -ArgumentList "$zipFileDir"

                        #write-host "Removing temp files..."
                        #remove-item -Recurse -Force $tempLocation
                    }
                    else
                    {
                        write-host "Clearing the '$tempLocation' dir ..."
                        remove-item -Recurse -Force $tempLocation

                        # try to regenerate the smaller zip file using 7zip after extracting the corrupted zip file created by cxzip
                        Extract-AZipArchive $zipFile $tempLocation

                        $zipFile = (Create-ANewZipArchive $tempLocation $destDir)

                        if((Is-ValidArchiveFile $zipFile $global:glbSupportedArchiveTypesList) -eq $true)
                        {
                            $zipFileDir = (get-item $zipFile).DirectoryName

                            write-host "A zip file named '$zipFile' was created successfully inside '$zipFileDir'."
                            write-host "Openning '$zipFileDir' ..."

                            start-process "explorer" -ArgumentList "$zipFileDir"
                        }
                        else
                        {
                            Write-host "ERROR! Something went wrong while trying to create a scannable zip file."
                        }
                    }
                }
                else
                {
                    write-host "WARNING: Could not find any scannable files inside the given item."
                    Write-host "Aborting request ..."
                }
            }
            else
            {
                Write-host "ERROR! Something went wrong while trying to extract / copy the selected item!"
                Write-host "Aborting request ..."
            }             
        }
    }
    else
    {
        write-output "ERROR! Could not find 'cxzip.exe' tool inside the path '$global:glbCxzipBinaryFileSpec'!"
    }
}
else
{
	write-host "ERROR! Wrong usage."
	write-host $usageInfo
}