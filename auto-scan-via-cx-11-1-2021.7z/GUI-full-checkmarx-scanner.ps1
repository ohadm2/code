﻿# include a script
. ($PSScriptRoot + "\" + "myFunctions.ps1")

Add-Type -AssemblyName "System.Web"

# mode = "select" for grid view or "newest" for using the newest file automatically
$mode = "select"

#$startLocation = [environment]::GetEnvironmentVariable('userprofile') + "\Downloads"
#"{0} {1}" -f $PSScriptRoot,(Get-Location)

if(((Get-Location).path).Contains($PSScriptRoot))
{
    $startLocation = [environment]::GetEnvironmentVariable('userprofile') + "\Downloads"
}
else
{
    $startLocation = (Get-Location)
}

$extraProjectNamesToSelectFrom = "test,temp"

$innerScriptFileSpec = $PSScriptRoot + "\" + "full-checkmarx-scanner.ps1"

$tempLocation = "c:\windows\temp\gui-full-checkmarx-scanner-" + (Generate-ARandomString 8)

if($mode -eq "select")
{
    $selectedItem = Get-ChildItem $startLocation | sort-object LastWriteTime -Descending | Out-GridView -PassThru -Title "Please select an object to scan (press 'cancel' to select your own path):"

    while($selectedItem -eq $null)
    {
        $readhost = Read-Host -Prompt "Please input a different path to list"

        $readhost = $readhost -replace "`"",""

        $status = test-path $readhost

        if($status -eq $true)
        {
            $list = (Get-ChildItem "$readhost")

            # if the selected item is a single item (a dir or a file) it needs to be converted into an array in order to add the parent dir to the list of options
            if($list -isnot [Array])
            {
                $arr = @()

                $arr += $list
                $arr += (Get-Item "$readhost")

                $list = $arr
            }
            else
            {
                $list += (Get-Item "$readhost")
            }

            $selectedItem = $list | sort-object LastWriteTime -Descending | Out-GridView -PassThru -Title "Please select an object to scan (press 'cancel' to select your own path):"
        }
        else
        {
            while ((test-path $Readhost) -eq $false)
            {
                $Readhost = Read-Host -Prompt "Wrong path, please input a valid path"
            }

            $list = (Get-ChildItem "$readhost")

            # if the selected item is a single item (a dir or a file) it needs to be converted into an array in order to add the parent dir to the list of options
            if($list -isnot [Array])
            {
                $arr = @()

                $arr += $list
                $arr += (Get-Item "$readhost")

                $list = $arr
            }
            else
            {
                $list += (Get-Item "$readhost")
            }

            $selectedItem = Get-ChildItem $readhost | sort-object LastWriteTime -Descending | Out-GridView -PassThru -Title "Please select an object to scan (press 'cancel' to select your own path):"
        }
    }
}
else
{
    $selectedItem = Get-NewestFile $startLocation
}

if($selectedItem -ne $null -and $selectedItem -ne "")
{
    $status = (Extract-OrCopyAnItem $selectedItem.fullname $tempLocation)

    if($status -eq $true)
    {
        Find-AndExtractInnerArchiveFiles $tempLocation $glbSupportedArchiveTypesList

        $extraProjectNamesToSelectFrom = $extraProjectNamesToSelectFrom + "," + $selectedItem.basename

        $name = (Get-AListOfProjectNames $tempLocation $extraProjectNamesToSelectFrom) | get-unique | Out-GridView -PassThru -Title "Please select a project name to use (press 'cancel' to select your own name):"

        if($name -eq $null)
        {
            $name = Read-Host -Prompt "Please input a name"
        }
    
        if($name -ne $null -and $name -ne "")
        {
            $creds = Get-Credential -Message "Please supply your credentials to the Chechmarx server"

            if($creds -ne $null)
            {
                $temp = $creds.GetNetworkCredential()

                $username = $temp.UserName
                $pwd = $temp.Password

                if(($username -ne $null -and $username -ne "") -or ($pwd -ne $null -and $pwd -ne ""))
                {
                    Write-host "Initiating a scan using the supplied details ..."

                    & "$innerScriptFileSpec" $tempLocation $name $username $pwd "yes"
                }
                else
                {
                    Write-host "ERROR! Some credentials are missing!"
                    Write-host "Aborting request ..."
                }
            }
            else
            {
                Write-host "ERROR! Some credentials are missing!"
                Write-host "Aborting request ..."            
            }
        }
        else
        {
            Write-host "ERROR! No project name was selected!"
            Write-host "Aborting request ..."        
        }
    }
    else
    {
        Write-host "ERROR! Something went wrong while trying to extract / copy the selected item!"
        Write-host "Aborting request ..."
    } 
}
else
{
    Write-host "ERROR! No object was selected!"
    Write-host "Aborting request ..."
}    