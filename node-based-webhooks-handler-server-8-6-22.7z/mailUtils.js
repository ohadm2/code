var config = require('./config');

const nodemailer = require("nodemailer");

const path = require('path');

var fs = require('fs');

var smptServerHost = config.smtp.host;
var smptServerPort = config.smtp.port;
var smptServerSecure = config.smtp.secure;
var smptServerIgnoreTLS = config.smtp.ignoreTLS;

function initServer(host, port, secure, ignoreTLS, user, password)
{
	let transporter = nodemailer.createTransport({
	    host: host,
	    port: port,
	    secure: secure, // true for 465, false for other ports
	    ignoreTLS: ignoreTLS,
	    auth: {
	      user: user, 
	      pass: password,
	    },
	  });
	  
	  return transporter;
}

async function sendEmailPlain(from, to, subject, plainBody)
{
	// send mail with defined transport object
	let info = await transporter.sendMail({
		from: from, // sender address
		to: to, // list of receivers
		subject: subject, // Subject line
		text: plainBody // plain text body
	});
	
	return info.messageId;
}

async function sendEmailHtml(from, to, subject, htmlBody)
{
	// send mail with defined transport object
	let info = await transporter.sendMail({
		from: from, // sender address
		to: to, // list of receivers
		subject: subject, // Subject line
		html: htmlBody // html body
	});
	
	return info.messageId;
}

 function sendEmailPlainWithAttachment(from, to, subject, plainBody, fileSpecToAttach, callback)
{
	fs.access(fileSpecToAttach, fs.constants.F_OK, async function(err) {
		if (err)
		{
			console.log("sendEmailPlainWithAttachment error");
			console.log("error: " + err);
			
			if (callback != undefined)
				callback(-1);
			else
				return -1;
		}
		else
		{
			console.log("sendEmailPlainWithAttachment ok");
			// send mail with defined transport object
			let info = await transporter.sendMail({
				from: from, // sender address
				to: to, // list of receivers
				subject: subject, // Subject line
				text: plainBody, 
				attachments: [{ 
						filename: path.basename(fileSpecToAttach),
						path: fileSpecToAttach
					}]
			});
			
			if (callback != undefined)
				callback(info.messageId, fileSpecToAttach);
			else
				return info.messageId;
		}
	});
}

var transporter = initServer(smptServerHost, smptServerPort, smptServerSecure, smptServerIgnoreTLS, "", "");

module.exports.initServer = initServer;
module.exports.sendEmailPlain = sendEmailPlain;
module.exports.sendEmailHtml = sendEmailHtml;
module.exports.sendEmailPlainWithAttachment = sendEmailPlainWithAttachment;


/*

let message = {
    ...
    attachments: [
        {   // utf-8 string as an attachment
            filename: 'text1.txt',
            content: 'hello world!'
        },
        {   // binary buffer as an attachment
            filename: 'text2.txt',
            content: new Buffer('hello world!','utf-8')
        },
        {   // file on disk as an attachment
            filename: 'text3.txt',
            path: '/path/to/file.txt' // stream this file
        },
        {   // filename and content type is derived from path
            path: '/path/to/file.txt'
        },
        {   // stream as an attachment
            filename: 'text4.txt',
            content: fs.createReadStream('file.txt')
        },
        {   // define custom content type for the attachment
            filename: 'text.bin',
            content: 'hello world!',
            contentType: 'text/plain'
        },
        {   // use URL as an attachment
            filename: 'license.txt',
            path: 'https://raw.github.com/nodemailer/nodemailer/master/LICENSE'
        },
        {   // encoded string as an attachment
            filename: 'text1.txt',
            content: 'aGVsbG8gd29ybGQh',
            encoding: 'base64'
        },
        {   // data uri as an attachment
            path: 'data:text/plain;base64,aGVsbG8gd29ybGQ='
        },
        {
            // use pregenerated MIME node
            raw: 'Content-Type: text/plain\r\n' +
                 'Content-Disposition: attachment;\r\n' +
                 '\r\n' +
                 'Hello world!'
        }
    ]
}

*/

