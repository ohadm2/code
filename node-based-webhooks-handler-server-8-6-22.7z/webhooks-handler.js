var config = require('./config');

var fs = require('fs');
const path = require('path');

const express = require('express');
const https = require('https');
const bodyParser = require('body-parser');
const router = express.Router();

var fileUtils = require('./fileUtils');
var netUtils = require('./netUtils');
var generalUtils = require('./generalUtils');
var mailUtils = require('./mailUtils');
var dateUtils = require('./dateUtils');

const app = express();

app.enable('trust proxy');

app.use(bodyParser.urlencoded({ limit: config.web.requestLimit, parameterLimit: config.web.parameterLimit, extended: true }));
app.use(bodyParser.json({ limit: config.web.requestLimit, extended: true, type: 'application/json' }));

app.use("/", router);

var webServerHost = config.web.host;
var webServerPort = config.web.port;
var allowedClients = config.web.allowedClients;

var smptServerHost = config.smtp.host;
var smptServerPort = config.smtp.port;
var smptServerSecure = config.smtp.secure;
var smptServerIgnoreTLS = config.smtp.ignoreTLS;

var emailFrom = config.email.fromAddr;
var emailTo = config.email.toAddr;
var emailSubjectForNexus = config.email.subjectForNexus;
var emailSubjectForAqua = config.email.subjectForAqua;

var https_certs = {
    key: fs.readFileSync(config.web.sslPrivateCertPath),
    cert: fs.readFileSync(config.web.sslPublicCertPath),
};

var https_server = https.createServer(https_certs, app).listen(webServerPort, webServerHost, function(){
  generalUtils.printToConsole(`Express HTTPS server listening on host ${webServerHost} on port ${webServerPort}`);
});


/*
// handle http requests just to notify the clients to use https

const httpApp = express();

const http = require('http');

var httpServer = http.createServer(httpApp).listen(8080);

httpApp.get('*',function (req, res) {
	var clientIP = req.headers['x-forwarded-for'] || req.socket.remoteAddress 

	fileUtils.saveDataToLogFile(clientIP, config.msgs.httpRequest);
	
	res.send(config.msgs.httpRequestToUser);
	generalUtils.printToConsole(config.msgs.httpRequest);
});

*/

//var transporter = mailUtils.initServer(smptServerHost, smptServerPort, smptServerSecure, smptServerIgnoreTLS, "", "");


app.get('/sent-from-nexus', (req, res) => {
	var clientIP = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
	
	var imageNameAndLocalPathInsideRepo;
	var scanLocation;
	var runByUser;
	
	if(netUtils.isValidClient(clientIP))
	{
		fileUtils.saveDataToLogFile(clientIP, config.msgs.clientAllowed + " (get request from Nexus)");
		generalUtils.printToConsole(config.msgs.clientAllowed + " (get request from Nexus)");
		
		var body = req.query;
		
		if (typeof body !== 'undefined' && body !== null && body !== "")
		{
			var bodyAsString = generalUtils.stringify(body);
			
			var jsonObj = JSON.parse(bodyAsString);			

			if(jsonObj.action == "CREATED" && jsonObj.repositoryName.includes("docker", 0))
			{
				if (typeof jsonObj.component.name != 'undefined' && jsonObj.component.name != null && jsonObj.component.name != "")
				{
					imageNameAndLocalPathInsideRepo = jsonObj.component.name + ":" + jsonObj.component.version;
					scanLocation = jsonObj.repositoryName;
			
					// not been used - may be used in the future
					runByUser = jsonObj.initiator;
					
					netUtils.scanADockerImageUsingAqua(scanLocation, imageNameAndLocalPathInsideRepo);
					
					bodyAsString = "This event should have an Aqua scan linked to it" + "\n\n" + bodyAsString;
				}
			}
			
			if (typeof jsonObj.component !== 'undefined')
			{
				if (jsonObj.component.name != null && jsonObj.component.name != "")
				{
					imageNameAndLocalPathInsideRepo = jsonObj.component.name + ":" + jsonObj.component.version;	
				}
			}
			else
			{
				// not an image update webhook
				imageNameAndLocalPathInsideRepo = "";
			}

			var fileSpec = config.files.location + path.sep + "Nexus_Event-" + dateUtils.getCurrentDate("forFileName") + ".json";
			
			fileUtils.saveDataToAFile(fileSpec, bodyAsString);
			
			bodyAsString = imageNameAndLocalPathInsideRepo + "\n\n" + bodyAsString + "\n\n" + config.msgs.maintainer;
			
			(async() => {
				var status = await mailUtils.sendEmailPlain(emailFrom, emailTo, emailSubjectForNexus, bodyAsString);
				
				var response = config.msgs.maintainer + "\n";
				
				response += config.msgs.webServerResponseBodyHeader1;
				response += bodyAsString;
				response += config.msgs.webServerResponseBodyHeader2;
				response += status;
				
				fileUtils.saveDataToLogFile(clientIP, "Nexus email: " + config.msgs.emailMsgStatusText + " " + status);
				
				// send http response
				res.send(response);				
			})();
		}
		else
		{
			fileUtils.saveDataToLogFile(clientIP, config.msgs.emptyBody);
			
			res.send(config.msgs.emptyBody);
			generalUtils.printToConsole(config.msgs.emptyBody);
		}
	}
	else
	{
		fileUtils.saveDataToLogFile(clientIP, config.msgs.clientDenied);
		
		res.send(clientIP + ": " + config.msgs.clientDenied);
		generalUtils.printToConsole(config.msgs.clientDenied);
	}
});

router.post('/sent-from-nexus',(req, res) => {
	var clientIP = req.headers['x-forwarded-for'] || req.socket.remoteAddress;

	var imageNameAndLocalPathInsideRepo;
	var scanLocation;
	var runByUser;
	
	if(netUtils.isValidClient(clientIP))
	{
		fileUtils.saveDataToLogFile(clientIP, config.msgs.clientAllowed + " (post request from Nexus)");
		generalUtils.printToConsole(config.msgs.clientAllowed + " (post request from Nexus)");
		
		var body = req.body;
		
		//if (body != "")
		if (typeof body !== 'undefined' && body !== null && body !== "")
		{
			var bodyAsString = generalUtils.stringify(body);
			
			generalUtils.printToConsole(bodyAsString);
			
			var jsonObj = JSON.parse(bodyAsString);
			
			if(jsonObj.action == "CREATED" && jsonObj.repositoryName.includes("docker", 0))
			{
				if (typeof jsonObj.component.name !== 'undefined' && jsonObj.component.name != null && jsonObj.component.name != "")
				{
					imageNameAndLocalPathInsideRepo = jsonObj.component.name + ":" + jsonObj.component.version;
					scanLocation = jsonObj.repositoryName;
			
					// not been used - may be used in the future
					runByUser = jsonObj.initiator;
					
					netUtils.scanADockerImageUsingAqua(scanLocation, imageNameAndLocalPathInsideRepo);
					
					bodyAsString = "This event should have an Aqua scan linked to it" + "\n\n" + bodyAsString;
				}
			}

			if (typeof jsonObj.component !== 'undefined')
			{
				if (jsonObj.component.name != null && jsonObj.component.name != "")
				{
					imageNameAndLocalPathInsideRepo = jsonObj.component.name + ":" + jsonObj.component.version;	
				}
			}
			else
			{
				// not an image update webhook
				imageNameAndLocalPathInsideRepo = "";
			}
			
			var fileSpec = config.files.location + path.sep + "Nexus_Event-" + dateUtils.getCurrentDate("forFileName") + ".json";
			
			fileUtils.saveDataToAFile(fileSpec, bodyAsString);
			
			bodyAsString = imageNameAndLocalPathInsideRepo + "\n\n" + bodyAsString + "\n\n" + config.msgs.maintainer;
		
			(async() => {
				var status = await mailUtils.sendEmailPlain(emailFrom, emailTo, emailSubjectForNexus, bodyAsString);
				
				var response = config.msgs.maintainer + "\n";
				
				response += config.msgs.webServerResponseBodyHeader1;
				response += bodyAsString;
				response += config.msgs.webServerResponseBodyHeader2;
				response += status;
				
				fileUtils.saveDataToLogFile(clientIP, "Nexus email: " + config.msgs.emailMsgStatusText + " " + status);
				
				// send http response
				res.send(response);				
			})();
		}
		else
		{
			fileUtils.saveDataToLogFile(clientIP, config.msgs.emptyBody);
			
			res.send(config.msgs.emptyBody);
			generalUtils.printToConsole(config.msgs.emptyBody);
		}
	}
	else
	{
		fileUtils.saveDataToLogFile(clientIP, config.msgs.clientDenied);
		
		res.send(clientIP + ": " + config.msgs.clientDenied);
		generalUtils.printToConsole(config.msgs.clientDenied);
	}
	
	//generalUtils.printToConsole(req.body.data);
	//res.end();
});

app.get('/sent-from-aqua', (req, res) => {
	if(req.secure)
	{
		var clientIP = req.headers['x-forwarded-for'] || req.socket.remoteAddress 
		
		if(netUtils.isValidClient(clientIP))
		{
			fileUtils.saveDataToLogFile(clientIP, config.msgs.clientAllowed + " (get request from Aqua)");
			generalUtils.printToConsole(config.msgs.clientAllowed + " (get request from Aqua)");
			
			var body = req.query;
			
			if (typeof body !== 'undefined' && body !== null && body !== "")
			{
				var bodyAsString = generalUtils.stringify(body);
			
				fileUtils.saveAquaScanResultsToFile(bodyAsString, "all", clientIP);
				
				var jsonObj = JSON.parse(bodyAsString);				
				
				if (typeof jsonObj.image != 'undefined' && jsonObj.image != null && jsonObj.image != "")				
				{
					bodyAsString = jsonObj.image + "\n\n" + bodyAsString + "\n\n" + config.msgs.maintainer;					
				}
				else
				{
					bodyAsString = config.msgs.maintainer + "\n\n" + bodyAsString + "\n\n" + config.msgs.maintainer;
				}
					
				(async() => {
					var status = await mailUtils.sendEmailPlain(emailFrom, emailTo, emailSubjectForAqua, bodyAsString);
					
					var response = config.msgs.maintainer + "\n";
					
					response += config.msgs.webServerResponseBodyHeader1;
					response += bodyAsString;
					response += config.msgs.webServerResponseBodyHeader2;
					response += status;
					
					fileUtils.saveDataToLogFile(clientIP, "Aqua email: " + config.msgs.emailMsgStatusText + " " + status);
					
					// send http response
					res.send(response);				
				})();
			}
			else
			{
				fileUtils.saveDataToLogFile(clientIP, config.msgs.emptyBody);
				
				res.send(config.msgs.emptyBody);
				generalUtils.printToConsole(config.msgs.emptyBody);
			}
		}
		else
		{
			fileUtils.saveDataToLogFile(clientIP, config.msgs.clientDenied);
			
			res.send(clientIP + ": " + config.msgs.clientDenied);
			generalUtils.printToConsole(config.msgs.clientDenied);
		}
	}
	else
	{
		fileUtils.saveDataToLogFile(clientIP, config.msgs.httpRequest);
	
		res.send(config.msgs.httpRequestToUser);
		generalUtils.printToConsole(config.msgs.httpRequest);
	}
});

router.post('/sent-from-aqua',(req, res) => {
	var clientIP = req.headers['x-forwarded-for'] || req.socket.remoteAddress 
	
	if(netUtils.isValidClient(clientIP))
	{
		fileUtils.saveDataToLogFile(clientIP, config.msgs.clientAllowed + " (post request from Aqua)");
		generalUtils.printToConsole(config.msgs.clientAllowed + " (post request from Aqua)");
		
		var body = req.body;
		
		//generalUtils.printToConsole(req.socket.bytesRead);
		
		if (typeof body !== 'undefined' && body !== null && body !== "")
		{
			var bodyAsString = generalUtils.stringify(body);
		
			//generalUtils.printToConsole(bodyAsString);
		
			fileUtils.saveAquaScanResultsToFile(bodyAsString, "all", clientIP);
		
			var jsonObj = JSON.parse(bodyAsString);				
			
			if (typeof jsonObj.image != 'undefined' && jsonObj.image != null && jsonObj.image != "")				
			{
				bodyAsString = jsonObj.image + "\n\n" + bodyAsString + "\n\n" + config.msgs.maintainer;					
			}
			else
			{
				bodyAsString = config.msgs.maintainer + "\n\n" + bodyAsString + "\n\n" + config.msgs.maintainer;
			}
		
			(async() => {
				var status = await mailUtils.sendEmailPlain(emailFrom, emailTo, emailSubjectForAqua, bodyAsString);
				
				var response = config.msgs.maintainer + "\n";
				
				response += config.msgs.webServerResponseBodyHeader1;
				response += bodyAsString;
				response += config.msgs.webServerResponseBodyHeader2;
				response += status;
				
				fileUtils.saveDataToLogFile(clientIP, "Aqua email: " + config.msgs.emailMsgStatusText + " " + status);
				
				// send http response
				res.send(response);				
			})();
		}
		else
		{
			fileUtils.saveDataToLogFile(clientIP, config.msgs.emptyBody);
			
			res.send(config.msgs.emptyBody);
			generalUtils.printToConsole(config.msgs.emptyBody);
		}
	}
	else
	{
		fileUtils.saveDataToLogFile(clientIP, config.msgs.clientDenied);
		
		res.send(clientIP + ": " + config.msgs.clientDenied);
		generalUtils.printToConsole(config.msgs.clientDenied);
	}
	
	//generalUtils.printToConsole(req.body.data);
	//res.end();
});


