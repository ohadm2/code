exports.simpleStringify = function(object){
    var simpleObject = {};
    for (var prop in object ){
        if (!object.hasOwnProperty(prop)){
            continue;
        }
        if (typeof(object[prop]) == 'object'){
            continue;
        }
        if (typeof(object[prop]) == 'function'){
            continue;
        }
        simpleObject[prop] = object[prop];
    }
    return JSON.stringify(simpleObject); // returns cleaned up JSON
};

exports.stringify = function(object){
    return JSON.stringify(object, null, 4); // returns cleaned up JSON
};

exports.sleep = function(seconds) {
	return new Promise((resolve) => {
		var ms = seconds * 1000;
		
		setTimeout(resolve, ms);
	});
}

exports.sleep2 = function(seconds) {
	var waitTill = new Date(new Date().getTime() + seconds * 1000);
	
	while(waitTill > new Date()){}
}

exports.printToConsole = function(text) {
	console.log(text + "\n");
}

exports.printFunctionStackTrace = function() {
	console.trace();
}

exports.isEmpty = function(object) {
	return (Object.keys(object).length === 0)
}


