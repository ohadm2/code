var config = require('./config');
var logFileSpec = config.logs.fileSpec;

var dateUtils = require('./dateUtils');
var netUtils = require('./netUtils');
var generalUtils = require('./generalUtils');

var mailUtils = require('./mailUtils');

var fs = require('fs');
const path = require('path');

var imageNameAndLocalPathInsideRepo;
var scanFileSpec;
var repoNameByAquaWhichIsImageNameWithoutATag;

exports.saveAquaScanResultsToFile = async function(data, fileType, clientIP)
{
	var error = 0;
	
	var isScanLocationAValidRegistry = false;
	
	var jsonObj = JSON.parse(data);
	
	if(!generalUtils.isEmpty(jsonObj))
	{
		var imageNameFromJson = jsonObj.image;
		var scanLocation = jsonObj.registry;
		
		// not been used - may be used in the future
		var runByUser = jsonObj.initiating_user;
		
		// there are 2 types of image names structures to process:
		// 1) repo:port/imagePath/imageName:tag (for ad-hoc unregistered scans - for json files creation)
		// 2) imagePath/imageName:tag (for registered scans - for both json and pdf files creation)

		// we need to use a regex to find which type is currently processed and setup the image name and file name accordignly
		// the regex looks for the pattern part ":port" from case #1 above and if it is found it is set as a delimiter using the split function hence
		// in case it is present, the results array will consist of 2 parts which are 1. 'repo' and 2. 'imagePath/imageName:tag'.
		// if it is NOT present, the results array will consist of 1 part which will be only 'imagePath/imageName:tag' which is the whole original expression because we couldn't find a match.
		
		var regex = /(?:\:[0-9]*\/)/;
		
		var splitResultsArr = imageNameFromJson.split(regex);
		
		var fileNamePartGeneratedFromJsonData;
		
		// we handle the cases according to the length of the results arr. see more info above.
		switch(splitResultsArr.length)
		{
			case 1:
				imageNameAndLocalPathInsideRepo = splitResultsArr[0];
				isScanLocationAValidRegistry = true;			
				break;
			case 2:
				imageNameAndLocalPathInsideRepo = splitResultsArr[1];
				break;
			default:
				module.exports.saveDataToLogFile(clientIP, config.msgs.unexpectedError + " while trying to parse the image part of the given json file.");
				error = 1;
				break;
		}
		
		if(error != 1)
		{
			var index = imageNameFromJson.indexOf("/");
			var len = imageNameFromJson.length;
			
			index = imageNameAndLocalPathInsideRepo.indexOf(":");
			repoNameByAquaWhichIsImageNameWithoutATag = imageNameAndLocalPathInsideRepo.substring(0, index);
			
			regex = /:/g;

			fileNamePartGeneratedFromJsonData = imageNameFromJson.replace(regex, '_');
			
			regex = /\//g;
			
			fileNamePartGeneratedFromJsonData = fileNamePartGeneratedFromJsonData.replace(regex, '_');			

			var scanResultsFilesLoc = config.files.location + path.sep;
			
			var scanFileNamePrefix = "scan-";
			
			var scanFileNameNoExt;
			
			if(isScanLocationAValidRegistry)
			{
				// add the reg name to name of the file
				scanFileNameNoExt = scanFileNamePrefix + scanLocation + "_" + fileNamePartGeneratedFromJsonData + "_" + dateUtils.getCurrentDate("forFileName");
			}
			else
			{
				scanFileNameNoExt = scanFileNamePrefix + fileNamePartGeneratedFromJsonData + "_" + dateUtils.getCurrentDate("forFileName");
			}

			// replace spaces with underscores in the final generated filename
			regex = /\ /g;
			
			scanFileNameNoExt = scanFileNameNoExt.replace(regex, '_');
			
			var scanFileSpecNoExt = scanResultsFilesLoc + scanFileNameNoExt;
					
			module.exports.saveDataToLogFile(clientIP, 'scanFileSpecNoExt = ' + scanFileSpecNoExt);
			
			if(fileType == "json" || fileType == "all" || fileType == "both")
			{
				scanFileSpec = scanFileSpecNoExt + ".json";
				
				var file = fs.writeFile(scanFileSpec, data, function(err)
				{
					    if(err)
					    {
						generalUtils.printToConsole(err);
						
						module.exports.saveDataToLogFile(clientIP, err);
					    }
					    else
					    {
					    	module.exports.saveDataToLogFile(clientIP, "a file named " + scanFileSpecNoExt + ".json" + " was created.");
					    }
				});
			}
			
			if(fileType == "pdf" || fileType == "all" || fileType == "both")
			{
				scanFileSpec = __dirname + path.sep + scanFileSpecNoExt + ".pdf";
				
				var scanFileName = scanFileNameNoExt + ".pdf";
				
				// important note: Aqua calls any ci-cd based scan an "Ad Hoc Scan" but if the scan was to set to be registered as well then another copy of the scan results will be created also under a valid registry. The pdf generation process MUST be based on the actual registry because only registered scans can be exported. This is a bit confusing ...
				//if(scanLocation == "Ad Hoc Scans")
				// types of registires are: (1) "Host Scans" - for workers scanning (not images), (2) "Ad Hoc Scans" - for ci-cd scans, (3) <a-reg-name> - for scans from a given registry
				if(scanLocation != "Host Scans")
				{
					//generalUtils.sleep(5);
					
					module.exports.saveDataToLogFile(clientIP, "calling func 'runAquaDockerImageAndGetAPdfReportForAScan' for the file " + scanFileSpec + " ...");
					module.exports.saveDataToLogFile(clientIP, "extra data: imageNameAndLocalPathInsideRepo = " + imageNameAndLocalPathInsideRepo + ", scanFileName = " + scanFileName);
					
					await netUtils.runAquaDockerImageAndGetAPdfReportForAScan(clientIP, imageNameAndLocalPathInsideRepo, scanFileName, handlePdfFile);
				}
			}
		}
	}
	else
	{
		module.exports.saveDataToLogFile(clientIP, config.msgs.invalidJsonInput);
	}
}

async function handlePdfFile(clientIP)
{
	module.exports.saveDataToLogFile(clientIP, "entered func 'handlePdfFile' for the file " + scanFileSpec);
	
	// we need to wait for the pdf file to be created - even though this is a callback function it can't ensure that the file was created on time because the process that creates the file is 
	// run on os-level as an os cmd (docker run cmd)
	
	//while (!module.exports.doesThisFileExist(scanFileSpec))
	//{
	//	module.exports.saveDataToLogFile(clientIP, "Waiting for file '" + scanFileSpec + "' to be available (loop) ... ");
		await generalUtils.sleep(3);
	//}

	fs.access(scanFileSpec, fs.constants.F_OK, async function (err) {
		if (err)
		{
			module.exports.saveDataToLogFile(clientIP, config.msgs.fileCantBeRead + ", file name: " + scanFileSpec);
			module.exports.saveDataToLogFile(clientIP, "err: " + err);
		}
		else
		{	
			generalUtils.printToConsole("exporting scan '" + scanFileSpec + "' ...");

			module.exports.saveDataToLogFile(clientIP, "exporting scan '" + scanFileSpec + "' ...");
			
			var status = await mailUtils.sendEmailPlainWithAttachment(config.email.fromAddr, config.email.pdfsToAddr, config.email.subjectForAqua, "" + imageNameAndLocalPathInsideRepo + "\n\n" + config.msgs.pdfFileIncluded + "\n\n" + config.msgs.maintainer, scanFileSpec, sendEmailPlainWithAttachmentCallback);
				
			netUtils.sendAFileToFtpServer(scanFileSpec);
		}
	});
}

function sendEmailPlainWithAttachmentCallback(status,scanFileSpec)
{
	module.exports.saveDataToLogFile("", " email status for the pdf file '" + scanFileSpec + "' is: " + status);
}

exports.saveDataToLogFile = function(clientIP, data)
{
	var addDateToData = dateUtils.getCurrentDate("forText") + " " + clientIP + " " + data + "\n";
	
	fs.appendFile(logFileSpec, addDateToData, function (err) {
		var logFilePath = path.dirname(logFileSpec);
		
		if (! fs.existsSync(logFilePath)) 
		{
			fs.mkdir(logFilePath, { recursive: true }, (err) => {
				if (err)
				{
					generalUtils.printToConsole(err);
				}
				else
				{
				
				}
			});
		}
	});
}

exports.saveDataToAFile = function(fileSpec, data)
{
	var addDateToData = dateUtils.getCurrentDate("forText") + " " + data + "\n";
	
	fs.appendFile(logFileSpec, addDateToData, function (err) {
		if (err)
		{
			generalUtils.printToConsole("saveDataToAFile func err:");
			generalUtils.printToConsole(err);
			
			module.exports.saveDataToLogFile("", "saveDataToAFile func err:" + err);
		}
	});
}


exports.doesThisFileExist = function(fileSpec)
{
	if (fs.existsSync(fileSpec)) 
	{
		return true;
	}
	else
	{
		return false;
	}
}





    
