var config = require('./config');
var fileUtils = require('./fileUtils');
var generalUtils = require('./generalUtils');

const path = require('path');
const fetch = require('node-fetch');

exports.isValidClient = function(clientIP)
{	
	var loc = config.web.allowedClients.indexOf(clientIP);
	
	if(loc >= 0)
	{
		return true;
	}
	else
	{
		return false;
	}
}

exports.runAquaDockerImageAndGetAPdfReportForAScan = async function(clientIP, scannedImageNameToCreateAReportFor, pdfReportFileName, callback)
{
	var exec = require('child_process').exec;
	//var execSync = require('child_process').execSync;
	
	var imageNameToRun = config.docker.aquaPdfExporterImageName;
	
	// we need to wait for the image to register in Aqua's DB
	await generalUtils.sleep(5);
	
	module.exports.getAquaRegistryNameFromImageName(scannedImageNameToCreateAReportFor).then(registry => {
		
		var cmd;
		
		var registryName = JSON.stringify(registry);
		
		registryName = registryName.replace(/["]+/g, '');
		
		if(registryName != config.msgs.registryNotFoundError)
		{		
			cmd = config.docker.aquaPdfExporterBasicCommand + " -image " + scannedImageNameToCreateAReportFor + " -registry " + registryName + " -output /tmp/reports/" + pdfReportFileName;
			
			//generalUtils.printToConsole(cmd);
			
			var execCMD = "docker run -v " + __dirname + path.sep + config.files.location + ":/tmp/reports " + imageNameToRun + " " + cmd;
			
			var pdfReportFileSpec = __dirname + path.sep + config.files.location + path.sep + pdfReportFileName;
			
			// we need to wait for the pdf file to be created
			//var sleepCMD = " sleep 4 ; " + "ls -l " + __dirname + path.sep + config.files.location + path.sep + pdfReportFileName;
			
			//generalUtils.printToConsole(execCMD);
			
			/*
			try
			{
				var output = execSync(execCMD).toString();
				
				generalUtils.printToConsole(output);

				var output = execSync(sleepCMD).toString();
				
				generalUtils.printToConsole(output);
			}
			catch(err)
			{
				fileUtils.saveDataToLogFile("", "runAquaDockerImageAndGetAPdfReportForAScan func error:");
				fileUtils.saveDataToLogFile("", "status code: " + err.status);
				fileUtils.saveDataToLogFile("", "error: " + err.message);
				fileUtils.saveDataToLogFile("", "stderr: " + err.stderr.toString());
				fileUtils.saveDataToLogFile("", "stdout: " + err.stdout.toString());
			}
			*/
			
			exec(execCMD, function(err, stdout, stderr) {
				if (err || stderr)
				{
					var regex,maskedErr;
					
					//if (err)
					//{
						if (err != undefined)
						{
							regex = /\-password\ \S*/;
						
							maskedErr = err.toString().replace(regex,"-password ***");
						}
						else
						{
							maskedErr = "";
						}
						
						fileUtils.saveDataToLogFile(clientIP, "runAquaDockerImageAndGetAPdfReportForAScan func errors: node err = " + maskedErr + " , stderr = " + stderr + " , stdout = " + stdout);
					//}
					
					//if (stderr)
					//{
					//	fileUtils.saveDataToLogFile("", "runAquaDockerImageAndGetAPdfReportForAScan func exec level error (stderr):" + stderr);
					//}
				}
				else
				{
					maskedErr = "";
					
					generalUtils.printToConsole(stdout);
					
					fileUtils.saveDataToLogFile(clientIP, "runAquaDockerImageAndGetAPdfReportForAScan func results: node err = " + maskedErr + " , stderr = " + stderr + " , stdout = " + stdout);
					
					if (callback != undefined)
						callback(clientIP);
				}
				
				fileUtils.saveDataToLogFile(clientIP, "runAquaDockerImageAndGetAPdfReportForAScan func extra data: clientIP = " + clientIP + ", pdfReportFileName = " + pdfReportFileName);
			});
		}
		else
		{
			generalUtils.printToConsole("REG NOT FOUND");			
			fileUtils.saveDataToLogFile(clientIP, "runAquaDockerImageAndGetAPdfReportForAScan func error:" + config.msgs.registryNotFoundError);
			fileUtils.saveDataToLogFile(clientIP, "runAquaDockerImageAndGetAPdfReportForAScan func extra data: clientIP = " + clientIP + ", pdfReportFileName = " + pdfReportFileName);			
		}
	
	});
}

exports.sendAFileToFtpServer = function(fileSpec)
{
	var ftpHost = config.ftp.host;
	var ftpUsername = config.ftp.username;
	var ftpPassword = config.ftp.password;

	var Client = require('ftp');
	var fs = require('fs');
	
	var destPath = config.ftp.destinationPath
	
	var c = new Client();
	  
	c.on('ready', function() {
		c.cwd(destPath, function(err) {
			if (err) 
			{
				c.mkdir(destPath, false, function(err) {
					if (err) 
					{
					      fileUtils.saveDataToLogFile("", "sendAFileToFtpServer func error (mkdir cmd):" + err);
					}
				});		
			}
		});
	
		c.binary(function(err) {
		
			if (err) 
			{
			      fileUtils.saveDataToLogFile("", "sendAFileToFtpServer func error (bin cmd):" + err);
			}
		});

		c.put(fileSpec, path.basename(fileSpec), function(err) {
			if (err) 
			{
			      fileUtils.saveDataToLogFile("", "sendAFileToFtpServer func error (put cmd): file: " + fileSpec + ", err: " + err);      
			}
			else
			{
				fileUtils.saveDataToLogFile("", "sendAFileToFtpServer func: sent the file " + fileSpec + " successfully to " + destPath + ".");
			}
		});
		
	c.end();
	
	});

	c.connect({host: ftpHost, user: ftpUsername, password: ftpPassword, secure: false});
}

exports.getAquaRegistryNameFromImageName = function(imageName)
{
	var aquaHost = config.aqua.host;
	var auth = config.aqua.basicAuthToken;
	
	const url = aquaHost + '/api/v2/images/names?name=' + imageName;
	
	const options = {
	  method: 'GET',
	  headers: {
	    Accept: 'application/json',
	    Authorization: auth,
	    'Content-Type': 'application/json'
	  }
	};
	
	//generalUtils.printToConsole(url);
	//generalUtils.printToConsole(generalUtils.stringify(options));
	
	var found = false;
	
	var prom = new Promise(resolve =>
    	{
		  fetch(url, options)
		  	.then(res => res.json())
		  
		  	.then(json => {
		  		
		  		var results = json.result;
		  		
		  		var resultsAsStr = generalUtils.stringify(results);
		  		
		  		fileUtils.saveDataToLogFile("", "getAquaRegistryNameFromImageName func web request result: " + resultsAsStr);
		  		
		  		generalUtils.printToConsole(resultsAsStr);
		  		
		  		var realRegistryName;
		  		
		  		for(var result in results)
		  		{	
					if(results[result].registry != "Ad Hoc Scans")
					{
						realRegistryName = results[result].registry;
						found = true;
						break;
					}
				}
				
				if(found)
		  		{
			  		//generalUtils.printToConsole('getAquaRegistryNameFromImageName func response: ' + generalUtils.stringify(json));
		  		
			  		//generalUtils.printToConsole('getAquaRegistryNameFromImageName func output: ' + realRegistryName);
		  		
			  		resolve(realRegistryName);
			  	}
			  	else
			  	{
			  		resolve(config.msgs.registryNotFoundError);
			  	}
		  	})
		  
		  	.catch(err => fileUtils.saveDataToLogFile("", "getAquaRegistryNameFromImageName func error: " + err));
	});
	 
	return(prom);
}

exports.deleteASingleImageFromAqua = function(imageName, repoNameByAquaWhichIsImageNameWithoutATag)
{
	var aquaHost = config.aqua.host;
	var auth = config.aqua.basicAuthToken;
	
	const url = aquaHost + '/api/v2/images/delete/all';
	
	const options = {
	  method: 'POST',
	  headers: {
	    Accept: 'application/json',
	    Authorization: auth,
	    'Content-Type': 'application/json'
	  },
	  body: '{ "filter": { "image_name": "' + imageName + '","repository_name + ":"' + repoNameByAquaWhichIsImageNameWithoutATag + '" } }'
	};
	
	generalUtils.printToConsole(url);
	generalUtils.printToConsole(generalUtils.stringify(options));	

	fetch(url, options)
		.then(res => res.json())

		.then(json => generalUtils.printToConsole('deleteASingleImageFromAqua func output:' + generalUtils.stringify(json)))

		.catch(err => fileUtils.saveDataToLogFile("", "deleteASingleImageFromAqua func error:" + err));
}

exports.runADockerImageViaAPI = function()
{

	var dockerCreateContainerRestApiDataPayload = "{\"AttachStderr\":true,\"AttachStdin\":true,\"AttachStdout\":true,\"Cmd\":[\"" + cmd + "\"],\"Domainname\":\"\",\"Entrypoint\":null,\"Env\":null,\"HostConfig\":{\"AutoRemove\":false,\"Binds\":[\"" + __dirname + path.sep + scanResultsFilesLoc + ":/tmp/reports\"],\"BlkioDeviceReadBps\":null,\"BlkioDeviceReadIOps\":null,\"BlkioDeviceWriteBps\":null,\"BlkioDeviceWriteIOps\":null,\"BlkioWeight\":0,\"BlkioWeightDevice\":[],\"CapAdd\":null,\"CapDrop\":null,\"Cgroup\":\"\",\"CgroupParent\":\"\",\"CgroupnsMode\":\"\",\"ConsoleSize\":[0,0],\"ContainerIDFile\":\"\",\"CpuCount\":0,\"CpuPercent\":0,\"CpuPeriod\":0,\"CpuQuota\":0,\"CpuRealtimePeriod\":0,\"CpuRealtimeRuntime\":0,\"CpuShares\":0,\"CpusetCpus\":\"\",\"CpusetMems\":\"\",\"DeviceCgroupRules\":null,\"DeviceRequests\":null,\"Devices\":[],\"Dns\":[],\"DnsOptions\":[],\"DnsSearch\":[],\"ExtraHosts\":null,\"GroupAdd\":null,\"IOMaximumBandwidth\":0,\"IOMaximumIOps\":0,\"IpcMode\":\"\",\"Isolation\":\"\",\"KernelMemory\":0,\"KernelMemoryTCP\":0,\"Links\":null,\"LogConfig\":{\"Config\":{},\"Type\":\"\"},\"MaskedPaths\":null,\"Memory\":0,\"MemoryReservation\":0,\"MemorySwap\":0,\"MemorySwappiness\":-1,\"NanoCpus\":0,\"NetworkMode\":\"default\",\"OomKillDisable\":false,\"OomScoreAdj\":0,\"PidMode\":\"\",\"PidsLimit\":0,\"PortBindings\":{},\"Privileged\":false,\"PublishAllPorts\":false,\"ReadonlyPaths\":null,\"ReadonlyRootfs\":false,\"RestartPolicy\":{\"MaximumRetryCount\":0,\"Name\":\"no\"},\"SecurityOpt\":null,\"ShmSize\":0,\"UTSMode\":\"\",\"Ulimits\":null,\"UsernsMode\":\"\",\"VolumeDriver\":\"\",\"VolumesFrom\":null},\"Hostname\":\"\",\"Image\":\"" + imageNameToRun + "\",\"Labels\":{},\"NetworkingConfig\":{\"EndpointsConfig\":{}},\"OnBuild\":null,\"OpenStdin\":true,\"Platform\":null,\"StdinOnce\":true,\"Tty\":true,\"User\":\"\",\"Volumes\":{},\"WorkingDir\":\"\"}";
				
	var curlCMDForDockerCreate = "curl -sS --unix-socket /var/run/docker.sock -H \"Content-Type: application/json\" -X POST http://localhost/v1.41/containers/create -d '" + dockerCreateContainerRestApiDataPayload + "'";
	
	var curlCMD1 = "curl -sS --unix-socket /var/run/docker.sock -H \"Content-Type: application/json\" -X POST http://localhost/v1.41/containers/create -d '{\"Image\": \"" + imageNameToRun + "\", \"Cmd\":[\"" + cmd + "\"],\"HostConfig\":{\"Binds\": [\"" + __dirname + path.sep + scanResultsFilesLoc + ":/tmp/reports\"]}}'";
	
	var curlCMDForDockerAttach = ""; // "curl -sS --unix-socket /var/run/docker.sock -X POST http://localhost/v1.41/containers/$ID/attach?stderr=1\\&stdout=1\\&stream=1";

	var curlCMDForDockerWait = "curl -sS --unix-socket /var/run/docker.sock -X POST http://localhost/v1.41/containers/$ID/wait?condition=next-exit";

	var curlCMDForDockerStart = "curl -sS --unix-socket /var/run/docker.sock -X POST http://localhost/v1.41/containers/$ID/start";

	var curlCMDForDockerLogs = ""; // "curl -sS --unix-socket /var/run/docker.sock -X GET http://localhost/v1.41/containers/$ID/logs?stdout=1\\&stderr=1";

	generalUtils.printToConsole(curlCMDForDockerCreate);
	generalUtils.printToConsole(curlCMDForDockerAttach);
	generalUtils.printToConsole(curlCMDForDockerWait);
	generalUtils.printToConsole(curlCMDForDockerStart);
	generalUtils.printToConsole(curlCMDForDockerLogs);

	var execCMD = "ID=$(" + curlCMDForDockerCreate + "| jq .Id | tr -d '\"') && echo $ID > /tmp/id && " + curlCMDForDockerAttach + " && " + curlCMDForDockerWait + " && " + curlCMDForDockerStart + " && " + curlCMDForDockerLogs + " && echo executing ....";
	
	exec(execCMD, function(err, stdout, stderr) {
		if (err)
		{
			fileUtils.saveDataToLogFile("", "runAquaDockerImageAndGetAPdfReportForAScan func node level error:" + err);
		}
		
		if (stderr)
		{
			fileUtils.saveDataToLogFile("", "runAquaDockerImageAndGetAPdfReportForAScan func exec level error (stderr):" + stderr);
		}
		
		generalUtils.printToConsole(stdout);
	});
}

exports.invokeAWebRequest = async function(url, method, body, authToken)
{
	var result = "";
	var Authorization = "";
	
	if(authToken != "" && authToken != undefined)
	{
		Authorization = authToken;
	}
	
	if(body != "" && body != undefined)
	{
		var userBody = "body: " + body;
	}
	
	if(method != "GET" && method != "get" && method != "POST" && method != "post")
	{
		method = "GET";
	}
	
	const options = {
		method: method,
		headers: {
			Accept: 'application/json',
			'Content-Type': 'application/json',
			Authorization			
		},
		userBody
	};

	//generalUtils.printToConsole(url);
	generalUtils.printToConsole(generalUtils.stringify(options));	
	
	try
	{
		result = await fetch(url, options);
		
		fileUtils.saveDataToLogFile("", "invokeAWebRequest func result:" + result.statusText);
		
		return result.status;
	}
	catch(err)
	{
		fileUtils.saveDataToLogFile("", "invokeAWebRequest func error:" + err);
		
		return 555;
	}
}


/*

this function does NOT work as expected and needs to be fixed - the headers part is created incorrectly:

e.g.:

{
    "method": "POST",
    "headers": {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "authHeader": "Authorization: Basic dfdflkdfldkfldfkl==",
        "userHeaders": ""
    }
}

*/

exports.invokeAWebRequest2 = async function(url, method, headers, body, authToken)
{
	var result = "";
	var authHeader = "";
	var userHeaders="";
	
	if(authToken != "" && authToken != undefined)
	{
		authHeader = "Authorization: " + authToken;
	}
	
	if(headers != "" && headers != undefined)
	{
		// take only valid headers using regex
		// structure is: name: value, name:value, ...
		var regex = /([a-z0-9]{1,}:[\ ]{0,1}[a-z0-9_]{1,}[,]{0,1}){1,}/ig;
		
		var validHeadersArr = headers.match(regex);
		
		var validHeadersCounter = validHeadersArr.length;
		
		var index = 0;
		
		while(validHeadersCounter--)
		{
			userHeaders = userHeaders + "," + validHeadersArr[index++];
		}
	}
	
	if(body != "" && body != undefined)
	{
		var userBody = "body: " + body;
	}
	
	if(method != "GET" && method != "get" && method != "POST" && method != "post")
	{
		method = "GET";
	}
	
	const options = {
		method: method,
		headers: {
			Accept: 'application/json',
			'Content-Type': 'application/json',
			authHeader,
			userHeaders
		},
		userBody
	};

	//generalUtils.printToConsole(url);
	generalUtils.printToConsole(generalUtils.stringify(options));	
	
	try
	{
		result = await fetch(url, options);
		
		fileUtils.saveDataToLogFile("", "invokeAWebRequest func result:" + result.statusText);
		
		return result.status;
	}
	catch(err)
	{
		fileUtils.saveDataToLogFile("", "invokeAWebRequest func error:" + err);
		
		return 555;
	}
}

exports.scanADockerImageUsingAqua = function(registryName, imageNameWithTagAndLocalPathInsideRepo)
{
	var apiCall = config.aqua.host + "/api/v1/scanner/registry/" + registryName + "/image/" + imageNameWithTagAndLocalPathInsideRepo + "/scan";

	(async() => {
		result = await module.exports.invokeAWebRequest(apiCall, "POST", "", config.aqua.basicAuthToken);
		
		// note: the error text from the request above is also sent to the default log file 
		
		fileUtils.saveDataToLogFile("", "scanADockerImageUsingAqua func results: " + "api call: " + apiCall + ", web request result: " + result);
	})();
}



