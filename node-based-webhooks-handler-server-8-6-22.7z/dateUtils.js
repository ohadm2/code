exports.getCurrentDate = function(format)
{
	let date_ob = new Date();

	// current date
	// adjust 0 before single digit date
	let day = ("0" + date_ob.getDate()).slice(-2);

	// current month
	let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);

	// current year
	let year = date_ob.getFullYear();

	// current hours
	let hours = date_ob.getHours();

	// current minutes
	//let minutes = date_ob.getMinutes();
	let minutes = ("0" + (date_ob.getMinutes())).slice(-2);

	// current seconds
	//let seconds = date_ob.getSeconds();
	let seconds = ("0" + (date_ob.getSeconds())).slice(-2);

	// prints date in YYYY-MM-DD format
	//console.log(year + "-" + month + "-" + date);

	// prints date & time in YYYY-MM-DD HH:MM:SS format
	//console.log(year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds);

	// prints time in HH:MM format
	//console.log(hours + ":" + minutes);
	
	/*
	if(format == "forFileName")
		return(hours + "-" + minutes + "-" + seconds + "_" + day + "-" + month + "-" + year);
	else
		return(hours + ":" + minutes + ":" + seconds + " " + day + "/" + month + "/" + year);
	*/	
		
	switch(format)
	{
		case "forFileName":
			return(day + "-" + month + "-" + year + "_" + hours + "-" + minutes + "-" + seconds);
			break;
		case "forText":
			return(day + "/" + month + "/" + year + " " + hours + ":" + minutes + ":" + seconds);
			break;
		case "forCalculations":
			return(date_ob.getTime());
		default:
			return(day + "-" + month + "-" + year + "_" + hours + "-" + minutes + "-" + seconds);
	}	
}

exports.getTimeDifference = function(date1, date2)
{
	var differenceInTime = date2.getTime() - date1.getTime();
	
	var differenceInDays = differenceInTime / (1000 * 3600 * 24);
}




