const userConfig = require('./userConfig');

const path = require('path');

//process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

var config = {};

config.web = {};
config.smtp = {};
config.ftp = {};
config.email = {};
config.files = {};
config.logs = {};
config.msgs = {};
config.docker = {};
config.aqua = {};

config.web.host = userConfig.web.host;
config.web.port = userConfig.web.port;
config.web.allowedClients = userConfig.web.allowedClients;
config.web.requestLimit = userConfig.web.requestLimit;
config.web.parameterLimit = userConfig.web.parameterLimit;
config.web.sslPublicCertPath = userConfig.web.sslPublicCertPath;
config.web.sslPrivateCertPath = userConfig.web.sslPrivateCertPath;

config.smtp.host = userConfig.smtp.host;
config.smtp.port = userConfig.smtp.port;
config.smtp.secure = userConfig.smtp.secure;
config.smtp.ignoreTLS = userConfig.smtp.ignoreTLS;

config.ftp.host = userConfig.ftp.host;
config.ftp.username = userConfig.ftp.username;
config.ftp.password = userConfig.ftp.password;
config.ftp.destinationPath = userConfig.ftp.destinationPath;

config.aqua.host = userConfig.aqua.host;
config.aqua.username = userConfig.aqua.username;
// slash required to escape the ! sign
config.aqua.password = userConfig.aqua.password;
config.aqua.basicAuthToken = "Basic " + Buffer.from(config.aqua.username + ":" + config.aqua.password).toString('base64');

config.email.fromAddr = userConfig.email.fromAddr;
config.email.toAddr = userConfig.email.toAddr;
config.email.subjectForNexus = userConfig.email.subjectForNexus;
config.email.subjectForAqua = userConfig.email.subjectForAqua;
config.email.body = userConfig.email.body;

config.email.pdfsToAddr = userConfig.email.pdfsToAddr;

config.files.location = "files";

config.logs.fileSpec = "logs" + path.sep + "err.log";

config.docker.aquaPdfExporterImageName = "aqua-reports:1.2";
config.docker.aquaPdfExporterBasicCommand = "-server " + config.aqua.host + " -user " + config.aqua.username + " -password '" + config.aqua.password + "'";

config.msgs.clientAllowed = "Client Allowed!";
config.msgs.clientDenied = "Client is not allowed to use this service.";
config.msgs.emptyBody = "Empty body detected (when a body must be sent)";
config.msgs.httpRequest = "HTTP request detected (when HTTPS is required)";
config.msgs.httpRequestToUser = "You send an HTTP request. This server accepts HTTPS requests only.";
config.msgs.fileCantBeRead = "No Read access to the file!";
config.msgs.fileNotFoundError = "File not found!";
config.msgs.registryNotFoundError = "RegistryNotFound";
config.msgs.emailMsgStatusText = "The status of the recently sent email message is:";
config.msgs.webServerResponseBodyHeader1 = "Just recieved a new email request!\nDetails:\nData to send:\n";
config.msgs.webServerResponseBodyHeader2 = "\nEmail status:\n";
config.msgs.unexpectedError = "An unexpected error occured";
config.msgs.pdfFileIncluded = "PDF file included";
config.msgs.cannotCreateDir = "Could not create a new directory!";
config.msgs.invalidJsonInput = "Could not detect a valid Json input!";

config.msgs.maintainer = userConfig.msgs.maintainer;

module.exports = config;
